#include "StdAfx.h"
#include "ground.h"
#include "XmlStruct.h"
#include "logic.h"
#include "battle.h"
#include "hero.h"
#include "vectorex.h"
#include "auxiliary.h"
#include "error/ebattle.h"

#define Config XmlConfig::Instance()

namespace battle {

uint32_t
totalprop(battle::ground &g, enum property prop, int from, int to)
{
	float val = 0.0f;
	std::unique_ptr<struct herost> *begin, *end;
	begin = &g.pool_heros[from];
	end = &g.pool_heros[to];
	while (begin < end) {
		herost *h = (begin++)->get();
		if (h == nullptr)
			continue;
		val += hero::propget(h, prop);
	}
	return val;
}

uint32_t
totaltroops(const std::vector<battle::db::hero> &l)
{
	uint32_t troops = 0;
	for (auto &h:l)
		troops += h.troops;
	return troops;
}

static void
transform_element(db::ground *g, int elemid)
{
	int n;
	if (g->elements.count(elemid))
		return ;
	auto *xml = Config.getSkillElement(elemid);
	if (xml == nullptr) {
		INFO("[BATTLE] SkillElement:" << elemid << " nonexist");
		return ;
	}
	auto &elem = g->elements[elemid];
	elem.id = xml->ElementID;
	elem.bigtype = xml->BigType;
	elem.smalltype = xml->SmallType;
	elem.formula = xml->Formula;
	elem.effecttype = xml->EffectType;
	elem.buff.delay = xml->BuffDelay;
	elem.buff.trigger = xml->BuffTrigger;
	elem.buff.invalid = xml->BuffInvalid;
	elem.buff.lasttype = xml->BuffLastType;
	elem.buff.lastround = xml->BuffLastRound;
	elem.buff.overlay = xml->BuffOverlay;
	elem.buff.overcount = xml->BuffOverlayNum;
	elem.buff.limittype = xml->BuffLimitType;
	elem.buff.limitparam = xml->BuffLimitParam;
	switch (elem.effecttype) {
	case EFFECT_DETACH: //清除BUFF
	case EFFECT_BUFF:
	case EFFECT_DEBUFF:
		n = 0;
		for (auto id:xml->BuffCategory)
			n |= 1 << id;
		elem.buff.category = n;
		break;
	default:
		break;
	}
	elem.happentype = xml->HappenType;
	elem.happenratio = xml->HappenRatio;
	elem.percentup = xml->PercentUp;
	elem.percentdown = xml->PercentDown;
	elem.valueup = xml->ValueUp;
	elem.valuedown = xml->ValueDown;
	return ;
}


static void
transform_skill(db::ground *g, const Skill *xml, int range)
{
	if (g->skills.count(xml->ID))
		return ;
	auto &skill = g->skills[xml->ID];
	skill.id = xml->ID;
	skill.type = xml->SkillType;
	skill.triggerparam1 = xml->TriggerParam1;
	skill.triggerparam2 = xml->TriggerParam2;
	skill.initparam = xml->InitParam;
	skill.cd = xml->SkillCD;
	if (xml->SkillType == SKILL_CHASE || xml->SkillType == SKILL_COUNTER)
		skill.range = range;
	else
		skill.range = xml->SkillRange;
	skill.readyround = xml->ReadyRound;
	skill.select.faction = xml->SelectFaction;
	skill.select.range = xml->SelectRange;
	skill.select.category = xml->SelectCategory;
	skill.select.count = xml->SelectCount;
	skill.nextskill = xml->NextSkill;
	skill.nexthappentype = xml->NextHappenType;
	skill.nexthappenratio = xml->NextHappenRatio;
	skill.element.resize(xml->Element.size());
	for (size_t i = 0; i < xml->Element.size(); i++) {
		int elemid = xml->Element[i];
		skill.element[i] = elemid;
		transform_element(g, elemid);
	}
	if (skill.nextskill && (xml = Config.getSkill(skill.nextskill)))
		transform_skill(g, xml, range);
	return ;
}

static void
transform_hero(db::ground *g, const db::hero &h)
{
	int normalrange = 0;
	std::unordered_map<int, const Skill *> conflict;
	std::vector<const Skill *> skillpool;
	DPRINT(g, "[transform] hero hid:%d\n", h.hid);
	skillpool.reserve(h.skills.size());
	for (int skillid:h.skills) {
		const auto *xml = Config.getSkill(skillid);
		if (xml == nullptr) {
			INFO("[BATTLE] skill:" << skillid << " nonexist");
			continue;
		}
		if (xml->SkillType == SKILL_NORMAL)
			normalrange = xml->SkillRange;
		skillpool.emplace_back(xml);
	}
	for (const auto *xml:skillpool) {
		int c = xml->SkillConflict;
		if (c == 0) {
			transform_skill(g, xml, normalrange);
		} else {
			const auto *&s = conflict[c];
			if (s && s->ConflictWeight >= xml->ConflictWeight)
				continue;
			s = xml;
		}
	}
	for (auto &iter:conflict) {
		auto *s = iter.second;
		transform_skill(g, s, normalrange);
		DPRINT(g, "[transform] hero hid:%d skill:%d\n", h.hid, s->ID);
	}
}

static void
transform_(db::ground &g)
{
	g.seed = rand();
	g.mround = 10;
	g.skills.clear();
	g.elements.clear();
	for (const auto &h:g.attacker)
		transform_hero(&g, h);
	for (const auto &h:g.defender)
		transform_hero(&g, h);
	g.masterpoint = xmlbaseget(HeroBase, HEROBASE_MASTERINITIAL);
	g.masterdelta = xmlbaseget(HeroBase, HEROBASE_MASTERGROWTH);
	g.mastermax = xmlbaseget(HeroBase, HEROBASE_MASTERMAX);
	g.hurtratio = xmlbaseget(HeroBase, HEROBASE_HURTRATIO);
	return ;
}

void
transform(db::ground &g, std::string &dat)
{
	transform_(g);
	battle::logic::serialize(g, dat);
	return ;
}

void
dummy(battle::ground &g, battle::result winval)
{
	assert(g.db.attacker.size());
	transform_(g.db);
	g.winval = winval;
	logic::start(&g, nullptr);
	logic::setmanual(&g, 0, 0);
	while (g.state != STATE_EXIT)
		logic::step(&g);
	return ;
}


void
play(battle::ground &g)
{
	return dummy(g, battle::WIN);
}

void
reportextra(battle::ground &g, uint32_t type, uint32_t value)
{
	report::extra extra;
	extra.type = type;
	extra.value = value;
	auxiliary::appendevent(&g, extra);
	return ;
}

void
reportaward(battle::ground &g, const std::vector<IdCount> &l)
{
	report::award award;
	award.list.resize(l.size());
	auto dst_iter = award.list.begin();
	for (auto &ic:l) {
		dst_iter->id = ic.id;
		dst_iter->count = ic.count;
		++dst_iter;
	}
	auxiliary::appendevent(&g, award);
	return ;
}

void
getreport(battle::ground &g, std::string &report)
{
	report = std::move(g.report);
	return ;
}

uint32_t
replay(battle::ground &g, const std::string &op, battle::result res)
{
	int n = 0;
	enum ctrl ctrl;
	const uint8_t *ptr;
	report::operation operation;
	n = operation._unpack((uint8_t *)op.c_str(), op.size(), &ptr);
	if (n < 0)
		return error::BADOPERATION;
	n = operation._parse(ptr, n);
	if (n < 0)
		return error::BADOPERATION;
	g.simplify = true;
	logic::start(&g, nullptr);
	logic::setmanual(&g, 1, 1);
	n = 0;
	auto &oplist = operation.list;
#if 0
	for (int i = 0; i < (int)oplist.size(); i++) {
		printf("op round:%d fight:%d id:%d\n",
			oplist[i].round, oplist[i].fight, oplist[i].id);
	}
#endif
	while (g.state != STATE_EXIT) {
		ctrl = logic::step(&g);
		if (ctrl == battle::CTRL_WAITMASTER) {
			if (n >= (int)oplist.size()) {
				printf("[battle] replay size:%d-%ld\n", n, oplist.size());
				return error::BADOPERATION;
			}
			auto &op = oplist[n];
			if (op.round != g.round) {
				printf("[battle] replay round:%d %d-%d\n", n, op.round, g.round);
				return error::BADOPERATION;
			}
			if (op.fight != g.fightstate) {
				printf("[battle] replay state:%d %d-%d\n", n, op.fight, g.fightstate);
				return error::BADOPERATION;
			}
			int err = logic::setskill(&g, op.id);
			printf("err:%d\n", err);
			n++;
		}
	}
	return g.result == res ? 0 : error::RESULTMISMATCH;
}




}

