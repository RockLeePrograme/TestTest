#include <assert.h>
#include <stdlib.h>
#include <string.h>
#include "ground.h"
#include "hero.h"
#include "skill.h"
#include "buff.h"
#include "fight.h"
#include "auxiliary.h"
#include "logic.h"
#include "portable/battle_report.hpp"

namespace battle {
namespace logic {

static const char *statename[] = {
	"STATE_NONE",
	"STATE_OPEN",
	"STATE_STRATEGY",
	"STATE_ROUNDOPEN",
	"STATE_PASSIVEOPEN",
	"STATE_FIGHTING",
	"STATE_PASSIVECLOSE",
	"STATE_ROUNDCLOSE",
	"STATE_OVER",
};

static const char *fightname[] = {
	"FIGHT_NONE",
	"FIGHT_BUFFOPEN",
	"FIGHT_PASSIVEOPEN",
	"FIGHT_MASTERW",
	"FIGHT_MASTERP",
	"FIGHT_ACTIVE",
	"FIGHT_NORMAL",
	"FIGHT_MASTER2W",
	"FIGHT_MASTER2P",
	"FIGHT_BUFFCLOSE",
	"FIGHT_PASSIVECLOSE",
};

static const char *performname[] = {
	"PERFORM_NONE",
	"PERFORM_RESERVE",
	"PERFORM_ATTACK",
	"PERFORM_COUNTER",
	"PERFORM_CHASE",
};

static int
sortbyspeed(struct herost **start, struct herost *heros[], int size)
{
	return auxiliary::sortalivedesc(start, heros, size, PROP_SPEED);
}

static void
perform_openskill(struct ground *g, struct herost **start)
{
	struct herost *heros[ONE_TEAM];
	int cnt = sortbyspeed(start, heros, ONE_TEAM);
	for (int i = 0; i < cnt; i++) {
		struct herost *h = heros[i];
		for (const db::skill *skill:h->openskills)
			skill::perform(g, h, skill);
	}
	return ;
}

static void
perform_strategyskill(struct ground *g, struct herost **start)
{
	struct herost *heros[ONE_TEAM];
	int cnt = sortbyspeed(start, heros, ONE_TEAM);
	for (int i = 0; i < cnt; i++) {
		struct herost *h = heros[i];
		for (const db::skill *skill:h->strategyskills)
			skill::perform(g, h, skill);
	}
	return ;
}

static enum ctrl
state_open(struct ground *g)
{
	perform_openskill(g, &g->heros[0]);
	perform_openskill(g, &g->heros[ONE_TEAM]);
	g->state = STATE_STRATEGY;
	return CTRL_NORMAL;
}

static enum ctrl
state_strategy(struct ground *g)
{
	perform_strategyskill(g, &g->heros[0]);
	perform_strategyskill(g, &g->heros[ONE_TEAM]);
	g->state = STATE_ROUNDOPEN;
	return CTRL_NORMAL;
}

static enum ctrl
state_roundopen(struct ground *g)
{
	int i, delta, max;
	struct queue *q;
	report::roundopen over;
	over.round = g->round;
	auxiliary::appendevent(g, over);
	q = &g->queue;
	q->idx = 0;
	assert(ARRAYSIZE(g->heros) == ARRAYSIZE(g->queue.heros));
	q->count = sortbyspeed(&g->heros[0], g->queue.heros, TWO_TEAM);
	g->state = (q->count == 0) ? STATE_OVER : STATE_PASSIVEOPEN;

	max = g->mastermax;
	delta = g->masterdelta;
	g->masterpoint[0] = auxiliary::addlimit(g->masterpoint[0], delta, max);
	g->masterpoint[1] = auxiliary::addlimit(g->masterpoint[1], delta, max);
	auxiliary::pushchange(g, CHANGE_SKILL, 0, 0, PROP_MASTER,
			g->masterpoint[0], BUFF_ROUNDOPEN);
	auxiliary::pushchange(g, CHANGE_SKILL, 0, 1, PROP_MASTER,
			g->masterpoint[1], BUFF_ROUNDOPEN);
	//round open buffs
	buff::shadowless(g, BUFF_ROUNDOPEN);
	for (i = 0; i < q->count; i++) {
		struct herost *h = q->heros[i];
		buff::trigger(g, h, BUFF_ROUNDOPEN);
	}
	DPRINT(g, "---------round:%d-------------\n", g->round);
	return CTRL_NORMAL;
}

static enum ctrl
state_passiveopen(struct ground *g)
{
	struct queue *q = &g->queue;
	for (int i = 0; i < q->count; i++) {
		struct herost *h = q->heros[i];
		for(const auto *skill:h->passiveroundopen)
			skill::perform(g, h, skill);
	}
	q->idx = 0;
	q->count = sortbyspeed(&g->heros[0], q->heros, TWO_TEAM);
	DPRINT(g, "[passiveopen] queue size:%d\n", q->count);
	if (q->count != 0) {
		g->state = STATE_FIGHTING;
		g->fightstate = FIGHT_BUFFOPEN;
	} else {
		g->state = STATE_OVER;
	}
	return CTRL_NORMAL;
}

static enum ctrl
state_fighting(struct ground *g)
{
	bool isdead;
	enum ctrl ctrl;
	struct queue *q = &g->queue;
	struct herost *h = q->heros[q->idx];
	isdead = hero::isdead(h);
	DPRINT(g, "[state] fighting hero id:%d pos:%d, isdead:%d queue idx:%d\n",
			h->id, h->pos, (int)isdead, q->idx);
	if (!isdead && (ctrl = fight::fight(g, h)) != CTRL_BREAK) {
		//hero::fight return CTRL_BREAK, to skip
		return ctrl;
	}
	++q->idx;
	if (q->idx < q->count) {
		g->fightstate = FIGHT_BUFFOPEN;
		return CTRL_NORMAL;
	}
	q->count = sortbyspeed(&g->heros[0], q->heros, TWO_TEAM);
	g->state = (q->count == 0) ? STATE_OVER : STATE_PASSIVECLOSE;
	return CTRL_NORMAL;
}

static enum ctrl
state_passiveclose(struct ground *g)
{
	struct queue *q = &g->queue;
	for (int i = 0; i < q->count; i++) {
		struct herost *h = q->heros[i];
		for (const auto *skill:h->passiveroundclose)
			skill::perform(g, h, skill);
	}
	DPRINT(g, "[passiveclose] alive attack:%d defend:%d\n",
			g->alivecount[0], g->alivecount[1]);
	if (g->alivecount[0] == 0 || g->alivecount[1] == 0)
		g->state = STATE_OVER;
	else
		g->state = STATE_ROUNDCLOSE;
	return CTRL_NORMAL;
}

static enum ctrl
state_roundclose(struct ground *g)
{
	size_t i;
	if (g->round >= g->maxround) {
		g->state = STATE_OVER;
		return CTRL_NORMAL;
	}
	++g->round;
	for (i = 0; i < ARRAYSIZE(g->heros); i++) {
		struct herost *h = g->heros[i];
		if (h == nullptr)
			continue;
		if (hero::isdead(h))
			continue;
		buff::trigger(g, h, BUFF_ROUNDCLOSE);
		buff::takeoff(g, h, TAKEOFF_ROUNDCLOSE);
	}
	g->state = STATE_ROUNDOPEN;
	return CTRL_NORMAL;
}

static enum ctrl
state_over(struct ground *g)
{
	int type;
	report::over over;
	if (g->alivecount[0])
		type = 1;
	else
		type = 2;
	if (g->alivecount[1])
		type |= 2;
	switch (type) {
	case 1:
		g->result = g->winval;
		break;
	case 2:
		g->result = result::LOST;
		break;
	default:
		g->result = result::DRAW;
		break;
	}
	over.result = g->result;
	auto &statistics = over.statistics;
	const auto &heros = g->pool_heros;
	statistics.reserve(TWO_TEAM);
	for (const auto &hptr:heros) {
		const auto &h = hptr.get();
		if (h == nullptr)
			continue;
		db::hero *db = (db::hero *)h->db;
		statistics.emplace_back();
		auto &s = statistics.back();
		s.id = h->id;
		s.hero = db->hid;
		s.maxtroops = h->maxtroops;
		s.troops = hero::propget(h, PROP_TROOPS);
		s.hurttroops = hero::propget(h, PROP_HURTTROOPS);
		db->troops = s.troops;
		db->wounded = s.hurttroops;
		s.phurt = h->statistics.phurt;
		s.mhurt = h->statistics.mhurt;
		s.heal = h->statistics.heal;
		s.arm = h->db->arm;
		s.level = h->db->level;
	}
#if DEBUGLOG
	DPRINT(g, "------------------statistics----------------------\n");
	DPRINT(g, "[state] result:%d\n", over.result);
	for (const auto &s:over.statistics) {
		DPRINT(g, "[state] hero:%d troops:%d "
			"phy hurt:%d magic hurt:%d heal:%d "
			" troop:%d hurt troop:%d maxtroop:%d\n",
			s.hero, s.troops,
			s.phurt, s.mhurt, s.heal,
			s.troops, s.hurttroops, s.maxtroops);
	}
#endif
	auxiliary::appendevent(g, over);
	g->state = STATE_EXIT;
	return CTRL_NORMAL;
}

enum ctrl
step(struct ground *g)
{
	enum ctrl ret;
	DPRINT(g, "[step] state:%s, fight:%s, perform:%s,"
		"attack alive:%d, defend alive:%d \n",
		statename[g->state],
		fightname[g->fightstate],
		performname[g->performstate],
		g->alivecount[0], g->alivecount[1]);
	if (g->alivecount[0] == 0 || g->alivecount[1] == 0)	//one dead
		g->state = STATE_OVER;
	switch (g->state) {
	case STATE_OPEN:
		ret = state_open(g);
		break;
	case STATE_STRATEGY:
		ret = state_strategy(g);
		break;
	case STATE_ROUNDOPEN:
		ret = state_roundopen(g);
		break;
	case STATE_PASSIVEOPEN:
		ret = state_passiveopen(g);
		break;
	case STATE_FIGHTING:
		ret = state_fighting(g);
		break;
	case STATE_PASSIVECLOSE:
		ret = state_passiveclose(g);
		break;
	case STATE_ROUNDCLOSE:
		ret = state_roundclose(g);
		break;
	case STATE_OVER:
		ret = state_over(g);
		break;
	case STATE_EXIT:
		break;
	default:
		DPRINT(g, "[step] unkown state:%d\n", g->state);
		break;
	}
	return ret;
}

static void
cookskill(struct ground *g, db::ground &ground)
{
	auto &skills = ground.skills;
	for (auto &siter:skills) {
		auto &s = siter.second;
		auto &element = s.element;
		for (auto eid = element.begin(); eid != element.end(); ) {
			const auto &iter = ground.elements.find(*eid);
			if (iter == ground.elements.end()) {
				eid = element.erase(eid);
			} else {
				*eid = (intptr_t)&iter->second;
				eid++;
			}
		}
		if (s.nextskill == 0)
			continue;
		auto iter = skills.find(s.nextskill);
		if (iter == skills.end())
			s.nextskill = 0;
		else
			s.nextskill = (intptr_t)&iter->second;
	}
	return ;
}

enum error {
	EOK = 0,	//成功
	EPARAM = -1,	//非法参数
	ENONEXIST = -2,	//武将不存在
	EAUTO = -3,	//自动模式下不可以设置技能
	ETEAM = -4,	//此英雄不是当前要释放指挥官技能的队伍
	EMASTER = -5,	//此武将没有指挥官技能
	EMASTERTRI = -6,//触发失败
};

int
setskill(struct ground *g, int id)
{
	struct herost *h;
	DPRINT(g, "[state] setskill %d\n", id);
	if (id < 0 || id >= TWO_TEAM)
		return EPARAM;
	h = g->pool_heros[id].get();
	if (h == nullptr)
		return ENONEXIST;
	if (g->manualctrl[h->team] == 0)
		return EAUTO;
	if (h->team != g->manual.team)
		return ETEAM;
	if (h->masterskill == nullptr)
		return EMASTER;
	g->manual.hero = h;
	return 0;
}

int
setmanual(struct ground *g, int team0, int team1)
{
	g->manual.hero = nullptr;
	g->manualctrl[0] = team0;
	g->manualctrl[1] = team1;
	DPRINT(g, "[state] setmanual %d-%d\n", team0, team1);
	return 0;
}

static void
clearground(struct ground *g)
{
	/* all field will be zero
	int round;
	int maxround;
	int buffidx = 0;
	bool simplify;
	int mastermax;
	int masterdelta;
	int masterpoint[2];	//两队指挥点, 0 -> attack, 1 -> defend
	int manualctrl[2];	//两队手操和自动操作
	int alivecount[2];
	struct queue queue;
	struct manual manual;
	enum state state;
	enum fightstate fightstate;
	enum performstate performstate;
	struct herost *heros[TWO_TEAM];
	size_t reportlastsize;

	enum result winval = WIN;
	enum result result = NIL;
	*/
	uint8_t *start = (uint8_t *)g;
	uint8_t *end = (uint8_t *)&g->winval;
	memset(g, 0, end - start);
	g->result = NIL;
	///////////////object
	g->rattack._reset();
	g->eattack._reset();
	g->operation._reset();
	g->report.clear();
	g->dbref = nullptr;
	g->shadowbuffs.clear();
	for (auto &ptr:g->pool_heros)
		ptr.reset(nullptr);
	return ;
}

void
start(struct ground *g, log_cb_t cb)
{
	int id, count;
	(void)statename;
	(void)fightname;
	(void)performname;
	db::ground *dbref;
	report::groundinfo info;
	clearground(g);
	g->round = 1;
	g->reportlastsize = 0;
	g->maxround = g->db.mround;
	g->hurtratio = g->db.hurtratio;
	if (g->maxround == 0)
		g->maxround = 30;
	g->state = STATE_OPEN;
	cookskill(g, g->db);
	dbref = &g->db;
	g->dbref = dbref;
	g->rand.Start(dbref->seed);
	g->manualctrl[0] = 0;
	g->manualctrl[1] = 0;
	g->mastermax = dbref->mastermax;
	g->masterdelta = dbref->masterdelta;
	g->masterpoint[0] = dbref->masterpoint;
	g->masterpoint[1] = dbref->masterpoint;
	memset(g->heros, 0, sizeof(g->heros));
	id = ONE_TEAM;
	count = std::min((size_t)ONE_TEAM, dbref->attacker.size());
	g->alivecount[0] = count;
	info.masterpoint0 = g->masterpoint[0];
	info.masterpoint1 = g->masterpoint[1];
	info.atk.reserve(count);
	auto &skills = info.skills;
	for (int i = 0; i < count; i++) {
		struct herost *h;
		std::unique_ptr<herost> ptr(new herost());
		h = ptr.get();
		h->team = 0;
		g->heros[--id] = h;
		DPRINT(g, "[start] attack pos:%d ptr:%p\n", id, h);
		hero::init(g, h, &dbref->attacker[i], id);
		info.atk.emplace_back();
		auto &hinfo = info.atk.back();
		hinfo.pos = id;
		hinfo.troops = hero::propget(h, PROP_TROOPS);
		hinfo.hid = dbref->attacker[i].hid;
		hinfo.type = dbref->attacker[i].type;
		auto &as = dbref->attacker[i].skills;
		skills.insert(skills.end(), as.begin(), as.end());
		if (h->masterskill)
			hinfo.master = h->masterskill->id;
		g->pool_heros[id] = std::move(ptr);
	}
	id = ONE_TEAM;
	count = std::min((size_t)ONE_TEAM, dbref->defender.size());
	g->alivecount[1] = count;
	for (int i = 0; i < count; i++, id++) {
		struct herost *h;
		std::unique_ptr<herost> ptr(new herost());
		h = ptr.get();
		h->team = 1;
		g->heros[id] = h;
		g->heros[id]->team = 1;
		DPRINT(g, "[start] defender pos:%d ptr:%p\n", id, h);
		hero::init(g, h, &dbref->defender[i], id);
		info.def.push_back({});
		auto &hinfo = info.def.back();
		hinfo.pos = id;
		hinfo.troops = hero::propget(h, PROP_TROOPS);
		hinfo.hid = dbref->defender[i].hid;
		hinfo.type = dbref->defender[i].type;
		auto &as = dbref->defender[i].skills;
		skills.insert(skills.end(), as.begin(), as.end());
		if (h->masterskill)
			hinfo.master = h->masterskill->id;
		g->pool_heros[id] = std::move(ptr);
	}
	info.mround = g->maxround;
	auxiliary::teamshift(g);
	auxiliary::appendevent(g, info);
	g->log = cb;
	DPRINT(g, "[start] alivecount:%d-%d\n", g->alivecount[0], g->alivecount[1]);
	return ;
}

int
rewind(struct ground *g, const uint8_t *ptr, int size)
{
	g->state = STATE_EXIT;
	g->reportlastsize = 0;
	g->report.assign((char *)ptr, size);
	return 0;
}

int
getreport(struct ground *g, const uint8_t **ptr)
{
	*ptr = (uint8_t *)g->report.c_str();
	return g->report.size();
}

int
parse(db::ground &ground, const uint8_t *buff, int size)
{
	const uint8_t *unpack;
	size = ground._unpack(buff, size, &unpack);
	if (size <= 0)
		return -1;
	size = ground._parse(unpack, size);
	return size;
}

int
serialize(db::ground &g, std::string &data)
{
	int err;
	const uint8_t *ptr, *pack;
	err = g._serialize(&ptr);
	if (err < 0) {
		return 0x03;
	}
	err = g._pack(ptr, err, &pack);
	if (err < 0) {
		return 0x03;
	}
	data.assign((char *)pack, err);
	return 0;
}



}}


