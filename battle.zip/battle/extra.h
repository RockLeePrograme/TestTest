#pragma once
#include <stdint.h>
namespace battle {

enum extra {
	EXTRA_NULL = 1,		//未战斗
	EXTRA_ATKCITY = 2,	//攻城值
	EXTRA_DURABILITY = 3,	//耐久值
	EXTRA_OCCUPY = 4,	//占领状态
	EXTRA_ATKEXP = 5,	//攻方经验
	EXTRA_DEFEXP = 6,	//守方经验
};


};

