#include <algorithm>
#include "ground.h"
#include "skill.h"
#include "buff.h"
#include "hero.h"
#include "auxiliary.h"
#include "fight.h"

namespace battle {
namespace fight {

static enum ctrl
fight_buffopen(struct ground *g, struct herost *h)
{
	if (buff::banget(g, h, BAN_ACTION))
		return CTRL_BREAK;	//skip
	buff::trigger(g, h, BUFF_ACTOPEN);
	buff::takeoff(g, h, TAKEOFF_ACTOPEN);
	g->fightstate = FIGHT_PASSIVEOPEN;
	return CTRL_NORMAL;
}

static enum ctrl
fight_passiveopen(struct ground *g, struct herost *h)
{
	for (const auto *skill:h->passiveactionopen)
		skill::perform(g, h, skill);
	g->fightstate = FIGHT_MASTERW;
	return CTRL_NORMAL;
}

static inline void
pushmaster(struct ground *g, int team, int id)
{
	g->operation.list.emplace_back();
	auto &op = g->operation.list.back();
	op.round = g->round;
	op.fight = g->fightstate;
	op.id = id;
	return ;
}

static inline enum ctrl
checkmanualw(struct ground *g, struct herost *h, enum fightstate next)
{
	g->fightstate = next;
	if (g->manualctrl[h->team]) {
		g->manual.team = h->team;
		if (!g->simplify) {
			report::waitmaster e;
			e.team = h->team;
			auxiliary::appendevent(g, e);
		}
		return CTRL_WAITMASTER;
	}
	return CTRL_NORMAL;
}

static enum ctrl
fight_masterp_manual(struct ground *g, struct herost *h,
		enum fightstate next, enum fightstate w)
{
	struct herost *hh = g->manual.hero;
	if (hh != nullptr && !hero::isdead(hh)) {
		g->manual.hero = nullptr;
		const db::skill *skill = hh->masterskill;
		if (skill && (buff::banget(g, hh, skill->type) == 0)) {
			if (skill::perform(g, hh, skill)) {
				pushmaster(g, hh->team, hh->id);
				g->fightstate = w;
				return CTRL_NORMAL;
			}
		}
	}
	pushmaster(g, h->team, -1);
	g->fightstate = next;
	return CTRL_NORMAL;
}

static enum ctrl
fight_masterp_auto(struct ground *g, struct herost *h,
		enum fightstate next, enum fightstate w)
{
	int i, n;
	struct herost *arr[ONE_TEAM];
	n = h->team * ONE_TEAM;
	n = auxiliary::alive(&g->heros[n], arr, ONE_TEAM);
	std::stable_sort(&arr[0], &arr[n],
			[](struct herost *a, struct herost *b) {
		return a->mastercount < b->mastercount;
	});
	for (i = 0; i < n; i++) {
		struct herost *hh;
		hh = arr[i];
		if (hero::isdead(hh))
			continue;
		const db::skill *skill = hh->masterskill;
		if (skill && (buff::banget(g, hh, skill->type) == 0)) {
			if (skill::perform(g, hh, skill))
				pushmaster(g, hh->team, hh->id);
		}
	}
	pushmaster(g, h->team, -1);
	g->fightstate = next;
	return CTRL_NORMAL;
}

static enum ctrl
fight_masterp(struct ground *g, struct herost *h,
		enum fightstate next, enum fightstate w)
{
	enum ctrl ret;
	if (g->manualctrl[h->team])
		ret = fight_masterp_manual(g, h, next, w);
	else
		ret = fight_masterp_auto(g, h, next, w);
	return ret;
}

static enum ctrl
fight_active(struct ground *g, struct herost *h)
{
	int ban = buff::banget(g, h, SKILL_ACTIVE);
	if (ban == 0) {
		for (const auto *skill:h->activeskills) {
			DPRINT(g, "[fight] active skill:%d ban:%d\n",
					skill->id, ban);
			skill::perform(g, h, skill);
		}
	}
	g->fightstate = FIGHT_NORMAL;
	return CTRL_NORMAL;
}

static enum ctrl
fight_normal(struct ground *g, struct herost *h)
{
	const db::skill *skill = h->normalskill;
	if (skill && (buff::banget(g, h, skill->type) == 0)) {
		skill::perform(g, h, skill);
		if (buff::normaltwice(g, h)) {
			skill::perform(g, h, skill);
		}
	}
	g->fightstate = FIGHT_MASTER2W;
	return CTRL_NORMAL;
}

static enum ctrl
fight_buffclose(struct ground *g, struct herost *h)
{
	buff::trigger(g, h, BUFF_ACTCLOSE);
	buff::takeoff(g, h, TAKEOFF_ACTCLOSE);
	g->fightstate = FIGHT_PASSIVECLOSE;
	return CTRL_NORMAL;
}

static enum ctrl
fight_passiveclose(struct ground *g, struct herost *h)
{
	for (const auto *skill:h->passiveactionclose)
		skill::perform(g, h, skill);
	return CTRL_BREAK;
}

enum ctrl
fight(struct ground *g, struct herost *h)
{
	enum ctrl ret;
	switch (g->fightstate) {
	case FIGHT_BUFFOPEN:
		ret = fight_buffopen(g, h);
		break;
	case FIGHT_PASSIVEOPEN:
		ret = fight_passiveopen(g, h);
		break;
	case FIGHT_MASTERW:
		ret = checkmanualw(g, h, FIGHT_MASTERP);
		break;
	case FIGHT_MASTERP:
		ret = fight_masterp(g, h, FIGHT_ACTIVE, FIGHT_MASTERW);
		break;
	case FIGHT_ACTIVE:
		ret = fight_active(g, h);
		break;
	case FIGHT_NORMAL:
		ret = fight_normal(g, h);
		break;
	case FIGHT_MASTER2W:
		ret = checkmanualw(g, h, FIGHT_MASTER2P);
		break;
	case FIGHT_MASTER2P:
		ret = fight_masterp(g, h, FIGHT_BUFFCLOSE, FIGHT_MASTER2W);
		break;
	case FIGHT_BUFFCLOSE:
		ret = fight_buffclose(g, h);
		break;
	case FIGHT_PASSIVECLOSE:
		ret = fight_passiveclose(g, h);
		break;
	default:
		ret = CTRL_BREAK;
		fprintf(stderr, "[Battle] hero::fight unsupport state:%d\n",
			g->fightstate);
		break;
	}
	return ret;
}

}}

