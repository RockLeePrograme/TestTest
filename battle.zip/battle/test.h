#ifndef _BATTLE_TEST_H
#define _BATTLE_TEST_H

namespace battle {

void test();

};


#endif

