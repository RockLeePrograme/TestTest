#ifndef _BATTLE_AUXILIARY_H
#define _BATTLE_AUXILIARY_H

#include "zprotowire.h"
#include "property.h"
#include "portable/battle_report.hpp"

namespace battle {
namespace auxiliary {

int aliveshrink(struct herost *heros[], int size);
int alive(struct herost **start, struct herost *heros[], int size);
int aliveexclude(struct herost **start, struct herost *heros[],
		int size, int exclude);

int arm(struct herost **start, struct herost *heros[], int size, int arm);
int armexclude(struct herost **start, struct herost *heros[],
		int size, int arm, int exclude);

void sortdesc(struct herost *heros[], int size, enum property prop);
void sortasc(struct herost *heros[], int size, enum property prop);

int sortalivedesc(struct herost **start, struct herost *heros[],
		int size, enum property prop);
int sortaliveasc(struct herost **start, struct herost *heros[],
		int size, enum property prop);

void appendevent(struct ground *g, zprotobuf::wirep &obj);
void attackevent(struct ground *g);
void teamshift(struct ground *g);

static inline void
pushchange(struct ground *g, int type, int elem,
		int hero, int id, float val, int phase)
{
	auto &changes = g->rattack.changes;
	changes.emplace_back();
	auto &ch = changes.back();
	ch.type = type;
	ch.elem = elem;
	ch.hero = hero;
	ch.id = id;
	ch.value = val;
	ch.phase = phase;
	return ;
}

static inline int
addlimit(int a, int b, int limit)
{
	a += b;
	if (a > limit)
		a = limit;
	return a;
}

}}


#endif

