#ifndef _BATTLE_HERO_H
#define _BATTLE_HERO_H

#include <stdint.h>
#include "ground.h"
#include "property.h"
#include "hero.h"

namespace battle {
namespace hero {

	float propget(const struct herost *h, enum property prop);
	float propsub(struct herost *h, enum property prop, float n,
			float percent = 0);
	float propadd(struct herost *h, enum property prop, float n,
			float percent = 0);
	float hpsub(struct herost *h, struct herost * atk, float *current,
			float n, float percent = 0);

	int banincr(struct herost *h, int ban);
	int bandec(struct herost *h, int ban, int n);
	int banget(struct herost *h, int ban);

	int statusincr(struct herost *h, enum herostatus status);
	int statusdec(struct herost *h, enum herostatus status, int n);
	int statusget(struct herost *h, enum herostatus status);

	bool isdead(const struct herost *h);
	void init(struct ground *g, struct herost *h,
			const db::hero *db, int id);
}}

#endif

