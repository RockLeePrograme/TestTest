#include <math.h>
#include "ground.h"
#include "hero.h"
#include "buff.h"
#include "hurt.h"
#include "auxiliary.h"

namespace battle {
namespace hurt {

static float
stage1(struct ground *g,
		struct herost *atk,
		struct herost *def,
		const db::element *elem)
{
	enum property atkprop, defprop;
	float hp, troop, addition, atkv, defv, param1, param2;
	int percent = g->rand.IRandom(elem->percentdown, elem->percentup);
	if (elem->formula == FORMULA_PHYSICS) {
		atkprop = PROP_STRENGTH;
		defprop = PROP_DEFENCE;
	} else {
		atkprop = PROP_INTELLIGENCE;
		defprop = PROP_INTELLIGENCE;
	}
	atkv = hero::propget(atk, atkprop);
	defv = hero::propget(def, defprop);
	hp = percent * (atkv + 50) / (defv + 50) / PERCENT100;
	DPRINT(g, "[hurt] stage1 percent:%d formula:%d"
			" atkv:%.2f, defv:%.2f hp:%.2f\n",
			percent, elem->formula, atkv, defv, hp);
	troop = hero::propget(atk, PROP_TROOPS);
	switch ((int)(troop / 10000)) {
	case 0:
		param1 = 0.f;
		param2 = 0.f;
		goto calc;
	case 1:
		param1 = 10000.f;
		param2 = 10.f;
		goto calc;
	case 2:
		param1 = 20000.f;
		param2 = 20.f;
		goto calc;
	case 3:
		param1 = 30000.f;
		param2 = 30.f;
	calc:
		param1 = troop - param1;
		addition = 19000 * param1 + 8110000 - (param1 * param1);
		addition = addition / 10000000.f + param2;
		break;
	default:
		addition = 40.0f;
		break;
	}
	hp = hp * 40.f * addition;
	DPRINT(g, "[hurt] stage1 addition:%.2f hp:%.2f\n", addition, hp);
	return hp;
}

static float
stage2(struct ground *g, float hp, struct herost *atk, struct herost *def,
		const db::element *elem)
{
	(void)atk;
	float prop = hero::propget(atk, PROP_DAMAGEAMPLIFY);	//伤害加成
	prop += hero::propget(def, PROP_R_DAMAGEAMPLIFY);	//
	prop -= hero::propget(def, PROP_DAMAGEREDUCE);	//伤害减免
	prop -= hero::propget(atk, PROP_R_DAMAGEREDUCE);
	if (elem->formula == FORMULA_PHYSICS) {
		prop += hero::propget(atk, PROP_PHYAMPLIFY);	//物伤加成
		prop += hero::propget(def, PROP_R_PHYAMPLIFY);
		prop -= hero::propget(def, PROP_PHYREDUCE);	//物伤减免
		prop -= hero::propget(atk, PROP_R_PHYREDUCE);
	} else {
		prop += hero::propget(atk, PROP_MAGICAMPLIFY);	//法伤加成
		prop += hero::propget(def, PROP_R_MAGICAMPLIFY);
		prop -= hero::propget(def, PROP_MAGICREDUCE);	//法伤减免
		prop -= hero::propget(atk, PROP_R_MAGICREDUCE);
	}
	prop = std::max(100.0f, prop + PERCENT100);
	hp = hp * prop / PERCENT100;
	DPRINT(g, "[hurt] stage2 prop:%.2f hp:%.2f\n", prop, hp);
	return hp;
}

static float
stage3(struct ground *g, float hp, struct herost *atk, struct herost *def,
		const db::element *elem)
{
	return hp;
}

static void
apply(struct ground *g, struct herost *h, float hp, struct herost *atk)
{
	float current;
	float ratio = g->hurtratio;
	float really = hero::hpsub(h, atk, &current, hp);
	float hurt = really * ratio / PERCENT100;
	hurt = floorf(hurt);
	hero::propadd(h, PROP_HURTTROOPS, hurt);
	if (current < 1.0f) {	//DEAD
		buff::dead(g, h);
		auxiliary::teamshift(g);
		//TODO: notify client
	}
	DPRINT(g, "[hurt] apply hero pos:%d hurt troops:%.2f"
			" really:%.2f hurt ratio:%.2f hurt:%.2f\n",
			h->pos, hp , really, ratio, hurt);
	return ;
}


float
eval(struct ground *g,  struct herost *atk, struct herost *def,
		const db::element *elem)
{
	float hp;
	buff::trigger(g, def, BUFF_HURTEDOPEN, elem->id);
	if (!buff::hurtinvalid(g, def)) {
		hp = stage1(g, atk, def, elem);
		hp = stage2(g, hp, atk, def, elem);
		hp = stage3(g, hp, atk, def, elem);
		if (elem->formula == FORMULA_PHYSICS)
			atk->statistics.phurt += hp;
		else
			atk->statistics.mhurt += hp;
	} else {
		hp = 0.0f;
		DPRINT(g, "[hurt] atk:%d def:%d has hurt invalid\n",
			atk->pos, def->pos);
	}
	buff::trigger(g, def, BUFF_HURTEDCLOSE, elem->id);
	buff::takeoff(g, def, TAKEOFF_HURTEDCLOSE);
	return hp;
}

void
perform(struct ground *g,
		struct herost *atk,
		struct herost *def,
		const db::element *elem,
		struct herost *share,
		float sharepercent)
{
	float hp;
	if (share == nullptr) {
		hp = eval(g, atk, def, elem);
		apply(g, def, hp, atk);
	} else {
		float deval;
		hp = eval(g, atk, def, elem);
		deval = hp * sharepercent / PERCENT100;
		apply(g, def, hp - deval, atk);
		apply(g, share, deval, atk);
	}
	float prop = hero::propget(atk, PROP_VAMPIRE); //吸血
	if (prop > 0.1f) {
		float v = hp * prop / PERCENT100;
		float hurt = hero::propget(atk, PROP_HURTTROOPS);
		if (v > hurt)
			v = hurt;
		hero::propadd(atk, PROP_TROOPS, v);
		hero::propsub(atk, PROP_HURTTROOPS, v);
		DPRINT(g, "[hurt] vampire atk:%d def:%d hp:%.2f\n",
				atk->pos, def->pos, v);
	}
	float troops = hero::propget(def, PROP_TROOPS);
	DPRINT(g, "[hurt] atk pos:%d def pos:%d vampire:%f, current troops:%.2f\n",
		atk->pos, def->pos, prop, troops);
	auxiliary::pushchange(g, CHANGE_SKILL, elem->id, def->id,
		PROP_TROOPS, troops, 0);
	buff::takeoff(g, atk, TAKEOFF_HURTCLOSE);
	return ;
}




}}
