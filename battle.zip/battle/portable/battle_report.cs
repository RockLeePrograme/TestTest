using System;
using System.Text;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Diagnostics;
using zprotobuf;
namespace battle {
namespace report {

public abstract class wirep:iwirep {
	protected override wiretree _wiretree() {
		return serializer.instance();
	}
}

public class change:wirep {
	public int type;
	public int elem;
	public int hero;
	public int phase;
	public int id;
	public float value;

	public override string _name() {
		return "change";
	}
	protected override int _encode_field(ref zdll.args args)  {
		switch (args.tag) {
		case 1:
			return write(ref args, type);
		case 2:
			return write(ref args, elem);
		case 3:
			return write(ref args, hero);
		case 4:
			return write(ref args, phase);
		case 5:
			return write(ref args, id);
		case 6:
			return write(ref args, value);
		default:
			return zdll.ERROR;
		}
	}
	protected override int _decode_field(ref zdll.args args)  {
		switch (args.tag) {
		case 1:
			return read(ref args, out type);
		case 2:
			return read(ref args, out elem);
		case 3:
			return read(ref args, out hero);
		case 4:
			return read(ref args, out phase);
		case 5:
			return read(ref args, out id);
		case 6:
			return read(ref args, out value);
		default:
			return zdll.ERROR;
		}
	}
}
public class attack:wirep {
	public int atk;
	public int skill;
	public change[] changes;

	public override string _name() {
		return "attack";
	}
	protected override int _encode_field(ref zdll.args args)  {
		switch (args.tag) {
		case 1:
			return write(ref args, atk);
		case 2:
			return write(ref args, skill);
		case 3:
			if (args.idx >= (int)changes.Length) {
				args.len = args.idx;
				return zdll.NOFIELD;
			}
			return changes[args.idx]._encode(args.buff, args.buffsz, args.sttype);
		default:
			return zdll.ERROR;
		}
	}
	protected override int _decode_field(ref zdll.args args)  {
		switch (args.tag) {
		case 1:
			return read(ref args, out atk);
		case 2:
			return read(ref args, out skill);
		case 3:
			Debug.Assert(args.idx >= 0);
			if (args.idx == 0)
				changes = new change[args.len];
			if (args.len == 0)
				return 0;
			changes[args.idx] = new change();
			return changes[args.idx]._decode(args.buff, args.buffsz, args.sttype);
		default:
			return zdll.ERROR;
		}
	}
}
public class heroinfo:wirep {
	public int pos;
	public int hid;
	public float troops;
	public int master;
	public int type;

	public override string _name() {
		return "heroinfo";
	}
	protected override int _encode_field(ref zdll.args args)  {
		switch (args.tag) {
		case 1:
			return write(ref args, pos);
		case 2:
			return write(ref args, hid);
		case 3:
			return write(ref args, troops);
		case 4:
			return write(ref args, master);
		case 5:
			return write(ref args, type);
		default:
			return zdll.ERROR;
		}
	}
	protected override int _decode_field(ref zdll.args args)  {
		switch (args.tag) {
		case 1:
			return read(ref args, out pos);
		case 2:
			return read(ref args, out hid);
		case 3:
			return read(ref args, out troops);
		case 4:
			return read(ref args, out master);
		case 5:
			return read(ref args, out type);
		default:
			return zdll.ERROR;
		}
	}
}
public class groundinfo:wirep {
	public int mround;
	public heroinfo[] atk;
	public heroinfo[] def;
	public int[] skills;
	public int masterpoint0;
	public int masterpoint1;
	public int atkuid;
	public int atklid;
	public int defuid;
	public int deflid;

	public override string _name() {
		return "groundinfo";
	}
	protected override int _encode_field(ref zdll.args args)  {
		switch (args.tag) {
		case 1:
			return write(ref args, mround);
		case 2:
			if (args.idx >= (int)atk.Length) {
				args.len = args.idx;
				return zdll.NOFIELD;
			}
			return atk[args.idx]._encode(args.buff, args.buffsz, args.sttype);
		case 3:
			if (args.idx >= (int)def.Length) {
				args.len = args.idx;
				return zdll.NOFIELD;
			}
			return def[args.idx]._encode(args.buff, args.buffsz, args.sttype);
		case 4:
			Debug.Assert(args.idx >= 0);
			if (args.idx >= (int)skills.Length) {
				args.len = args.idx;
				return zdll.NOFIELD;
			}
			return write(ref args, skills[args.idx]);
		case 5:
			return write(ref args, masterpoint0);
		case 6:
			return write(ref args, masterpoint1);
		case 7:
			return write(ref args, atkuid);
		case 8:
			return write(ref args, atklid);
		case 9:
			return write(ref args, defuid);
		case 10:
			return write(ref args, deflid);
		default:
			return zdll.ERROR;
		}
	}
	protected override int _decode_field(ref zdll.args args)  {
		switch (args.tag) {
		case 1:
			return read(ref args, out mround);
		case 2:
			Debug.Assert(args.idx >= 0);
			if (args.idx == 0)
				atk = new heroinfo[args.len];
			if (args.len == 0)
				return 0;
			atk[args.idx] = new heroinfo();
			return atk[args.idx]._decode(args.buff, args.buffsz, args.sttype);
		case 3:
			Debug.Assert(args.idx >= 0);
			if (args.idx == 0)
				def = new heroinfo[args.len];
			if (args.len == 0)
				return 0;
			def[args.idx] = new heroinfo();
			return def[args.idx]._decode(args.buff, args.buffsz, args.sttype);
		case 4:
			if (args.idx == 0)
				skills = new int[args.len];
			if (args.len == 0)
				return 0;
			return read(ref args, out skills[args.idx]);
		case 5:
			return read(ref args, out masterpoint0);
		case 6:
			return read(ref args, out masterpoint1);
		case 7:
			return read(ref args, out atkuid);
		case 8:
			return read(ref args, out atklid);
		case 9:
			return read(ref args, out defuid);
		case 10:
			return read(ref args, out deflid);
		default:
			return zdll.ERROR;
		}
	}
}
public class eattack:wirep {
	public attack[] list;

	public override string _name() {
		return "eattack";
	}
	protected override int _encode_field(ref zdll.args args)  {
		switch (args.tag) {
		case 1:
			if (args.idx >= (int)list.Length) {
				args.len = args.idx;
				return zdll.NOFIELD;
			}
			return list[args.idx]._encode(args.buff, args.buffsz, args.sttype);
		default:
			return zdll.ERROR;
		}
	}
	protected override int _decode_field(ref zdll.args args)  {
		switch (args.tag) {
		case 1:
			Debug.Assert(args.idx >= 0);
			if (args.idx == 0)
				list = new attack[args.len];
			if (args.len == 0)
				return 0;
			list[args.idx] = new attack();
			return list[args.idx]._decode(args.buff, args.buffsz, args.sttype);
		default:
			return zdll.ERROR;
		}
	}
}
public class over:wirep {
	public class info:wire {
		public int id;
		public int hero;
		public int phurt;
		public int mhurt;
		public int heal;
		public int troops;
		public int hurttroops;
		public int maxtroops;
		public int arm;
		public int level;

		public override string _name() {
			return "";
		}
		protected override int _encode_field(ref zdll.args args)  {
			switch (args.tag) {
			case 1:
				return write(ref args, id);
			case 2:
				return write(ref args, hero);
			case 3:
				return write(ref args, phurt);
			case 4:
				return write(ref args, mhurt);
			case 5:
				return write(ref args, heal);
			case 6:
				return write(ref args, troops);
			case 7:
				return write(ref args, hurttroops);
			case 8:
				return write(ref args, maxtroops);
			case 9:
				return write(ref args, arm);
			case 10:
				return write(ref args, level);
			default:
				return zdll.ERROR;
			}
		}
		protected override int _decode_field(ref zdll.args args)  {
			switch (args.tag) {
			case 1:
				return read(ref args, out id);
			case 2:
				return read(ref args, out hero);
			case 3:
				return read(ref args, out phurt);
			case 4:
				return read(ref args, out mhurt);
			case 5:
				return read(ref args, out heal);
			case 6:
				return read(ref args, out troops);
			case 7:
				return read(ref args, out hurttroops);
			case 8:
				return read(ref args, out maxtroops);
			case 9:
				return read(ref args, out arm);
			case 10:
				return read(ref args, out level);
			default:
				return zdll.ERROR;
			}
		}
	}
	public int result;
	public info[] statistics;

	public override string _name() {
		return "over";
	}
	protected override int _encode_field(ref zdll.args args)  {
		switch (args.tag) {
		case 1:
			return write(ref args, result);
		case 2:
			if (args.idx >= (int)statistics.Length) {
				args.len = args.idx;
				return zdll.NOFIELD;
			}
			return statistics[args.idx]._encode(args.buff, args.buffsz, args.sttype);
		default:
			return zdll.ERROR;
		}
	}
	protected override int _decode_field(ref zdll.args args)  {
		switch (args.tag) {
		case 1:
			return read(ref args, out result);
		case 2:
			Debug.Assert(args.idx >= 0);
			if (args.idx == 0)
				statistics = new info[args.len];
			if (args.len == 0)
				return 0;
			statistics[args.idx] = new info();
			return statistics[args.idx]._decode(args.buff, args.buffsz, args.sttype);
		default:
			return zdll.ERROR;
		}
	}
}
public class waitmaster:wirep {
	public int team;

	public override string _name() {
		return "waitmaster";
	}
	protected override int _encode_field(ref zdll.args args)  {
		switch (args.tag) {
		case 1:
			return write(ref args, team);
		default:
			return zdll.ERROR;
		}
	}
	protected override int _decode_field(ref zdll.args args)  {
		switch (args.tag) {
		case 1:
			return read(ref args, out team);
		default:
			return zdll.ERROR;
		}
	}
}
public class operation:wirep {
	public class master:wire {
		public int round;
		public int fight;
		public int id;

		public override string _name() {
			return "";
		}
		protected override int _encode_field(ref zdll.args args)  {
			switch (args.tag) {
			case 1:
				return write(ref args, round);
			case 2:
				return write(ref args, fight);
			case 3:
				return write(ref args, id);
			default:
				return zdll.ERROR;
			}
		}
		protected override int _decode_field(ref zdll.args args)  {
			switch (args.tag) {
			case 1:
				return read(ref args, out round);
			case 2:
				return read(ref args, out fight);
			case 3:
				return read(ref args, out id);
			default:
				return zdll.ERROR;
			}
		}
	}
	public master[] list;

	public override string _name() {
		return "operation";
	}
	protected override int _encode_field(ref zdll.args args)  {
		switch (args.tag) {
		case 1:
			if (args.idx >= (int)list.Length) {
				args.len = args.idx;
				return zdll.NOFIELD;
			}
			return list[args.idx]._encode(args.buff, args.buffsz, args.sttype);
		default:
			return zdll.ERROR;
		}
	}
	protected override int _decode_field(ref zdll.args args)  {
		switch (args.tag) {
		case 1:
			Debug.Assert(args.idx >= 0);
			if (args.idx == 0)
				list = new master[args.len];
			if (args.len == 0)
				return 0;
			list[args.idx] = new master();
			return list[args.idx]._decode(args.buff, args.buffsz, args.sttype);
		default:
			return zdll.ERROR;
		}
	}
}
public class roundopen:wirep {
	public int round;

	public override string _name() {
		return "roundopen";
	}
	protected override int _encode_field(ref zdll.args args)  {
		switch (args.tag) {
		case 1:
			return write(ref args, round);
		default:
			return zdll.ERROR;
		}
	}
	protected override int _decode_field(ref zdll.args args)  {
		switch (args.tag) {
		case 1:
			return read(ref args, out round);
		default:
			return zdll.ERROR;
		}
	}
}
public class extra:wirep {
	public int type;
	public int value;

	public override string _name() {
		return "extra";
	}
	protected override int _encode_field(ref zdll.args args)  {
		switch (args.tag) {
		case 1:
			return write(ref args, type);
		case 2:
			return write(ref args, value);
		default:
			return zdll.ERROR;
		}
	}
	protected override int _decode_field(ref zdll.args args)  {
		switch (args.tag) {
		case 1:
			return read(ref args, out type);
		case 2:
			return read(ref args, out value);
		default:
			return zdll.ERROR;
		}
	}
}
public class award:wirep {
	public class idcount:wire {
		public int id;
		public int count;

		public override string _name() {
			return "";
		}
		protected override int _encode_field(ref zdll.args args)  {
			switch (args.tag) {
			case 1:
				return write(ref args, id);
			case 2:
				return write(ref args, count);
			default:
				return zdll.ERROR;
			}
		}
		protected override int _decode_field(ref zdll.args args)  {
			switch (args.tag) {
			case 1:
				return read(ref args, out id);
			case 2:
				return read(ref args, out count);
			default:
				return zdll.ERROR;
			}
		}
	}
	public idcount[] list;

	public override string _name() {
		return "award";
	}
	protected override int _encode_field(ref zdll.args args)  {
		switch (args.tag) {
		case 1:
			if (args.idx >= (int)list.Length) {
				args.len = args.idx;
				return zdll.NOFIELD;
			}
			return list[args.idx]._encode(args.buff, args.buffsz, args.sttype);
		default:
			return zdll.ERROR;
		}
	}
	protected override int _decode_field(ref zdll.args args)  {
		switch (args.tag) {
		case 1:
			Debug.Assert(args.idx >= 0);
			if (args.idx == 0)
				list = new idcount[args.len];
			if (args.len == 0)
				return 0;
			list[args.idx] = new idcount();
			return list[args.idx]._decode(args.buff, args.buffsz, args.sttype);
		default:
			return zdll.ERROR;
		}
	}
}
public class serializer:wiretree {

	private static serializer inst = null;

	private const string def = "\x63\x68\x61\x6e\x67\x65\x20\x7b\xa\x9\x2e\x74\x79\x70\x65\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x31\x9\x23\xa\x9\x2e\x65\x6c\x65\x6d\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x32\x9\x23\x20\x30\x20\x2d\x2d\x3e\x20\x73\x6b\x69\x6c\x6c\x20\x63\x68\x61\x6e\x67\x65\x2c\x20\x3e\x20\x30\x20\x2d\x2d\x3e\x20\x62\x75\x66\x66\x20\x63\x68\x61\x6e\x67\x65\xa\x9\x2e\x68\x65\x72\x6f\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x33\xa\x9\x2e\x70\x68\x61\x73\x65\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x34\xa\x9\x2e\x69\x64\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x35\x9\x23\x20\x70\x72\x6f\x70\x65\x72\x74\x79\x2e\x68\xa\x9\x2e\x76\x61\x6c\x75\x65\x3a\x66\x6c\x6f\x61\x74\x20\x36\xa\x7d\xa\xa\x61\x74\x74\x61\x63\x6b\x20\x30\x78\x30\x37\x20\x7b\xa\x9\x2e\x61\x74\x6b\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x31\xa\x9\x2e\x73\x6b\x69\x6c\x6c\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x32\xa\x9\x2e\x63\x68\x61\x6e\x67\x65\x73\x3a\x63\x68\x61\x6e\x67\x65\x5b\x5d\x20\x33\xa\x7d\xa\xa\x68\x65\x72\x6f\x69\x6e\x66\x6f\x20\x7b\xa\x9\x2e\x70\x6f\x73\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x31\xa\x9\x2e\x68\x69\x64\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x32\xa\x9\x2e\x74\x72\x6f\x6f\x70\x73\x3a\x66\x6c\x6f\x61\x74\x20\x33\xa\x9\x2e\x6d\x61\x73\x74\x65\x72\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x34\xa\x9\x2e\x74\x79\x70\x65\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x35\xa\x7d\xa\xa\x67\x72\x6f\x75\x6e\x64\x69\x6e\x66\x6f\x20\x30\x78\x30\x31\x20\x7b\xa\x9\x2e\x6d\x72\x6f\x75\x6e\x64\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x31\xa\x9\x2e\x61\x74\x6b\x3a\x68\x65\x72\x6f\x69\x6e\x66\x6f\x5b\x5d\x20\x32\xa\x9\x2e\x64\x65\x66\x3a\x68\x65\x72\x6f\x69\x6e\x66\x6f\x5b\x5d\x20\x33\xa\x9\x2e\x73\x6b\x69\x6c\x6c\x73\x3a\x69\x6e\x74\x65\x67\x65\x72\x5b\x5d\x20\x34\xa\x9\x2e\x6d\x61\x73\x74\x65\x72\x70\x6f\x69\x6e\x74\x30\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x35\xa\x9\x2e\x6d\x61\x73\x74\x65\x72\x70\x6f\x69\x6e\x74\x31\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x36\xa\x9\x2e\x61\x74\x6b\x75\x69\x64\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x37\xa\x9\x2e\x61\x74\x6b\x6c\x69\x64\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x38\xa\x9\x2e\x64\x65\x66\x75\x69\x64\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x39\xa\x9\x2e\x64\x65\x66\x6c\x69\x64\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x31\x30\xa\x7d\xa\xa\x65\x61\x74\x74\x61\x63\x6b\x20\x30\x78\x30\x32\x20\x7b\xa\x9\x2e\x6c\x69\x73\x74\x3a\x61\x74\x74\x61\x63\x6b\x5b\x5d\x20\x31\xa\x7d\xa\xa\x6f\x76\x65\x72\x20\x30\x78\x30\x33\x20\x7b\xa\x9\x69\x6e\x66\x6f\x20\x7b\xa\x9\x9\x2e\x69\x64\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x31\xa\x9\x9\x2e\x68\x65\x72\x6f\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x32\xa\x9\x9\x2e\x70\x68\x75\x72\x74\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x33\xa\x9\x9\x2e\x6d\x68\x75\x72\x74\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x34\xa\x9\x9\x2e\x68\x65\x61\x6c\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x35\xa\x9\x9\x2e\x74\x72\x6f\x6f\x70\x73\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x36\xa\x9\x9\x2e\x68\x75\x72\x74\x74\x72\x6f\x6f\x70\x73\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x37\xa\x9\x9\x2e\x6d\x61\x78\x74\x72\x6f\x6f\x70\x73\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x38\xa\x9\x9\x2e\x61\x72\x6d\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x39\xa\x9\x9\x2e\x6c\x65\x76\x65\x6c\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x31\x30\xa\x9\x7d\xa\x9\x2e\x72\x65\x73\x75\x6c\x74\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x31\xa\x9\x2e\x73\x74\x61\x74\x69\x73\x74\x69\x63\x73\x3a\x69\x6e\x66\x6f\x5b\x5d\x20\x32\xa\x7d\xa\xa\x77\x61\x69\x74\x6d\x61\x73\x74\x65\x72\x20\x30\x78\x30\x35\x20\x7b\xa\x9\x2e\x74\x65\x61\x6d\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x31\xa\x7d\xa\xa\x6f\x70\x65\x72\x61\x74\x69\x6f\x6e\x20\x30\x78\x30\x36\x20\x7b\xa\x9\x6d\x61\x73\x74\x65\x72\x20\x7b\xa\x9\x9\x2e\x72\x6f\x75\x6e\x64\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x31\xa\x9\x9\x2e\x66\x69\x67\x68\x74\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x32\xa\x9\x9\x2e\x69\x64\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x33\xa\x9\x7d\xa\x9\x2e\x6c\x69\x73\x74\x3a\x6d\x61\x73\x74\x65\x72\x5b\x5d\x20\x31\xa\x7d\xa\xa\x72\x6f\x75\x6e\x64\x6f\x70\x65\x6e\x20\x30\x78\x30\x38\x20\x7b\xa\x9\x2e\x72\x6f\x75\x6e\x64\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x31\xa\x7d\xa\xa\x65\x78\x74\x72\x61\x20\x30\x78\x30\x39\x20\x7b\xa\x9\x2e\x74\x79\x70\x65\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x31\xa\x9\x2e\x76\x61\x6c\x75\x65\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x32\xa\x7d\xa\xa\x61\x77\x61\x72\x64\x20\x30\x78\x30\x61\x20\x7b\xa\x9\x69\x64\x63\x6f\x75\x6e\x74\x20\x7b\xa\x9\x9\x2e\x69\x64\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x31\xa\x9\x9\x2e\x63\x6f\x75\x6e\x74\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x32\xa\x9\x7d\xa\x9\x2e\x6c\x69\x73\x74\x3a\x69\x64\x63\x6f\x75\x6e\x74\x5b\x5d\x20\x31\xa\x7d\xa\xa";
	private serializer():base(def) {

	}

	public static serializer instance() {
		if (inst == null)
			inst = new serializer();
		return inst;
	}
}

}}
