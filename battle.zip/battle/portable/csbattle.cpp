#include <stdint.h>
#include "ground.h"
#include "logic.h"

#define eventtype(ptr)	(*(battle::event_type_t *)(ptr))
#define eventsize(ptr)	(*(battle::event_size_t *)(ptr))

#ifdef WIN32
#define EXPORT __declspec(dllexport)
#else
#define EXPORT
#endif

struct buffer {
	int32_t type;
	const uint8_t *ptr;
	int32_t size;
};

extern "C" battle::ground * EXPORT
csbstart(const uint8_t *buff, int32_t size, log_cb_t cb)
{
	battle::ground *g = new battle::ground();
	if (battle::logic::parse(g->db, buff, size) < 0) {
		delete g;
		return nullptr;
	}
	battle::logic::start(g, cb);
	return g;
}

extern "C" void EXPORT
csbstop(battle::ground *g)
{
	delete g;
	return ;
}

extern "C" int EXPORT
csbsetskill(battle::ground *g, int id)
{
	return battle::logic::setskill(g, id);
}

extern "C" void EXPORT
csbsetmanual(battle::ground *g, int team0, int team1)
{
	battle::logic::setmanual(g, team0, team1);
}

extern "C" void EXPORT
csboperation(battle::ground *g, struct buffer *buff)
{
	int sz;
	const uint8_t *ptr;
	g->report.clear();
	sz = g->operation._serialize(&ptr);
	if (sz < 0) {
		buff->type = 0;
		buff->ptr = 0;
		buff->size = 0;
		return ;
	}
	g->operation._pack(ptr, sz, g->report);
	buff->type = g->operation._tag();
	buff->ptr = (const uint8_t *)g->report.c_str();
	buff->size = g->report.size();
	return ;
}

extern "C" int EXPORT
csbstep(battle::ground *g, struct buffer *buff)
{
	if (g->reportlastsize >= g->report.size()) {
		while (g->state != battle::STATE_EXIT) {
			battle::logic::step(g);
			if (g->reportlastsize < g->report.size())
				break;
		}
	}
	if (g->reportlastsize < g->report.size()) {
		battle::event_type_t type;
		battle::event_size_t size;
		const uint8_t *ptr = (uint8_t *)g->report.c_str();
		const uint8_t *start = ptr + g->reportlastsize;
		type = eventtype(start);
		start += sizeof(type);
		size = eventsize(start);
		start += sizeof(size);
		buff->type = type;
		buff->ptr = start;
		buff->size = size;
		g->reportlastsize = start + size - ptr;
		return 0;
	} else {
		buff->type = 0;
		buff->ptr = 0;
		buff->size = 0;
		return 1;
	}
}

extern "C" void EXPORT
csbreport(battle::ground *g, struct buffer *buff)
{
	buff->ptr = (uint8_t *)g->report.c_str();
	buff->size = g->report.size();
	return ;
}


extern "C" int EXPORT
csbinfo(battle::ground *g, struct buffer *buff)
{
	return csbstep(g, buff);
}

extern "C" battle::ground * EXPORT
csbrewind(const uint8_t *ptr, int size)
{
	battle::ground *g = new battle::ground();
	battle::logic::rewind(g, ptr, size);
	return g;
}


