using System;
using System.IO;
using System.Diagnostics;
using System.Runtime.InteropServices;
using battle;
using battle.report;

namespace test {
class Program {
	static void play(int n)
	{
		FileStream fs = new FileStream("./ground.dat", FileMode.Open, FileAccess.Read);
		byte[] buffer = new byte[fs.Length];
		fs.Read(buffer, 0, buffer.Length);
		fs.Close();
		bdll.revent buff = new bdll.revent();
		IntPtr g = bdll.start(buffer);
		bdll.setmanual(g, n, 0);
		Console.WriteLine("hello:" + g + "\n");
		for (;;) {
			int ret = bdll.step(g, ref buff);
			Console.WriteLine("hello:" + g + "\n");
			if (ret != 0)
				break;
			switch (buff.type) {
			case 1:
				battle.report.groundinfo ginfo = new battle.report.groundinfo();
				ginfo._parse(buff.ptr, buff.size);
				Console.WriteLine("GroundInfo:" +
						ginfo.mround);
				break;
			case 2:
				break;
			case 5: //wait master
				battle.report.waitmaster wait = new battle.report.waitmaster();
				wait._parse(buff.ptr, buff.size);
				Console.WriteLine("wait master team:" + wait.team);
				string str = Console.ReadLine();
				int id = Int32.Parse(str);
				Console.WriteLine("input:" + id);
				bdll.setskill(g, id);
				break;
			}
		}
		{
			FileStream fs2 = new FileStream("./report.dat", FileMode.Create, FileAccess.Write);
			bdll.report(g, ref buff);
			byte[] buffer2 = new byte[buff.size];
			Marshal.Copy(buff.ptr, buffer2, 0, buff.size);
			fs2.Write(buffer2, 0, buffer2.Length);
			fs2.Close();
		}
		{
			FileStream fs2 = new FileStream("./operation.dat", FileMode.Create, FileAccess.Write);
			bdll.operation(g, ref buff);
			byte[] buffer2 = new byte[buff.size];
			Marshal.Copy(buff.ptr, buffer2, 0, buff.size);
			fs2.Write(buffer2, 0, buffer2.Length);
			fs2.Close();
		}
		return ;

	}

	static void rewind()
	{
		int n = 0;
		byte[] unpack;
		FileStream fs = new FileStream("./rewind.dat", FileMode.Open, FileAccess.Read);
		byte[] buffer = new byte[fs.Length];
		fs.Read(buffer, 0, buffer.Length);
		fs.Close();
		bdll.revent buff = new bdll.revent();
		IntPtr g = bdll.rewind(buffer);
		for (;;) {
			int ret = bdll.step(g, ref buff);
			Console.WriteLine("revent:" + buff.type);
			if (ret == 1)
				break;
		}
	}

	static void replay()
	{
		int n = 0;
		byte[] unpack;
		FileStream fs = new FileStream("./operation.dat", FileMode.Open, FileAccess.Read);
		byte[] buffer = new byte[fs.Length];
		fs.Read(buffer, 0, buffer.Length);
		fs.Close();
		battle.report.operation operation = new battle.report.operation();
		operation._unpack(buffer, (int)buffer.Length, out unpack);
		operation._parse(unpack, unpack.Length);

		FileStream fs2 = new FileStream("./ground.dat", FileMode.Open, FileAccess.Read);
		buffer = new byte[fs2.Length];
		fs2.Read(buffer, 0, buffer.Length);
		fs2.Close();

		bdll.revent buff = new bdll.revent();
		IntPtr g = bdll.start(buffer);
		bdll.setmanual(g, 1, 1);
		Console.WriteLine("hello:" + g + "operation:" + operation.list.Length + "\n");
		for (;;) {
			int ret = bdll.step(g, ref buff);
			if (ret != 0)
				break;
			switch (buff.type) {
			case 1:
				battle.report.groundinfo ginfo = new battle.report.groundinfo();
				ginfo._parse(buff.ptr, buff.size);
				Console.WriteLine("GroundInfo:" +
						ginfo.mround);
				break;
			case 2:
				break;
			case 5: //wait master
				Console.WriteLine("Size:" + n + " size:" + operation.list.Length);
				Debug.Assert(n < operation.list.Length);
				battle.report.waitmaster wait = new battle.report.waitmaster();
				wait._parse(buff.ptr, buff.size);
				bdll.setskill(g, operation.list[n].id);
				n++;
				break;
			}
		}
		return ;
	}

	
	static void Main(string[] args)
	{
		Console.Write("StartUp:"  + args.Length);
		if (args.Length > 0)
			play(Int32.Parse(args[0]));
		else
			rewind();
	}
}}

