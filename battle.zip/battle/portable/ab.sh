#!/bin/bash
#!/bin/bash
LAST=`git log -n1 ./`

git pull origin
NOW="`git log -n1 ./`"
echo "not equal"
LAST=$NOW

DIR=`date +%F`
mkdir -p "./battle-$DIR/ios/"
mkdir -p "./battle-$DIR/android/"

echo `date +%F %T` > "./battle-$DIR/stamp.txt"
echo $NOW >> "./battle-$DIR/stamp.txt"

echo "++++++++++++++++++++++++++++++++++++++++++++++++++"
echo "Build Iphone..."
make ios
echo "Build Iphone finish..."
echo "Ios:`md5 ios/build/Release-iphoneos/libios.a`" >> "./battle-$DIR/stamp.txt"
cp -v ios/build/Release-iphoneos/libios.a "./battle-$DIR/ios/libbattle.a"
sleep 2
echo "++++++++++++++++++++++++++++++++++++++++++++++++++"
echo "Build Android ..."
make android
echo "Android:`md5 android/libs/armeabi/libbattle.so`" >> "./battle-$DIR/stamp.txt"
cp -v android/libs/armeabi/libbattle.so "./battle-$DIR/android/"
sleep 2
echo "++++++++++++++++++++++++++++++++++++++++++++++++++"
scp -r "./battle-$DIR" root@192.168.2.118:/root/battlelib


