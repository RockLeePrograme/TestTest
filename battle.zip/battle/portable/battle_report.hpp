#ifndef __battle_report_h
#define __battle_report_h
#include "zprotowire.h"
namespace battle {
namespace report {

using namespace zprotobuf;

struct wirepimpl:public wirep {
protected:
        virtual wiretree &_wiretree() const;
};

struct change:public wirepimpl{
        int32_t type = 0;
        int32_t elem = 0;
        int32_t hero = 0;
        int32_t phase = 0;
        int32_t id = 0;
        float value = 0.0f;
protected:
        virtual int _encode_field(struct zproto_args *args) const;
        virtual int _decode_field(struct zproto_args *args);
public:
        virtual void _reset();
        virtual int _tag() const;
        virtual const char *_name() const;
        virtual zproto_struct *_query() const;
        static void _load(wiretree &t);
private:
        static zproto_struct *_st;
};
struct attack:public wirepimpl{
        int32_t atk = 0;
        int32_t skill = 0;
        std::vector<struct change> changes;
protected:
        virtual int _encode_field(struct zproto_args *args) const;
        virtual int _decode_field(struct zproto_args *args);
public:
        virtual void _reset();
        virtual int _tag() const;
        virtual const char *_name() const;
        virtual zproto_struct *_query() const;
        static void _load(wiretree &t);
private:
        static zproto_struct *_st;
};
struct heroinfo:public wirepimpl{
        int32_t pos = 0;
        int32_t hid = 0;
        float troops = 0.0f;
        int32_t master = 0;
        int32_t type = 0;
protected:
        virtual int _encode_field(struct zproto_args *args) const;
        virtual int _decode_field(struct zproto_args *args);
public:
        virtual void _reset();
        virtual int _tag() const;
        virtual const char *_name() const;
        virtual zproto_struct *_query() const;
        static void _load(wiretree &t);
private:
        static zproto_struct *_st;
};
struct groundinfo:public wirepimpl{
        int32_t mround = 0;
        std::vector<struct heroinfo> atk;
        std::vector<struct heroinfo> def;
        std::vector<int32_t> skills;
        int32_t masterpoint0 = 0;
        int32_t masterpoint1 = 0;
protected:
        virtual int _encode_field(struct zproto_args *args) const;
        virtual int _decode_field(struct zproto_args *args);
public:
        virtual void _reset();
        virtual int _tag() const;
        virtual const char *_name() const;
        virtual zproto_struct *_query() const;
        static void _load(wiretree &t);
private:
        static zproto_struct *_st;
};
struct eattack:public wirepimpl{
        std::vector<struct attack> list;
protected:
        virtual int _encode_field(struct zproto_args *args) const;
        virtual int _decode_field(struct zproto_args *args);
public:
        virtual void _reset();
        virtual int _tag() const;
        virtual const char *_name() const;
        virtual zproto_struct *_query() const;
        static void _load(wiretree &t);
private:
        static zproto_struct *_st;
};
struct over:public wirepimpl{
        struct info:public wire {
                int32_t id = 0;
                int32_t hero = 0;
                int32_t phurt = 0;
                int32_t mhurt = 0;
                int32_t heal = 0;
                int32_t troops = 0;
                int32_t hurttroops = 0;
                int32_t maxtroops = 0;
                int32_t arm = 0;
                int32_t level = 0;
        protected:
                virtual int _encode_field(struct zproto_args *args) const;
                virtual int _decode_field(struct zproto_args *args);
        public:
                virtual void _reset();
        };
        int32_t result = 0;
        std::vector<struct info> statistics;
protected:
        virtual int _encode_field(struct zproto_args *args) const;
        virtual int _decode_field(struct zproto_args *args);
public:
        virtual void _reset();
        virtual int _tag() const;
        virtual const char *_name() const;
        virtual zproto_struct *_query() const;
        static void _load(wiretree &t);
private:
        static zproto_struct *_st;
};
struct waitmaster:public wirepimpl{
        int32_t team = 0;
protected:
        virtual int _encode_field(struct zproto_args *args) const;
        virtual int _decode_field(struct zproto_args *args);
public:
        virtual void _reset();
        virtual int _tag() const;
        virtual const char *_name() const;
        virtual zproto_struct *_query() const;
        static void _load(wiretree &t);
private:
        static zproto_struct *_st;
};
struct operation:public wirepimpl{
        struct master:public wire {
                int32_t round = 0;
                int32_t fight = 0;
                int32_t id = 0;
        protected:
                virtual int _encode_field(struct zproto_args *args) const;
                virtual int _decode_field(struct zproto_args *args);
        public:
                virtual void _reset();
        };
        std::vector<struct master> list;
protected:
        virtual int _encode_field(struct zproto_args *args) const;
        virtual int _decode_field(struct zproto_args *args);
public:
        virtual void _reset();
        virtual int _tag() const;
        virtual const char *_name() const;
        virtual zproto_struct *_query() const;
        static void _load(wiretree &t);
private:
        static zproto_struct *_st;
};
struct roundopen:public wirepimpl{
        int32_t round = 0;
protected:
        virtual int _encode_field(struct zproto_args *args) const;
        virtual int _decode_field(struct zproto_args *args);
public:
        virtual void _reset();
        virtual int _tag() const;
        virtual const char *_name() const;
        virtual zproto_struct *_query() const;
        static void _load(wiretree &t);
private:
        static zproto_struct *_st;
};
struct extra:public wirepimpl{
        int32_t type = 0;
        int32_t value = 0;
protected:
        virtual int _encode_field(struct zproto_args *args) const;
        virtual int _decode_field(struct zproto_args *args);
public:
        virtual void _reset();
        virtual int _tag() const;
        virtual const char *_name() const;
        virtual zproto_struct *_query() const;
        static void _load(wiretree &t);
private:
        static zproto_struct *_st;
};
struct award:public wirepimpl{
        struct idcount:public wire {
                int32_t id = 0;
                int32_t count = 0;
        protected:
                virtual int _encode_field(struct zproto_args *args) const;
                virtual int _decode_field(struct zproto_args *args);
        public:
                virtual void _reset();
        };
        std::vector<struct idcount> list;
protected:
        virtual int _encode_field(struct zproto_args *args) const;
        virtual int _decode_field(struct zproto_args *args);
public:
        virtual void _reset();
        virtual int _tag() const;
        virtual const char *_name() const;
        virtual zproto_struct *_query() const;
        static void _load(wiretree &t);
private:
        static zproto_struct *_st;
};
class serializer:public wiretree {
	serializer();
public:
	static serializer &instance();
};

}}
#endif
