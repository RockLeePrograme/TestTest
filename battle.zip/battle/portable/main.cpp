#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include "property.h"
#include "ground.h"
#include "logic.h"

using namespace battle;

int main()
{
	int err;
	ground g;
	db::ground db;
	struct stat st;
	err = stat("./ground.dat", &st);
	if (err == -1) {
		perror("zproto_load:");
		return 0;
	}
	FILE *fp = fopen("./ground.dat", "rb");
	if (fp == NULL) {
		perror("zproto_load:");
		return 0;
	}
	uint8_t *buff = (uint8_t *)malloc(st.st_size + 1);
	err = fread(buff, 1, st.st_size, fp);
	if (err != st.st_size) {
		return 0;
	}
	err = logic::parse(db, buff, st.st_size);
	assert(err > 0);
	logic::start(&g, db);
	while (g.state != STATE_EXIT) {
		logic::step(&g);
	}
	printf("fight ok\n");
	return 0;
}

