using System;
using System.Runtime.InteropServices;
using System.Collections;
using System.Collections.Generic;
#if UNITY_EDITOR
using UnityEngine;
#endif

namespace battle
{
	public class bdll
	{
		private const string DLLNAME = "battle";
		public struct revent {	//report event
			public int type;
			public IntPtr ptr;
			public int size;
		};

		public delegate void log_cb_t(IntPtr str, int sz);

		[DllImport(DLLNAME, EntryPoint = "csbstart", CallingConvention = CallingConvention.Cdecl)]
		public extern static IntPtr csstart(IntPtr buff, int size, log_cb_t cb);

		[DllImport(DLLNAME, EntryPoint = "csbrewind", CallingConvention = CallingConvention.Cdecl)]
		public extern static IntPtr csrewind(IntPtr buff, int size);

		[DllImport(DLLNAME, EntryPoint = "csbstop", CallingConvention = CallingConvention.Cdecl)]
		public extern static void stop(IntPtr g);

		[DllImport(DLLNAME, EntryPoint = "csbinfo", CallingConvention = CallingConvention.Cdecl)]
		public extern static int groundinfo(IntPtr g, ref revent e);

		[DllImport(DLLNAME, EntryPoint = "csbsetskill", CallingConvention = CallingConvention.Cdecl)]
		public extern static int setskill(IntPtr g, int id);

		[DllImport(DLLNAME, EntryPoint = "csbsetmanual", CallingConvention = CallingConvention.Cdecl)]
		public extern static int setmanual(IntPtr g, int team0, int team1);

		[DllImport(DLLNAME, EntryPoint = "csboperation", CallingConvention = CallingConvention.Cdecl)]
		public extern static int operation(IntPtr g, ref revent e);

		[DllImport(DLLNAME, EntryPoint = "csbstep", CallingConvention = CallingConvention.Cdecl)]
		public extern static int step(IntPtr g, ref revent e);

		[DllImport(DLLNAME, EntryPoint = "csbreport", CallingConvention = CallingConvention.Cdecl)]
		public extern static int report(IntPtr g, ref revent e);

		public static void log(IntPtr str, int sz) {
			string s = Marshal.PtrToStringAnsi(str);
			#if UNITY_EDITOR
			Debug.Log(s);
			#else
			Console.WriteLine(s);
			#endif
		}

		public static IntPtr start(byte[] ground) {
			IntPtr g;
			IntPtr buff = Marshal.AllocHGlobal(ground.Length);
			Marshal.Copy(ground, 0, buff, ground.Length);
			g= csstart(buff, ground.Length, log);
			Marshal.FreeHGlobal(buff);
			return g;
		}
		public static IntPtr rewind(byte[] ground) {
			IntPtr g;
			IntPtr buff = Marshal.AllocHGlobal(ground.Length);
			Marshal.Copy(ground, 0, buff, ground.Length);
			g= csrewind(buff, ground.Length);
			Marshal.FreeHGlobal(buff);
			return g;
		}

	}
}

