#include <string.h>
#include "zprotowire.h"
#include "battle_report.hpp"
namespace battle {
namespace report {

using namespace zprotobuf;

wiretree&
wirepimpl::_wiretree() const
{
	return serializer::instance();
}

int
change::_tag() const
{
	return 0x0;
}
const char *
change::_name() const
{
	return "change";
}
struct zproto_struct *change::_st = nullptr;
struct zproto_struct *
change::_query() const
{
	return _st;
}
void
change::_load(wiretree &t)
{
	change::_st = t.query("change");
	assert(change::_st);
}
void
change::_reset()
{
	type = 0;
	elem = 0;
	hero = 0;
	phase = 0;
	id = 0;
	value = 0.0f;

}
int
change::_encode_field(struct zproto_args *args) const
{
	switch (args->tag) {
	case 1:
		return _write(args, type);
	case 2:
		return _write(args, elem);
	case 3:
		return _write(args, hero);
	case 4:
		return _write(args, phase);
	case 5:
		return _write(args, id);
	case 6:
		return _write(args, value);
	default:
		return ZPROTO_ERROR;
	}
}
int
change::_decode_field(struct zproto_args *args) 
{
	switch (args->tag) {
	case 1:
		return _read(args, type);
	case 2:
		return _read(args, elem);
	case 3:
		return _read(args, hero);
	case 4:
		return _read(args, phase);
	case 5:
		return _read(args, id);
	case 6:
		return _read(args, value);
	default:
		return ZPROTO_ERROR;
	}
}
int
attack::_tag() const
{
	return 0x7;
}
const char *
attack::_name() const
{
	return "attack";
}
struct zproto_struct *attack::_st = nullptr;
struct zproto_struct *
attack::_query() const
{
	return _st;
}
void
attack::_load(wiretree &t)
{
	attack::_st = t.query("attack");
	assert(attack::_st);
}
void
attack::_reset()
{
	atk = 0;
	skill = 0;
	changes.clear();

}
int
attack::_encode_field(struct zproto_args *args) const
{
	switch (args->tag) {
	case 1:
		return _write(args, atk);
	case 2:
		return _write(args, skill);
	 case 3:
		 if (args->idx >= (int)changes.size()) {
			 args->len = args->idx;
			 return ZPROTO_NOFIELD;
		 }
		 return changes[args->idx]._encode(args->buff, args->buffsz, args->sttype);
	default:
		return ZPROTO_ERROR;
	}
}
int
attack::_decode_field(struct zproto_args *args) 
{
	switch (args->tag) {
	case 1:
		return _read(args, atk);
	case 2:
		return _read(args, skill);
	 case 3:
		 assert(args->idx >= 0);
		 if (args->len == 0)
			 return 0;
		 changes.resize(args->idx + 1);
		 return changes[args->idx]._decode(args->buff, args->buffsz, args->sttype);
	default:
		return ZPROTO_ERROR;
	}
}
int
heroinfo::_tag() const
{
	return 0x0;
}
const char *
heroinfo::_name() const
{
	return "heroinfo";
}
struct zproto_struct *heroinfo::_st = nullptr;
struct zproto_struct *
heroinfo::_query() const
{
	return _st;
}
void
heroinfo::_load(wiretree &t)
{
	heroinfo::_st = t.query("heroinfo");
	assert(heroinfo::_st);
}
void
heroinfo::_reset()
{
	pos = 0;
	hid = 0;
	troops = 0.0f;
	master = 0;
	type = 0;

}
int
heroinfo::_encode_field(struct zproto_args *args) const
{
	switch (args->tag) {
	case 1:
		return _write(args, pos);
	case 2:
		return _write(args, hid);
	case 3:
		return _write(args, troops);
	case 4:
		return _write(args, master);
	case 5:
		return _write(args, type);
	default:
		return ZPROTO_ERROR;
	}
}
int
heroinfo::_decode_field(struct zproto_args *args) 
{
	switch (args->tag) {
	case 1:
		return _read(args, pos);
	case 2:
		return _read(args, hid);
	case 3:
		return _read(args, troops);
	case 4:
		return _read(args, master);
	case 5:
		return _read(args, type);
	default:
		return ZPROTO_ERROR;
	}
}
int
groundinfo::_tag() const
{
	return 0x1;
}
const char *
groundinfo::_name() const
{
	return "groundinfo";
}
struct zproto_struct *groundinfo::_st = nullptr;
struct zproto_struct *
groundinfo::_query() const
{
	return _st;
}
void
groundinfo::_load(wiretree &t)
{
	groundinfo::_st = t.query("groundinfo");
	assert(groundinfo::_st);
}
void
groundinfo::_reset()
{
	mround = 0;
	atk.clear();
	def.clear();
	skills.clear();
	masterpoint0 = 0;
	masterpoint1 = 0;

}
int
groundinfo::_encode_field(struct zproto_args *args) const
{
	switch (args->tag) {
	case 1:
		return _write(args, mround);
	 case 2:
		 if (args->idx >= (int)atk.size()) {
			 args->len = args->idx;
			 return ZPROTO_NOFIELD;
		 }
		 return atk[args->idx]._encode(args->buff, args->buffsz, args->sttype);
	 case 3:
		 if (args->idx >= (int)def.size()) {
			 args->len = args->idx;
			 return ZPROTO_NOFIELD;
		 }
		 return def[args->idx]._encode(args->buff, args->buffsz, args->sttype);
	case 4:
		assert(args->idx >= 0);
		if (args->idx >= (int)skills.size()) {
			args->len = args->idx;
			return ZPROTO_NOFIELD;
		}
		return _write(args, skills[args->idx]);
	case 5:
		return _write(args, masterpoint0);
	case 6:
		return _write(args, masterpoint1);
	default:
		return ZPROTO_ERROR;
	}
}
int
groundinfo::_decode_field(struct zproto_args *args) 
{
	switch (args->tag) {
	case 1:
		return _read(args, mround);
	 case 2:
		 assert(args->idx >= 0);
		 if (args->len == 0)
			 return 0;
		 atk.resize(args->idx + 1);
		 return atk[args->idx]._decode(args->buff, args->buffsz, args->sttype);
	 case 3:
		 assert(args->idx >= 0);
		 if (args->len == 0)
			 return 0;
		 def.resize(args->idx + 1);
		 return def[args->idx]._decode(args->buff, args->buffsz, args->sttype);
	case 4:
		assert(args->idx >= 0);
		if (args->len == 0)
			return 0;
		skills.resize(args->idx + 1);
		return _read(args, skills[args->idx]);
	case 5:
		return _read(args, masterpoint0);
	case 6:
		return _read(args, masterpoint1);
	default:
		return ZPROTO_ERROR;
	}
}
int
eattack::_tag() const
{
	return 0x2;
}
const char *
eattack::_name() const
{
	return "eattack";
}
struct zproto_struct *eattack::_st = nullptr;
struct zproto_struct *
eattack::_query() const
{
	return _st;
}
void
eattack::_load(wiretree &t)
{
	eattack::_st = t.query("eattack");
	assert(eattack::_st);
}
void
eattack::_reset()
{
	list.clear();

}
int
eattack::_encode_field(struct zproto_args *args) const
{
	switch (args->tag) {
	 case 1:
		 if (args->idx >= (int)list.size()) {
			 args->len = args->idx;
			 return ZPROTO_NOFIELD;
		 }
		 return list[args->idx]._encode(args->buff, args->buffsz, args->sttype);
	default:
		return ZPROTO_ERROR;
	}
}
int
eattack::_decode_field(struct zproto_args *args) 
{
	switch (args->tag) {
	 case 1:
		 assert(args->idx >= 0);
		 if (args->len == 0)
			 return 0;
		 list.resize(args->idx + 1);
		 return list[args->idx]._decode(args->buff, args->buffsz, args->sttype);
	default:
		return ZPROTO_ERROR;
	}
}
void
over::info::_reset()
{
	id = 0;
	hero = 0;
	phurt = 0;
	mhurt = 0;
	heal = 0;
	troops = 0;
	hurttroops = 0;
	maxtroops = 0;
	arm = 0;
	level = 0;

}
int
over::info::_encode_field(struct zproto_args *args) const
{
	switch (args->tag) {
	case 1:
		return _write(args, id);
	case 2:
		return _write(args, hero);
	case 3:
		return _write(args, phurt);
	case 4:
		return _write(args, mhurt);
	case 5:
		return _write(args, heal);
	case 6:
		return _write(args, troops);
	case 7:
		return _write(args, hurttroops);
	case 8:
		return _write(args, maxtroops);
	case 9:
		return _write(args, arm);
	case 10:
		return _write(args, level);
	default:
		return ZPROTO_ERROR;
	}
}
int
over::info::_decode_field(struct zproto_args *args) 
{
	switch (args->tag) {
	case 1:
		return _read(args, id);
	case 2:
		return _read(args, hero);
	case 3:
		return _read(args, phurt);
	case 4:
		return _read(args, mhurt);
	case 5:
		return _read(args, heal);
	case 6:
		return _read(args, troops);
	case 7:
		return _read(args, hurttroops);
	case 8:
		return _read(args, maxtroops);
	case 9:
		return _read(args, arm);
	case 10:
		return _read(args, level);
	default:
		return ZPROTO_ERROR;
	}
}
int
over::_tag() const
{
	return 0x3;
}
const char *
over::_name() const
{
	return "over";
}
struct zproto_struct *over::_st = nullptr;
struct zproto_struct *
over::_query() const
{
	return _st;
}
void
over::_load(wiretree &t)
{
	over::_st = t.query("over");
	assert(over::_st);
}
void
over::_reset()
{
	result = 0;
	statistics.clear();

}
int
over::_encode_field(struct zproto_args *args) const
{
	switch (args->tag) {
	case 1:
		return _write(args, result);
	 case 2:
		 if (args->idx >= (int)statistics.size()) {
			 args->len = args->idx;
			 return ZPROTO_NOFIELD;
		 }
		 return statistics[args->idx]._encode(args->buff, args->buffsz, args->sttype);
	default:
		return ZPROTO_ERROR;
	}
}
int
over::_decode_field(struct zproto_args *args) 
{
	switch (args->tag) {
	case 1:
		return _read(args, result);
	 case 2:
		 assert(args->idx >= 0);
		 if (args->len == 0)
			 return 0;
		 statistics.resize(args->idx + 1);
		 return statistics[args->idx]._decode(args->buff, args->buffsz, args->sttype);
	default:
		return ZPROTO_ERROR;
	}
}
int
waitmaster::_tag() const
{
	return 0x5;
}
const char *
waitmaster::_name() const
{
	return "waitmaster";
}
struct zproto_struct *waitmaster::_st = nullptr;
struct zproto_struct *
waitmaster::_query() const
{
	return _st;
}
void
waitmaster::_load(wiretree &t)
{
	waitmaster::_st = t.query("waitmaster");
	assert(waitmaster::_st);
}
void
waitmaster::_reset()
{
	team = 0;

}
int
waitmaster::_encode_field(struct zproto_args *args) const
{
	switch (args->tag) {
	case 1:
		return _write(args, team);
	default:
		return ZPROTO_ERROR;
	}
}
int
waitmaster::_decode_field(struct zproto_args *args) 
{
	switch (args->tag) {
	case 1:
		return _read(args, team);
	default:
		return ZPROTO_ERROR;
	}
}
void
operation::master::_reset()
{
	round = 0;
	fight = 0;
	id = 0;

}
int
operation::master::_encode_field(struct zproto_args *args) const
{
	switch (args->tag) {
	case 1:
		return _write(args, round);
	case 2:
		return _write(args, fight);
	case 3:
		return _write(args, id);
	default:
		return ZPROTO_ERROR;
	}
}
int
operation::master::_decode_field(struct zproto_args *args) 
{
	switch (args->tag) {
	case 1:
		return _read(args, round);
	case 2:
		return _read(args, fight);
	case 3:
		return _read(args, id);
	default:
		return ZPROTO_ERROR;
	}
}
int
operation::_tag() const
{
	return 0x6;
}
const char *
operation::_name() const
{
	return "operation";
}
struct zproto_struct *operation::_st = nullptr;
struct zproto_struct *
operation::_query() const
{
	return _st;
}
void
operation::_load(wiretree &t)
{
	operation::_st = t.query("operation");
	assert(operation::_st);
}
void
operation::_reset()
{
	list.clear();

}
int
operation::_encode_field(struct zproto_args *args) const
{
	switch (args->tag) {
	 case 1:
		 if (args->idx >= (int)list.size()) {
			 args->len = args->idx;
			 return ZPROTO_NOFIELD;
		 }
		 return list[args->idx]._encode(args->buff, args->buffsz, args->sttype);
	default:
		return ZPROTO_ERROR;
	}
}
int
operation::_decode_field(struct zproto_args *args) 
{
	switch (args->tag) {
	 case 1:
		 assert(args->idx >= 0);
		 if (args->len == 0)
			 return 0;
		 list.resize(args->idx + 1);
		 return list[args->idx]._decode(args->buff, args->buffsz, args->sttype);
	default:
		return ZPROTO_ERROR;
	}
}
int
roundopen::_tag() const
{
	return 0x8;
}
const char *
roundopen::_name() const
{
	return "roundopen";
}
struct zproto_struct *roundopen::_st = nullptr;
struct zproto_struct *
roundopen::_query() const
{
	return _st;
}
void
roundopen::_load(wiretree &t)
{
	roundopen::_st = t.query("roundopen");
	assert(roundopen::_st);
}
void
roundopen::_reset()
{
	round = 0;

}
int
roundopen::_encode_field(struct zproto_args *args) const
{
	switch (args->tag) {
	case 1:
		return _write(args, round);
	default:
		return ZPROTO_ERROR;
	}
}
int
roundopen::_decode_field(struct zproto_args *args) 
{
	switch (args->tag) {
	case 1:
		return _read(args, round);
	default:
		return ZPROTO_ERROR;
	}
}
int
extra::_tag() const
{
	return 0x9;
}
const char *
extra::_name() const
{
	return "extra";
}
struct zproto_struct *extra::_st = nullptr;
struct zproto_struct *
extra::_query() const
{
	return _st;
}
void
extra::_load(wiretree &t)
{
	extra::_st = t.query("extra");
	assert(extra::_st);
}
void
extra::_reset()
{
	type = 0;
	value = 0;

}
int
extra::_encode_field(struct zproto_args *args) const
{
	switch (args->tag) {
	case 1:
		return _write(args, type);
	case 2:
		return _write(args, value);
	default:
		return ZPROTO_ERROR;
	}
}
int
extra::_decode_field(struct zproto_args *args) 
{
	switch (args->tag) {
	case 1:
		return _read(args, type);
	case 2:
		return _read(args, value);
	default:
		return ZPROTO_ERROR;
	}
}
void
award::idcount::_reset()
{
	id = 0;
	count = 0;

}
int
award::idcount::_encode_field(struct zproto_args *args) const
{
	switch (args->tag) {
	case 1:
		return _write(args, id);
	case 2:
		return _write(args, count);
	default:
		return ZPROTO_ERROR;
	}
}
int
award::idcount::_decode_field(struct zproto_args *args) 
{
	switch (args->tag) {
	case 1:
		return _read(args, id);
	case 2:
		return _read(args, count);
	default:
		return ZPROTO_ERROR;
	}
}
int
award::_tag() const
{
	return 0xA;
}
const char *
award::_name() const
{
	return "award";
}
struct zproto_struct *award::_st = nullptr;
struct zproto_struct *
award::_query() const
{
	return _st;
}
void
award::_load(wiretree &t)
{
	award::_st = t.query("award");
	assert(award::_st);
}
void
award::_reset()
{
	list.clear();

}
int
award::_encode_field(struct zproto_args *args) const
{
	switch (args->tag) {
	 case 1:
		 if (args->idx >= (int)list.size()) {
			 args->len = args->idx;
			 return ZPROTO_NOFIELD;
		 }
		 return list[args->idx]._encode(args->buff, args->buffsz, args->sttype);
	default:
		return ZPROTO_ERROR;
	}
}
int
award::_decode_field(struct zproto_args *args) 
{
	switch (args->tag) {
	 case 1:
		 assert(args->idx >= 0);
		 if (args->len == 0)
			 return 0;
		 list.resize(args->idx + 1);
		 return list[args->idx]._decode(args->buff, args->buffsz, args->sttype);
	default:
		return ZPROTO_ERROR;
	}
}
const char *def = "\x63\x68\x61\x6e\x67\x65\x20\x7b\xa\x9\x2e\x74\x79\x70\x65\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x31\x9\x23\xa\x9\x2e\x65\x6c\x65\x6d\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x32\x9\x23\x20\x30\x20\x2d\x2d\x3e\x20\x73\x6b\x69\x6c\x6c\x20\x63\x68\x61\x6e\x67\x65\x2c\x20\x3e\x20\x30\x20\x2d\x2d\x3e\x20\x62\x75\x66\x66\x20\x63\x68\x61\x6e\x67\x65\xa\x9\x2e\x68\x65\x72\x6f\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x33\xa\x9\x2e\x70\x68\x61\x73\x65\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x34\xa\x9\x2e\x69\x64\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x35\x9\x23\x20\x70\x72\x6f\x70\x65\x72\x74\x79\x2e\x68\xa\x9\x2e\x76\x61\x6c\x75\x65\x3a\x66\x6c\x6f\x61\x74\x20\x36\xa\x7d\xa\xa\x61\x74\x74\x61\x63\x6b\x20\x30\x78\x30\x37\x20\x7b\xa\x9\x2e\x61\x74\x6b\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x31\xa\x9\x2e\x73\x6b\x69\x6c\x6c\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x32\xa\x9\x2e\x63\x68\x61\x6e\x67\x65\x73\x3a\x63\x68\x61\x6e\x67\x65\x5b\x5d\x20\x33\xa\x7d\xa\xa\x68\x65\x72\x6f\x69\x6e\x66\x6f\x20\x7b\xa\x9\x2e\x70\x6f\x73\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x31\xa\x9\x2e\x68\x69\x64\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x32\xa\x9\x2e\x74\x72\x6f\x6f\x70\x73\x3a\x66\x6c\x6f\x61\x74\x20\x33\xa\x9\x2e\x6d\x61\x73\x74\x65\x72\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x34\xa\x9\x2e\x74\x79\x70\x65\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x35\xa\x7d\xa\xa\x67\x72\x6f\x75\x6e\x64\x69\x6e\x66\x6f\x20\x30\x78\x30\x31\x20\x7b\xa\x9\x2e\x6d\x72\x6f\x75\x6e\x64\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x31\xa\x9\x2e\x61\x74\x6b\x3a\x68\x65\x72\x6f\x69\x6e\x66\x6f\x5b\x5d\x20\x32\xa\x9\x2e\x64\x65\x66\x3a\x68\x65\x72\x6f\x69\x6e\x66\x6f\x5b\x5d\x20\x33\xa\x9\x2e\x73\x6b\x69\x6c\x6c\x73\x3a\x69\x6e\x74\x65\x67\x65\x72\x5b\x5d\x20\x34\xa\x9\x2e\x6d\x61\x73\x74\x65\x72\x70\x6f\x69\x6e\x74\x30\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x35\xa\x9\x2e\x6d\x61\x73\x74\x65\x72\x70\x6f\x69\x6e\x74\x31\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x36\xa\x7d\xa\xa\x65\x61\x74\x74\x61\x63\x6b\x20\x30\x78\x30\x32\x20\x7b\xa\x9\x2e\x6c\x69\x73\x74\x3a\x61\x74\x74\x61\x63\x6b\x5b\x5d\x20\x31\xa\x7d\xa\xa\x6f\x76\x65\x72\x20\x30\x78\x30\x33\x20\x7b\xa\x9\x69\x6e\x66\x6f\x20\x7b\xa\x9\x9\x2e\x69\x64\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x31\xa\x9\x9\x2e\x68\x65\x72\x6f\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x32\xa\x9\x9\x2e\x70\x68\x75\x72\x74\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x33\xa\x9\x9\x2e\x6d\x68\x75\x72\x74\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x34\xa\x9\x9\x2e\x68\x65\x61\x6c\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x35\xa\x9\x9\x2e\x74\x72\x6f\x6f\x70\x73\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x36\xa\x9\x9\x2e\x68\x75\x72\x74\x74\x72\x6f\x6f\x70\x73\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x37\xa\x9\x9\x2e\x6d\x61\x78\x74\x72\x6f\x6f\x70\x73\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x38\xa\x9\x9\x2e\x61\x72\x6d\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x39\xa\x9\x9\x2e\x6c\x65\x76\x65\x6c\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x31\x30\xa\x9\x7d\xa\x9\x2e\x72\x65\x73\x75\x6c\x74\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x31\xa\x9\x2e\x73\x74\x61\x74\x69\x73\x74\x69\x63\x73\x3a\x69\x6e\x66\x6f\x5b\x5d\x20\x32\xa\x7d\xa\xa\x77\x61\x69\x74\x6d\x61\x73\x74\x65\x72\x20\x30\x78\x30\x35\x20\x7b\xa\x9\x2e\x74\x65\x61\x6d\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x31\xa\x7d\xa\xa\x6f\x70\x65\x72\x61\x74\x69\x6f\x6e\x20\x30\x78\x30\x36\x20\x7b\xa\x9\x6d\x61\x73\x74\x65\x72\x20\x7b\xa\x9\x9\x2e\x72\x6f\x75\x6e\x64\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x31\xa\x9\x9\x2e\x66\x69\x67\x68\x74\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x32\xa\x9\x9\x2e\x69\x64\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x33\xa\x9\x7d\xa\x9\x2e\x6c\x69\x73\x74\x3a\x6d\x61\x73\x74\x65\x72\x5b\x5d\x20\x31\xa\x7d\xa\xa\x72\x6f\x75\x6e\x64\x6f\x70\x65\x6e\x20\x30\x78\x30\x38\x20\x7b\xa\x9\x2e\x72\x6f\x75\x6e\x64\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x31\xa\x7d\xa\xa\x65\x78\x74\x72\x61\x20\x30\x78\x30\x39\x20\x7b\xa\x9\x2e\x74\x79\x70\x65\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x31\xa\x9\x2e\x76\x61\x6c\x75\x65\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x32\xa\x7d\xa\xa\x61\x77\x61\x72\x64\x20\x30\x78\x30\x61\x20\x7b\xa\x9\x69\x64\x63\x6f\x75\x6e\x74\x20\x7b\xa\x9\x9\x2e\x69\x64\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x31\xa\x9\x9\x2e\x63\x6f\x75\x6e\x74\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x32\xa\x9\x7d\xa\x9\x2e\x6c\x69\x73\x74\x3a\x69\x64\x63\x6f\x75\x6e\x74\x5b\x5d\x20\x31\xa\x7d\xa\xa";

serializer::serializer()
	 :wiretree(def)
{
	change::_load(*this);
	attack::_load(*this);
	heroinfo::_load(*this);
	groundinfo::_load(*this);
	eattack::_load(*this);
	over::_load(*this);
	waitmaster::_load(*this);
	operation::_load(*this);
	roundopen::_load(*this);
	extra::_load(*this);
	award::_load(*this);
}
serializer &
serializer::instance()
{
	 static serializer *inst = new serializer();
	 return *inst;
}
}}
