#ifndef _ZPROTO_HPP
#define _ZPROTO_HPP

extern "C" {
#include "zproto.h"
}

#endif

