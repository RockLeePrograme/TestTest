local config = require "config"
local zproto = require "zproto"
local proto = zproto:load("battle.db")

local path = './'

config.parselist {
	path .. 'Skill.xml',
	path .. 'SkillElement.xml'
}

local ground = require "ground"

ground.skills = {}
ground.elements = {}

local function transform_element(elemid)
	local elem = ground.elements[elemid]
	if elem then
		return
	end
	local xml = assert(config.getkey("SkillElement.xml", elemid), elemid)
	elem = {}
	ground.elements[elemid] = elem
	elem.id = xml.ElementID
	elem.bigtype = xml.BigType
	elem.smalltype = xml.SmallType
	elem.formula = xml.Formula
	elem.effecttype = xml.EffectType
	local category = 0
	for _, v in ipairs(xml.BuffCategory) do
		category = category | (1 << v)
	end
	elem.buff = {
		delay = xml.BuffDelay,
		trigger = xml.BuffTrigger,
		invalid = xml.BuffInvalid,
		effecttype = xml.BuffEffectType,
		lastround = xml.BuffLastRound,
		lasttype = xml.BuffLastType,
		overlay = xml.BuffOverlay,
		weight = xml.BuffWeight,
		category = category,
		limittype = xml.BuffLimitType;
		limitparam = xml.BuffLimitParam;
	}
	elem.happentype = xml.HappenType
	elem.happenratio = xml.HappenRatio
	elem.percentdown = xml.PercentDown
	elem.percentup = xml.PercentUp
	elem.valueup = xml.ValueUp
	elem.valuedown = xml.ValueDown
	--[[
	print("element:", elemid)
	for k, v in pairs(elem.buff) do
		print(k, v)
	end
	]]--
end

local function transform_skill(skillid, xml)
	local skill = ground.skills[skillid]
	if skill then
		return
	end
	print("transform skill:", skillid)
	skill = {}
	ground.skills[skillid] = skill
	skill.id = xml.ID
	skill.type = xml.SkillType
	skill.triggerparam1 = xml.TriggerParam1
	skill.triggerparam2 = xml.TriggerParam2
	skill.initparam = xml.InitParam
	skill.cd = xml.SkillCD
	skill.range = xml.SkillRange
	skill.readyround = xml.ReadyRound
	skill.select = {
		faction = xml.SelectFaction,
		range = xml.SelectRange,
		category = xml.SelectCategory,
		count = xml.SelectCount,
	}
	skill.element = xml.Element
	skill.nextskill = xml.NextSkill
	skill.nexthappentype = xml.NextHappenType
	skill.nexthappenratio = xml.NextHappenRatio
	for _, elemid in ipairs(skill.element) do
		transform_element(elemid)
	end
	local nextskill = skill.nextskill
	if nextskill ~= 0 then
		local xml = config.getkey("Skill.xml", nextskill)
		assert(xml, nextskill)
		transform_skill(nextskill, xml)
	end
end

local function transform_team(heros)
	for _, hero in ipairs(heros) do
		local conflict = {}
		for _, skillid in ipairs(hero.skills) do
			local xml = config.getkey("Skill.xml", skillid)
			assert(xml, skillid)
			if xml.SkillConflict ~= 0 then
				local s = conflict[xml.SkillConflict]
				if not (s and s.ConflictWeight > xml.ConflictWeight) then
					conflict[xml.SkillConflict] = xml
				end
			else
				transform_skill(skillid, xml)
			end
		end
		for _, v in pairs(conflict) do
			transform_skill(v.ID, v)
		end
	end
end

transform_team(ground.attacker)
transform_team(ground.defender)

local dat = proto:encode("ground", ground)
local pack = proto:pack(dat)
local f = io.open("ground.dat", "wb")
f:write(pack)
f:close()
print("generate ok origin size:", #dat, " pack size:", #pack)

