#include "ground.h"
#include "hero.h"
#include "property.h"
#include "buff.h"
#include "heal.h"
#include "auxiliary.h"
#include "portable/battle_report.hpp"

namespace battle {
namespace heal {

static inline float
evalval(struct ground *g, struct herost *atk, struct herost *def,
		const db::element *elem)
{
	float hp, prop, hurthp, amplify, real;
	float percent = g->rand.IRandom(elem->percentdown, elem->percentup);
	hp = atk->maxtroops / 20 * percent / PERCENT100;
	switch (elem->formula) {
	case FORMULA_HEAL1:
		prop = hero::propget(atk, PROP_DEFENCE);
		hp += hp * prop / 200.f;
		break;
	case FORMULA_HEAL2:
		prop = hero::propget(atk, PROP_INTELLIGENCE);
		hp += hp * prop / 200.f;
		break;
	case FORMULA_HEAL3:
		prop = 0.0f;
		break;
	default:
		prop = 0.0f;
		break;
	}
	amplify = hero::propget(atk, PROP_HEALAMPLIFY);
	amplify += hero::propget(def, PROP_R_HEALAMPLIFY);
	amplify -= hero::propget(def, PROP_HEALREDUCE);
	amplify = std::max(100.0f, amplify + PERCENT100);
	hp = hp * amplify / PERCENT100;
	hurthp = hero::propget(def, PROP_HURTTROOPS);
	real = std::min(hp, hurthp);
	DPRINT(g, "[heal] atk pos:%d percent:%.2f formula:%d"
			"prop:%.2f healhp:%f hurthp:%f final:%f\n",
			atk->pos, percent, elem->formula,
			prop, hp, hurthp, real);
	return real;
}


float
eval(struct ground *g, struct herost *atk, struct herost *def,
		const db::element *elem)
{
	float hp;
	if (!buff::healinvalid(g, def)) {
		float real = evalval(g, atk, def, elem);
		hp = hero::propadd(def, PROP_TROOPS, real);
		hero::propsub(def, PROP_HURTTROOPS, real);
		atk->statistics.heal += hp;
	} else {
		hp = 0.0f;
		DPRINT(g, "[heal] atk pos:%d def pos:%d has heal invalid\n",
				atk->pos, def->pos);
	}
	buff::takeoff(g, def, TAKEOFF_HEALEDCLOSE);
	buff::takeoff(g, atk, TAKEOFF_HEALCLOSE);
	return hp;
}


void
perform(struct ground *g, struct herost *atk, struct herost *def,
		const db::element *elem)
{
	eval(g, atk, def, elem);
	auxiliary::pushchange(g, CHANGE_SKILL, elem->id, def->id,
		PROP_TROOPS, hero::propget(def, PROP_TROOPS), 0);
	return ;
}


}}


