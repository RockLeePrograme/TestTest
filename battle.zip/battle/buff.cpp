#include "ground.h"
#include "property.h"
#include "skill.h"
#include "hero.h"
#include "heal.h"
#include "hurt.h"
#include "buff.h"
#include "auxiliary.h"
#include "portable/battle_report.hpp"

namespace battle {
namespace buff {

enum special {
	SPECIAL_WARCRY = 2,		//嘲讽
	SPECIAL_OOC = 3,		//暴走
	SPECIAL_HP = 4,			//回春术
	SPECIAL_HURT = 5,		//持续伤害
	SPECIAL_BURN = 6,		//燃烧
	SPECIAL_COLD = 7,		//寒冷
	SPECIAL_POISON = 8,		//中毒
	SPECIAL_HURTSHARE = 9,		//援护
	SPECIAL_HURTAROUND = 11,	//分兵
	SPECIAL_NORMALTWICE = 12,	//连续普攻两次
	SPECIAL_CTRLINVALID = 13,	//洞察
	SPECIAL_HURTINVALID = 14,	//规避
	SPECIAL_HEALINVALID = 15,	//禁疗
	SPECIAL_DIZZY = 16,		//眩晕
	SPECIAL_SILENCE = 17,		//沉默
	SPECIAL_BANNORMAL = 18,		//缴械（禁止普攻）
};

static void
lostspecial(struct ground *g, struct herost *owner, buffst &b)
{
	auto &e = b.elem;
	DPRINT(g, "[buff] take special causer:%d owner:%d smalltype:%d\n",
			b.causer->pos, owner->pos, e->smalltype);
	int n = b.ud.n; //trigger times
	switch (e->smalltype) {
	case SPECIAL_DIZZY:	// 16 眩晕
		hero::bandec(owner, SKILL_MASTER, n);	//1 指挥官
		hero::bandec(owner, SKILL_ACTIVE, n);	//2 主动技能
		hero::bandec(owner, SKILL_NORMAL, n);	//3 普通攻击
		hero::bandec(owner, SKILL_COUNTER, n);	//7 反击技能
		hero::statusdec(owner, HERO_DIZZY, n);
		break;
	case SPECIAL_OOC:	//3 暴走
		hero::statusdec(owner, HERO_OOC, n);	//暴走
		break;
	case SPECIAL_SILENCE:	// 17 沉默
		hero::bandec(owner, SKILL_MASTER, n);	//1 指挥官
		hero::bandec(owner, SKILL_ACTIVE, n);	//2 主动技能
		hero::statusdec(owner, HERO_SILENCE, n);
		break;
	case SPECIAL_BANNORMAL: // 18 普攻
		hero::bandec(owner, SKILL_NORMAL, n);	//3 普攻
		hero::statusdec(owner, HERO_BANNORMAL, n);
		break;
	case SPECIAL_HURT:	//持续伤害
	case SPECIAL_BURN:	//燃烧
		hero::statusdec(owner, HERO_BURN, n);
		break;
	case SPECIAL_COLD:	//寒冷
		hero::statusdec(owner, HERO_COLD, n);
		break;
	case SPECIAL_POISON:	//中毒
		hero::statusdec(owner, HERO_POISON, n);
		break;
	case SPECIAL_NORMALTWICE: //连续普攻两次
		hero::statusdec(owner, HERO_NORMALTWICE, n);
		break;
	case SPECIAL_CTRLINVALID: //控制无效
		hero::statusdec(owner, HERO_CTRLINVALID, n);
		break;
	case SPECIAL_HURTINVALID: //伤害无效
		hero::statusdec(owner, HERO_HURTINVALID, n);
		break;
	case SPECIAL_HEALINVALID: //治疗无效
		hero::statusdec(owner, HERO_HEALINVALID, n);
		break;
	case SPECIAL_WARCRY: //嘲讽
		owner->buff.unique.erase(UNIQUE_WARCRY);
		break;
	case SPECIAL_HURTSHARE: //援护
		owner->buff.unique.erase(UNIQUE_HURTSHARE);
		break;
	case SPECIAL_HURTAROUND: //分兵
		owner->buff.unique.erase(UNIQUE_HURTAROUND);
		break;
	default:
		DPRINT(g, "[buff] lost special unknow type:%d\n", e->smalltype);
	}
	return ;
}

static void
losteffect(struct ground *g, struct herost *owner, buffst &b)
{
	float val;
	struct herost *causer;
	enum property prop;
	auto &e = b.elem;
	(void)val;
	switch (e->bigtype) {
	case BIG_BUFFPROP:	//属性类
		prop = (enum property)e->smalltype;
		val = hero::propsub(owner, prop, b.ud.f);
		DPRINT(g, "[buff] lost prop owner:%d prop:%d value:%f final:%f\n",
			owner->pos, e->smalltype, b.ud.f, val);
		break;
	case BIG_BUFFSTEAL:
		causer = b.causer;
		prop = (enum property)e->smalltype;
		hero::propadd(owner, prop, b.ud.f);
		hero::propsub(causer, prop, b.ud.f);
		DPRINT(g, "[buff] lost steal causer:%d owner:%d prop:%d final:%f\n",
			causer->pos, owner->pos, e->smalltype, b.ud.f);
		break;
	case BIG_SPECIAL:
		lostspecial(g, owner, b);
		break;
	default:
		DPRINT(g, "[buff] lost effect unkonw big type:%d\n", e->bigtype);
		break;
	}
	return ;
}

static void
takeoffreal(struct ground *g, struct herost *owner, buffst &b,
		int phase, int type = CHANGE_DETACH)
{
	auto &e = b.elem;
	if (e->buff.overlay == 0 && e->buff.overcount != 0) {
		auto &overlay = owner->buff.overlaycount;
		auto iter = overlay.find(e->id);
		if (iter != overlay.end() && --iter->second <= 0)
			overlay.erase(iter);
	}
	losteffect(g, owner, b);
	auxiliary::pushchange(g, type, b.buffid, owner->id, 0, 0.f, phase);
	return ;
}

static void
triggerspecial(struct ground *g, struct herost *owner, buffst &b, int phase)
{
	float f;
	struct herost *causer;
	auto &e = b.elem;
	(void)f;
	b.ud.n++; //trigger times
	switch(e->smalltype) {
	case SPECIAL_HP: { //回春术
		causer = b.causer;
		f = heal::eval(g, causer, owner, e);
		float troops = hero::propget(owner, PROP_TROOPS);
		auxiliary::pushchange(g, CHANGE_BUFF, b.buffid, owner->id,
			PROP_TROOPS, troops, phase);
		DPRINT(g, "[buff] causer pos:%d owner pos:%d 2-%d :%.3f A:%.3f\n",
			causer->pos, owner->pos, e->smalltype, f, troops);
		break;}
	case SPECIAL_HURT:	//持续伤害
	case SPECIAL_BURN:	//燃烧
		hero::statusincr(owner, HERO_BURN);
		goto hurt;
	case SPECIAL_COLD:	//寒冷
		hero::statusincr(owner, HERO_COLD);
		goto hurt;
	case SPECIAL_POISON: 	//中毒
		hero::statusincr(owner, HERO_POISON);
		hurt:{
		causer = b.causer;
		f = hurt::eval(g, causer, owner, e);
		int id = owner->id;
		float troops = hero::propget(owner, PROP_TROOPS);
		auxiliary::pushchange(g, CHANGE_BUFF, b.buffid, id,
			PROP_TROOPS, troops, phase);
		DPRINT(g, "[buff] causer pos:%d def pos:%d 2-%d :%f\n",
			causer->pos, owner->pos, e->smalltype, f);
		break;}
	case SPECIAL_DIZZY:	// 16 眩晕
		skill::songclear(g, owner);
		hero::banincr(owner, SKILL_MASTER);	//1 指挥官
		hero::banincr(owner, SKILL_ACTIVE);	//2 主动技能
		hero::banincr(owner, SKILL_NORMAL);	//3 普通攻击
		hero::banincr(owner, SKILL_COUNTER);	//7 反击技能
		hero::statusincr(owner, HERO_DIZZY);
		break;
	case SPECIAL_OOC:	//3 暴走
		hero::statusincr(owner, HERO_OOC);	//暴走
		break;
	case SPECIAL_SILENCE:	// 17 沉默
		skill::songclear(g, owner);
		hero::banincr(owner, SKILL_MASTER);	//1 指挥官
		hero::banincr(owner, SKILL_ACTIVE);	//2 主动技能
		hero::statusincr(owner, HERO_SILENCE);
		break;
	case SPECIAL_BANNORMAL: // 18 普攻
		hero::banincr(owner, SKILL_NORMAL);	//3 普攻
		hero::statusincr(owner, HERO_BANNORMAL);
		break;
	case SPECIAL_NORMALTWICE: //连续普攻两次
		hero::statusincr(owner, HERO_NORMALTWICE);
		break;
	case SPECIAL_CTRLINVALID: //控制无效
		hero::statusincr(owner, HERO_CTRLINVALID);
		break;
	case SPECIAL_HURTINVALID: //伤害无效
		hero::statusincr(owner, HERO_HURTINVALID);
		break;
	case SPECIAL_HEALINVALID: //治疗无效
		hero::statusincr(owner, HERO_HEALINVALID);
		break;
	case SPECIAL_WARCRY: //嘲讽
		owner->buff.unique[UNIQUE_WARCRY] = b.buffid;
		break;
	case SPECIAL_HURTSHARE: //援护
		owner->buff.unique[UNIQUE_HURTSHARE] = b.buffid;
		break;
	case SPECIAL_HURTAROUND: //分兵
		owner->buff.unique[UNIQUE_HURTAROUND] = b.buffid;
		break;
	}
}

static inline void
triggereffect(struct ground *g, struct herost *owner, buffst &b, int phase)
{
	struct herost *causer;
	float f, percent, value;
	enum property prop;
	auto &e = b.elem;
	switch (e->bigtype) {
	case BIG_BUFFPROP:	//属性类
		prop = (enum property)e->smalltype;
		value = g->rand.IRandom(e->valuedown, e->valueup);
		percent = g->rand.IRandom(e->percentdown, e->percentup);
		if (e->effecttype == EFFECT_DEBUFF) {
			percent = percent;
			value = value;
			f = -hero::propsub(owner, prop, value, percent);
			b.ud.f += f;
		} else {
			f = hero::propadd(owner, prop, value, percent);
			b.ud.f += f;
		}
		auxiliary::pushchange(g, CHANGE_BUFF, b.buffid, owner->id,
				prop, f, phase);
		DPRINT(g, "[buff] prop prop:%d percent:%f value:%f final:%f\n",
				e->smalltype, percent, value, b.ud.f);
		break;
	case BIG_BUFFSTEAL:
		causer = b.causer;
		prop = (enum property)e->smalltype;
		value = g->rand.IRandom(e->valuedown, e->valueup);
		percent = g->rand.IRandom(e->percentdown, e->percentup);
		f = hero::propsub(owner, prop, value, percent);
		hero::propadd(causer, prop, f);
		b.ud.f += f;
		auxiliary::pushchange(g, CHANGE_BUFF, b.buffid, owner->id,
				prop, -f, phase);
		auxiliary::pushchange(g, CHANGE_BUFF, b.buffid, causer->id,
				prop, f, phase);
		DPRINT(g, "[buff] steal prop:%d percent:%f value:%f final:%f\n",
				e->smalltype, percent, value, b.ud.f);
		break;
	case BIG_SPECIAL:
		triggerspecial(g, owner, b, phase);
		break;
	default:
		DPRINT(g, "[buff] take effect unkonw big type:%d\n", e->bigtype);
		break;
	}
}

static inline struct buffst *
uniquebuff(struct ground *g, struct herost *h, enum uniquebuff type)
{
	(void)g;
	auto &unique = h->buff.unique;
	auto iter = unique.find(type);
	if (iter == unique.end())
		return nullptr;
	auto &pool = h->buff.pool;
	auto biter = pool.find(iter->second);
	if (biter == pool.end()) { //already detatch
		unique.erase(iter);
		return nullptr;
	}
	return &biter->second;
}

static inline void
replace(struct ground *g, struct herost *def, const db::element *elem, int buffid)
{
	int category = elem->buff.overlay;
	auto &n = def->buff.category[category];
	if (n == 0) {
		n = buffid;
		return ;
	}
	auto iter = def->buff.pool.find(n);
	if (iter == def->buff.pool.end()) { //already detatch
		n = buffid;
		return ;
	}
	auto &oldbuff = iter->second;
	if (elem->buff.trigger == BUFF_UNMOUNT)
		triggereffect(g, def, oldbuff, BUFF_UNMOUNT);
	takeoffreal(g, def, oldbuff, 0, CHANGE_DETACHREPLACE);
	def->buff.pool.erase(iter);
	n = buffid;
	return ;
}

static int
attach_(struct ground *g, int buffid, struct herost *atk, struct herost *def,
		const db::element *elem)
{
	int trigger, invalid;
	if (elem->buff.overlay == 0) {
		if (elem->buff.overcount > 0) {
			int &n = def->buff.overlaycount[elem->id];
			if (n >= elem->buff.overcount)
				return 0;
			++n;
		}
	} else {
		replace(g, def, elem, buffid);
	}
	DPRINT(g, "[buff] attach elem:%d overlay:%d atk pos:%d def pos:%d"
		" replace:%d buffid:%d\n", elem->id, elem->buff.overlay,
		atk->pos, def->pos, 1, buffid);
	auto &buffs = def->buff.pool;
	auto &buff = buffs[buffid];
	buff.buffid = buffid;
	buff.causer = atk;
	buff.owner = def;
	buff.elem = elem;
	buff.ud.n = 0;
	buff.lastround = elem->buff.lastround;
	trigger = elem->buff.trigger;
	switch (trigger) {
	case 0:
		break;
	case BUFF_MOUNT: //立即生效
		triggereffect(g, def, buff, BUFF_MOUNT);
		break;
	case BUFF_UNMOUNT: //do nothing
		break;
	default: {
		auto &spec = def->buff.trigger[trigger];
		spec.push_back(buffid);
		break;}
	}
	invalid = elem->buff.invalid;
	switch (trigger) {
	case BUFF_MOUNT: //do nothing
	case BUFF_UNMOUNT:
	case 0:
		break;
	default: {
		auto &spec = def->buff.invalid[invalid];
		spec.push_back(buffid);
		break;}
	}
	auto &takeoff = def->buff.takeoff[elem->buff.lasttype];
	takeoff.push_back(buffid);
	return buffid;
}



void
attach(struct ground *g, struct herost *atk, struct herost *def,
		const db::element *elem)
{
 	int delay = elem->buff.delay;
	if (delay == 0) {
		int buffid = attach_(g, ++g->buffidx, atk, def, elem);
		if (buffid != 0) {
			auxiliary::pushchange(g, CHANGE_ATTACH, elem->id,
				def->id, buffid, 0.0f, 0);
		}
	} else {
		int buffid = ++g->buffidx;
		auto &shadow = g->shadowbuffs[g->round + delay];
		shadow.emplace_back(buffid, atk, def, elem);
		auxiliary::pushchange(g, CHANGE_ATTACHDELAY, elem->id,
				def->id, buffid, 0.0f, 0);
	}
	DPRINT(g, "[buff] attach atk:%d def:%d elem:%d delay:%d\n",
			atk->pos, def->pos, elem->id, delay);
	return ;
}

void
shadowless(struct ground *g, int phase)
{
	auto &shadows = g->shadowbuffs;
	auto iter = shadows.find(g->round);
	if (iter == shadows.end())
		return ;
	for (auto &s:iter->second) {
		if (hero::isdead(s.atk))
			continue;
		if (hero::isdead(s.def))
			continue;
		attach_(g, s.buffid, s.atk, s.def, s.elem);
		auxiliary::pushchange(g, CHANGE_ATTACHREAL, 0,
				0, s.buffid, 0.0f, phase);
	}
	return ;
}

void detach(struct ground *g, struct herost *def, const db::element *elem)
{
	int count = 0;
	int max = elem->valuedown;
	auto &pool = def->buff.pool;
	for (auto it = pool.begin(); it != pool.end(); ) {
		auto &b = it->second;
		if (b.elem->buff.category & elem->buff.category) {
			DPRINT(g, "[buff] detach hero:%d buffid:%d\n",
				def->pos, b.buffid);
			takeoffreal(g, def, b, 0);
			it = pool.erase(it);
			if (++count >= max) {
				DPRINT(g, "[buff] detach reach max:%d\n",max);
				break;
			}
		} else {
			++it;
		}
	}
}

static inline void
trigger_effect(struct ground *g, struct herost *h,
		enum bufftrigger phase, int exclude)
{
	static int reentry = 0;
	if (reentry != 0)
		return ;
	auto &trigger = h->buff.trigger;
	auto titer = trigger.find(phase);
	if (titer == trigger.end()) // has no buff
		return ;
	auto &set = titer->second;
	auto &buffpool = h->buff.pool;
	reentry = 1;
	for (auto it = set.begin(); it != set.end(); ) {
		bool ok;
		enum herostatus limite;
		int n, buffid = *it;
		auto biter = buffpool.find(buffid);
		if (biter == buffpool.end()) { //alread detach
			DPRINT(g, "[buff] trigger_effect event:%d pos:%d"
				" buff:%d invalidate\n",
				phase, h->pos, buffid);
			it = set.erase(it);
			continue;
		}
		++it;
		auto &b = biter->second;
		auto &e = b.elem;
		if (e->id == exclude)
			continue;
		int limitn = e->buff.limittype;
		switch (limitn) {
		case 0: //must
			ok = true;
			break;
		case 1: //概率触发
			n = g->rand.IRandom(0, PERCENT100);
			ok = n < e->buff.limitparam;
			break;
		default:
			limite = (enum herostatus)limitn;
			ok = hero::statusget(h, limite) > 0;
			break;
		}
		DPRINT(g, "[buff] trigger_effect event:%d pos:%d "
			"buff id:%d elem:%d limittype:%d n:%d ok:%d\n",
			phase, h->pos, buffid, e->id, limitn, e->buff.limitparam, ok);
		if (ok != true)
			continue;
		triggereffect(g, h, b, phase);
	}
	reentry = 0;
	return ;
}

static inline void
trigger_invalid(struct ground *g, struct herost *h, enum bufftrigger phase)
{
	auto &invalid = h->buff.invalid;
	auto titer = invalid.find(phase);
	if (titer == invalid.end()) // has no buff
		return ;
	auto &set = titer->second;
	auto &buffpool = h->buff.pool;
	for (auto it = set.begin(); it != set.end(); ) {
		int buffid = *it;
		auto biter = buffpool.find(buffid);
		if (biter == buffpool.end()) { //alread detach
			DPRINT(g, "[buff] trigger_invalid event:%d pos:%d"
				" buff:%d already detach\n",
				phase, h->pos, buffid);
			it = set.erase(it);
			continue;
		}
		++it;
		auto &b = biter->second;
		losteffect(g, h, b);
		//clear buff dirty data
		b.ud.n = 0;
		DPRINT(g, "[buff] trigger_invalid event:%d pos:%d "
			"buff id:%d elem:%d\n",
			phase, h->pos, buffid, b.elem->id);
	}
	return ;

}


void
trigger(struct ground *g, struct herost *h, enum bufftrigger phase, int exclude)
{
	trigger_effect(g, h, phase, exclude);
	trigger_invalid(g, h, phase);
	return ;
}

void
takeoff(struct ground *g, struct herost *h, enum bufftakeoff phase)
{
	auto iter = h->buff.takeoff.find(phase);
	if (iter == h->buff.takeoff.end())
		return ;
	auto &set = iter->second;
	auto &buffpool = h->buff.pool;
	for (auto it = set.begin(); it != set.end(); ) {
		int buffid = *it;
		auto biter = buffpool.find(buffid);
		// buff may be 'replace', so alway check if it exist
		if (biter == buffpool.end()) {
			it = set.erase(it);
			DPRINT(g, "[buff] trigger event:%d pos:%d"
				" buff:%d invalidate\n",
				phase, h->pos, buffid);
			continue;
		}
		auto &b = biter->second;
		DPRINT(g, "[buff] takeoff pos:%d event:%d buff:%d last:%d\n",
			h->pos, phase, b.elem->id, b.lastround);
		if (--b.lastround <= 0) {
			if (b.elem->buff.trigger == BUFF_UNMOUNT)
				triggereffect(g, h, b, BUFF_UNMOUNT);
			takeoffreal(g, h, b, phase);
			buffpool.erase(biter);
			DPRINT(g, "[buff] detach elem:%d buffid:%d\n",
				b.elem->id, buffid);
			it = set.erase(it);
		} else {
			++it;
		}
	}
	return ;
}

void
dead(struct ground *g, struct herost *h)
{
	auto &buff = h->buff;
	auto &pool = buff.pool;
	DPRINT(g, "[buff] hero pos:%d dead detach all\n", h->pos);
	for (auto it = pool.begin(); it != pool.end(); ) {
		auto &b = it->second;
		if (b.elem->bigtype == BIG_BUFFSTEAL)
			losteffect(g, h, b);
		it = pool.erase(it);
	}
	buff.category.clear();
	buff.trigger.clear();
	buff.takeoff.clear();
}


static inline bool
ctrlinvalid(struct ground *g, struct herost *h)
{
	return hero::statusget(h, HERO_CTRLINVALID); //控制无效
}

int
banget(struct ground *g, struct herost *h, int type)
{
	if (ctrlinvalid(g, h))
		return 0;
	return hero::banget(h, type);	//2大类 1 小类
}

const struct buffst *
warcry(struct ground *g, struct herost *h) //嘲讽
{
	if (ctrlinvalid(g, h)) {
		DPRINT(g, "warcry:ctrlinvalid\n");
		return nullptr;
	}
	return uniquebuff(g, h, UNIQUE_WARCRY); //2大类，2小类，为嘲讽
}

struct buffst *
hurtshare(struct ground *g, struct herost *h)
{
	return uniquebuff(g, h, UNIQUE_HURTSHARE); //2大类 9小类 伤害分摊
}

static inline void
hurt(struct ground *g, struct herost *atk, struct herost *h, struct buffst *buff)
{
	auto e = buff->elem;
	float hp = hurt::eval(g, atk, h, e);
	(void)hp;
	DPRINT(g, "[buff] hurt around atk:%d target:%d hurt:%f\n",
		atk->pos, h->pos, hp);
	auto it = g->eattack.list.begin();
	if (it == g->eattack.list.end())
		return;
	float f = hero::propget(h, PROP_TROOPS);
	auxiliary::pushchange(g, CHANGE_BUFF, buff->buffid, h->id,
			PROP_TROOPS, f, 0);
	return ;
}

void
hurtaround(struct ground *g, struct herost *atk, struct herost *def) //分兵
{
	int pos, start, end;
	struct herost *h;
	struct buffst *buff;
	buff = uniquebuff(g, atk, UNIQUE_HURTAROUND); //2大类， 11小类 分兵
	if (buff == nullptr)
		return ;
	if (def->pos < ONE_TEAM) {
		start = 0;
		end = ONE_TEAM;
	} else {
		start = ONE_TEAM;
		end = TWO_TEAM;
	}
	pos = def->pos + 1;
	if (pos < end && (h = g->heros[pos]) && (!hero::isdead(h))) {
		hurt(g, atk, h, buff);
		return ;
	}
	pos = def->pos - 1;
	if (pos >= start && (h = g->heros[pos]) && (!hero::isdead(h)))
		hurt(g, atk, h, buff);
	return ;
}

bool
ooc(struct ground *g, struct herost *h)	//out of control
{
	if (ctrlinvalid(g, h))
		return false;
	return hero::statusget(h, HERO_OOC) > 0; //2大类， 3小类，暴走
}


bool
normaltwice(struct ground *g, struct herost *h)
{
	//连续普攻两次
	return hero::statusget(h, HERO_NORMALTWICE);
}


bool
hurtinvalid(struct ground *g, struct herost *h)
{
	//规避
	return hero::statusget(h, HERO_HURTINVALID);
}

bool
healinvalid(struct ground *g, struct herost *h)
{
	//禁疗
	return hero::statusget(h, HERO_HEALINVALID);
}


}}


