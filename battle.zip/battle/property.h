#ifndef _BATTLE_PROPERTY_H
#define _BATTLE_PROPERTY_H


namespace battle {

const float PERCENT100 = 1000.f;

enum arm {
	ARM_INFANTRY = 1,	//步兵
	ARM_CAVALRY = 2,	//骑兵
	ARM_ARCHER = 3,		//弓兵
};

enum herotype {
	HERO = 1,
	MONSTER = 2,
};

enum property : int {
	PROP_INVALID = 0,

	PROP_INTELLIGENCE = 111,	//智慧
	PROP_STRENGTH = 112,		//武力
	PROP_DEFENCE = 113,		//防御
	PROP_TROOPS = 114,		//兵力
	PROP_SPEED = 115,		//速度
	PROP_ATKCITY = 116,		//攻城值

	PROP_HURTRATIO	= 131,		//伤兵系数
	PROP_MOVESPEED = 132,		//移动速度
	PROP_HURTTROOPS = 133,		//受伤兵力

	PROP_MASTEPOINT = 142,		//额外需要指挥点
	PROP_PHYAMPLIFY = 143,		//物伤加成
	PROP_PHYREDUCE = 144,		//物伤减免
	PROP_R_PHYAMPLIFY = 145,	//反方向物伤加成
	PROP_R_PHYREDUCE = 146,		//反方向物伤减免
	PROP_MAGICAMPLIFY = 147,	//攻击者法伤加成
	PROP_MAGICREDUCE = 148,		//攻击者法伤减免
	PROP_R_MAGICAMPLIFY = 149,	//反方向法伤加成
	PROP_R_MAGICREDUCE = 150,	//反方向法伤减免
	PROP_DAMAGEAMPLIFY = 151,	//攻击者伤害加成
	PROP_DAMAGEREDUCE = 152,	//攻击者伤害减免
	PROP_R_DAMAGEAMPLIFY = 153,	//反方向伤害加成
	PROP_R_DAMAGEREDUCE = 154,	//反方向伤害减免
	PROP_HEALAMPLIFY = 155,		//攻击者治愈加成
	PROP_R_HEALAMPLIFY = 156,	//反方向治愈加成
	PROP_HEALREDUCE = 157,		//治愈减免

	PROP_FEEDBACK = 158,		//伤害反弹
	PROP_VAMPIRE = 159,		//吸血
	PROP_ACTIVERATIO = 160,		//主动技能触发概率

	PROP_HURTARCHER = 201,		//克弓
	PROP_DEFARCHER = 202,		//抗弓
	PROP_HURTPIKE = 203,		//克枪
	PROP_DEFPIKE = 204,		//抗枪
	PROP_HURTCAVALRY = 205,		//克骑
	PROP_DEFCAVALRY = 206,		//抗骑

	PROP_HURTHUMAN = 301,		//克人类
	PROP_DEFHUMAN = 302,		//抗人类
	PROP_HURTELF = 303,		//克精灵
	PROP_DEFELF = 304,		//抗精灵
	PROP_HURTORC = 305,		//克兽人
	PROP_DEFORC = 306,		//抗兽人

	//custom event
	PROP_MASTER = 1001,		//指挥点
};

}

#endif

