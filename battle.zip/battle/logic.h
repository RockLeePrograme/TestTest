#ifndef _BATTLE_LOGIC_H
#define _BATTLE_LOGIC_H
#include "ground.h"
#include "portable/battle_report.hpp"

namespace battle {
namespace logic {

void start(struct ground *g, log_cb_t log);
int rewind(struct ground *g, const uint8_t *ptr, int size);
int getreport(struct ground *g, const uint8_t **ptr);
int setskill(struct ground *g, int id);
int setmanual(struct ground *g, int team0, int team1);
enum ctrl step(struct ground *g);

int parse(db::ground &ground, const uint8_t *buff, int size);
int serialize(db::ground &ground, std::string &data);

}}


#endif

