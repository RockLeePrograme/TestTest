#ifndef _BATTLE_SELECTOR_H
#define _BATTLE_SELECTOR_H

#include "ground.h"

namespace battle {
namespace selector {

struct sel {
	int count;
	struct herost *heros[TWO_TEAM];
};

void select(struct ground *g, struct herost *performer,
		const db::skill *skill, struct sel *sel);

int distance(struct herost *a, struct herost *b);

}}


#endif

