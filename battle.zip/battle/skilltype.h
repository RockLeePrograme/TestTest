#ifndef _BATTLE_SKILL_TYPE_H
#define _BATTLE_SKILL_TYPE_H

enum skilltype : int {
	SKILL_MASTER = 1,	//指挥官
	SKILL_ACTIVE = 2,	//主动技能
	SKILL_NORMAL = 3,	//普通攻击
	SKILL_PASSIVE = 4,	//被动技能
	SKILL_STRATEGY = 5,	//战术技能
	SKILL_CHASE = 6,	//追击技能
	SKILL_COUNTER = 7,	//反击技能
	SKILL_OPEN = 8,		//开场技能
};

#endif

