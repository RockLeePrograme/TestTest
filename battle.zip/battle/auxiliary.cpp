#include <algorithm>
#include "ground.h"
#include "hero.h"
#include "property.h"
#include "auxiliary.h"


namespace battle {
namespace auxiliary {

int
aliveshrink(struct herost *heros[], int size)
{
	struct herost **l = heros;
	struct herost **p = heros;
	for (int i = 0; i < size; i++) {
		struct herost *h = *l++;
		if (hero::isdead(h))
			continue;
		*p++ = h;
	}
	return p - heros;;
}

int
alive(struct herost **start, struct herost *heros[], int size)
{
	struct herost **put = heros;
	for (int i = 0; i < size; i++) {
		struct herost *h = start[i];
		if (h == nullptr)
			continue;
		if (hero::isdead(h))
			continue;
		*put++ =  h;
	}
	return put - heros;
}

int
aliveexclude(struct herost **start, struct herost *heros[],
		int size, int exclude)
{
	struct herost **put = heros;
	for (int i = 0; i < size; i++) {
		struct herost *h = start[i];
		if (h == nullptr)
			continue;
		if (h->pos == exclude)
			continue;
		if (hero::isdead(h))
			continue;
		*put++ = h;
	}
	return put - heros;
}

int
arm(struct herost **start, struct herost *heros[], int size, int arm)
{
	struct herost **put = heros;
	for (int i = 0; i < size; i++) {
		struct herost *h = start[i];
		if (h == nullptr)
			continue;
		if (h->db->arm != arm)
			continue;
		*put++ = h;
	}
	return put - heros;
}

int
armexclude(struct herost **start, struct herost *heros[], int size,
		int arm, int exclude)
{
	int cnt = 0;
	for (int i = 0; i < size; i++) {
		struct herost *h = start[i];
		if (h == nullptr)
			continue;
		if (h->db->arm != arm)
			continue;
		if (h->pos == exclude)
			continue;
		heros[cnt++] = h;
	}
	return cnt;

}


void
sortdesc(struct herost *heros[], int size, enum property prop)
{
	std::stable_sort(&heros[0], &heros[size],
			[prop](struct herost *a, struct herost *b) {
		int64_t va = hero::propget(a, prop);
		int64_t vb = hero::propget(b, prop);
		return va > vb;
	});
}

void
sortasc(struct herost *heros[], int size, enum property prop)
{
	std::stable_sort(&heros[0], &heros[size],
			[prop](struct herost *a, struct herost *b) {
		int64_t va = hero::propget(a, prop);
		int64_t vb = hero::propget(b, prop);
		return va < vb;
	});
}


int
sortalivedesc(struct herost **start, struct herost *heros[], int size, enum property prop)
{
	int count = alive(start, heros, size);
	if (count > 0)
		sortdesc(heros, count, prop);
	return count;
}

int
sortaliveasc(struct herost **start, struct herost *heros[], int size,
		enum property prop)
{
	int count = alive(start, heros, size);
	if (count > 0)
		sortasc(heros, count, prop);
	return count;
}

void
teamshift(struct ground *g)
{
	int count = 0;
	struct herost **start, **tail, **head;
	auto &heros = g->heros;
	assert(ARRAYSIZE(g->heros) == TWO_TEAM);
	//attack team
	start = &heros[0];
	head = &heros[ONE_TEAM - 1];
	tail = head;
	while (head >= &heros[0]) {
		struct herost *h = *head--;
		if (h == nullptr)
			break;
		if (hero::isdead(h)) {
			DPRINT(g, "[teamshift] dead hero:%d\n", h->pos);
			continue;
		}
		h->pos = tail - start;
		*tail-- = h;
		count++;
	}
	while (tail > head)
		*tail-- = nullptr;
	DPRINT(g, "[perform] teamshift team ZERO alive:%d\n", count);
	g->alivecount[0] = count;
	//defend team
	count = 0;
	head = &heros[ONE_TEAM];
	tail = head;
	while (head < &heros[TWO_TEAM]) {
		struct herost *h = *head++;
		if (h == nullptr)
			break;
		if (hero::isdead(h))
			continue;
		h->pos = tail - start;
		*tail++ = h;
		count++;
	}
	while (tail < head)
		*tail++ = nullptr;
	DPRINT(g, "[perform] teamshift team ONE alive:%d\n", count);
	g->alivecount[1] = count;
	return ;
}


void
appendevent(struct ground *g, zprotobuf::wirep &obj)
{
	int ret;
	const uint8_t *data;
	event_type_t type;
	event_size_t size;
	ret = obj._serialize(&data);
	if (ret <= 0) {
		fprintf(stderr, "[battle] attackevent _serialize:%d\n", ret);
		return ;
	}
	type = obj._tag();
	size = ret;
	DPRINT(g, "[auxiliary] appent event type:%d size:%d\n", type, size);
	g->report.append((char *)&type, sizeof(type));
	g->report.append((char *)&size, sizeof(size));
	g->report.append((char *)data, size);
	return ;
}

void
attackevent(struct ground *g)
{
	if (g->eattack.list.size() == 0)
		return ;
	appendevent(g, g->eattack);
	g->eattack.list.clear();
	DPRINT(g, "[auxiliary] attackevent\n");
	return ;
}


}}

