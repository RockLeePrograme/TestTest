#ifndef __battle_db_h
#define __battle_db_h
#include "zprotowire.h"
namespace battle {
namespace db {

using namespace zprotobuf;

struct wirepimpl:public wirep {
protected:
        virtual wiretree &_wiretree() const;
};

struct prop:public wirepimpl{
        int32_t id = 0;
        float val = 0.0f;
protected:
        virtual int _encode_field(struct zproto_args *args) const;
        virtual int _decode_field(struct zproto_args *args);
public:
        virtual void _reset();
        virtual int _tag() const;
        virtual const char *_name() const;
        virtual zproto_struct *_query() const;
        static void _load(wiretree &t);
private:
        static zproto_struct *_st;
};
struct skillsel:public wirepimpl{
        int32_t faction = 0;
        int32_t range = 0;
        int32_t category = 0;
        std::vector<int32_t> count;
protected:
        virtual int _encode_field(struct zproto_args *args) const;
        virtual int _decode_field(struct zproto_args *args);
public:
        virtual void _reset();
        virtual int _tag() const;
        virtual const char *_name() const;
        virtual zproto_struct *_query() const;
        static void _load(wiretree &t);
private:
        static zproto_struct *_st;
};
struct skill:public wirepimpl{
        int32_t id = 0;
        int32_t type = 0;
        int32_t triggerparam1 = 0;
        int32_t triggerparam2 = 0;
        int32_t initparam = 0;
        int32_t cd = 0;
        int32_t range = 0;
        int32_t readyround = 0;
        struct skillsel select;
        std::vector<int64_t> element;
        int64_t nextskill = 0;
        int32_t nexthappentype = 0;
        int32_t nexthappenratio = 0;
protected:
        virtual int _encode_field(struct zproto_args *args) const;
        virtual int _decode_field(struct zproto_args *args);
public:
        virtual void _reset();
        virtual int _tag() const;
        virtual const char *_name() const;
        virtual zproto_struct *_query() const;
        static void _load(wiretree &t);
private:
        static zproto_struct *_st;
};
struct elembuff:public wirepimpl{
        int32_t delay = 0;
        int32_t trigger = 0;
        int32_t invalid = 0;
        int32_t lasttype = 0;
        int32_t lastround = 0;
        int32_t overlay = 0;
        int32_t overcount = 0;
        int32_t limittype = 0;
        int32_t limitparam = 0;
        int32_t category = 0;
protected:
        virtual int _encode_field(struct zproto_args *args) const;
        virtual int _decode_field(struct zproto_args *args);
public:
        virtual void _reset();
        virtual int _tag() const;
        virtual const char *_name() const;
        virtual zproto_struct *_query() const;
        static void _load(wiretree &t);
private:
        static zproto_struct *_st;
};
struct element:public wirepimpl{
        int32_t id = 0;
        int32_t bigtype = 0;
        int32_t smalltype = 0;
        int32_t formula = 0;
        int32_t effecttype = 0;
        struct elembuff buff;
        int32_t happentype = 0;
        int32_t happenratio = 0;
        int32_t percentdown = 0;
        int32_t percentup = 0;
        int32_t valueup = 0;
        int32_t valuedown = 0;
protected:
        virtual int _encode_field(struct zproto_args *args) const;
        virtual int _decode_field(struct zproto_args *args);
public:
        virtual void _reset();
        virtual int _tag() const;
        virtual const char *_name() const;
        virtual zproto_struct *_query() const;
        static void _load(wiretree &t);
private:
        static zproto_struct *_st;
};
struct hero:public wirepimpl{
        int32_t huid = 0;
        int32_t hid = 0;
        int32_t type = 0;
        int32_t arm = 0;
        int32_t level = 0;
        int32_t troops = 0;
        int32_t wounded = 0;
        std::vector<int32_t> skills;
        std::unordered_map<int32_t, struct prop> props;
protected:
        union iterator_wrapper {
                iterator_wrapper(){};
                std::unordered_map<int32_t, struct prop>::const_iterator props;
        };
        virtual int _encode_field(struct zproto_args *args) const;
        virtual int _decode_field(struct zproto_args *args);
        mutable union iterator_wrapper _mapiterator;
public:
        virtual void _reset();
        virtual int _tag() const;
        virtual const char *_name() const;
        virtual zproto_struct *_query() const;
        static void _load(wiretree &t);
private:
        static zproto_struct *_st;
};
struct ground:public wirepimpl{
        int32_t seed = 0;
        int32_t scene = 0;
        int32_t mround = 0;
        std::vector<struct hero> attacker;
        std::vector<struct hero> defender;
        std::unordered_map<int32_t, struct skill> skills;
        std::unordered_map<int32_t, struct element> elements;
        int32_t masterpoint = 0;
        int32_t masterdelta = 0;
        int32_t mastermax = 0;
        int32_t hurtratio = 0;
protected:
        union iterator_wrapper {
                iterator_wrapper(){};
                std::unordered_map<int32_t, struct skill>::const_iterator skills;
                std::unordered_map<int32_t, struct element>::const_iterator elements;
        };
        virtual int _encode_field(struct zproto_args *args) const;
        virtual int _decode_field(struct zproto_args *args);
        mutable union iterator_wrapper _mapiterator;
public:
        virtual void _reset();
        virtual int _tag() const;
        virtual const char *_name() const;
        virtual zproto_struct *_query() const;
        static void _load(wiretree &t);
private:
        static zproto_struct *_st;
};
class serializer:public wiretree {
	serializer();
public:
	static serializer &instance();
};

}}
#endif
