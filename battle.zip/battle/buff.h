#ifndef _BATTLE_BUFF_H
#define _BATTLE_BUFF_H

#include "ground.h"

namespace battle {
namespace buff {

void attach(struct ground *g, struct herost *atk, struct herost *def,
		const db::element *elem);
void shadowless(struct ground *g, int phase);
void detach(struct ground *g, struct herost *def, const db::element *elem);
void trigger(struct ground *g, struct herost *h, enum bufftrigger phase,
		int exclude = 0);
void takeoff(struct ground *g, struct herost *h, enum bufftakeoff phase);
void dead(struct ground *g, struct herost *h); //hero is dead, so detach all

int banget(struct ground *g, struct herost *h, int type);
const struct buffst *warcry(struct ground *g, struct herost *h);
struct buffst *hurtshare(struct ground *g, struct herost *h);
void hurtaround(struct ground *g, struct herost *atk, struct herost *def);

//status
bool ooc(struct ground *g, struct herost *h);	//out of control
bool normaltwice(struct ground *g, struct herost *h);
bool hurtinvalid(struct ground *g, struct herost *h);
bool healinvalid(struct ground *g, struct herost *h);

}}


#endif

