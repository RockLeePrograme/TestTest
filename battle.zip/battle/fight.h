#ifndef _BATTLE_FIGHT_H
#define _BATTLE_FIGHT_H

namespace battle {
namespace fight {

enum ctrl fight(struct ground *g, struct herost *h);

}}


#endif

