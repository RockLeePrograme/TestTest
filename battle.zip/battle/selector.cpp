#include <stdlib.h>
#include "ground.h"
#include "property.h"
#include "auxiliary.h"
#include "buff.h"
#include "selector.h"

#define ASC 1
#define DESC 2
#define SELENEMY 1
#define SELFRIEND 2

namespace battle {
namespace selector {

static struct {
	enum property prop;
	int seq;
} category[] = {
	{PROP_INVALID, ASC},
	{PROP_TROOPS, DESC},		//1: //兵力最多的
	{PROP_TROOPS, ASC},		//2: //兵力最少的
	{PROP_STRENGTH, DESC},		//3: //武力最多的
	{PROP_STRENGTH, ASC},		//4: //武力最少的
	{PROP_DEFENCE, DESC},   	//5: //防御最多的
	{PROP_DEFENCE, ASC},		//6: //防御最少的
	{PROP_INTELLIGENCE, DESC},	//7: //智力最多的
	{PROP_INTELLIGENCE, ASC},	//8: //智力最少的
	{PROP_SPEED, DESC},		//9: //速度最多的
	{PROP_SPEED, ASC},		//10: //速度最少的
};

static const int TEAMSLOT[TWO_TEAM] = {2, 1, 0, 3, 4, 5};

static void
select_alive(struct ground *g, int startid, struct sel *sel, int count)
{
	struct herost **start = &g->heros[startid];
	if (sel->count == 0) {
		sel->count = auxiliary::alive(start, sel->heros, count);
	} else {
		int has = sel->count;
		int ex = sel->heros[0]->pos;
		struct herost **selhero = &sel->heros[has];
		count -= has;
		count = auxiliary::aliveexclude(start, selhero, count, ex);
		sel->count = count + has;
	}
	return ;
}

static void
select_arm(struct ground *g, int startid, struct sel *sel, int count, int arm)
{
	struct herost **start = &g->heros[startid];
	if (sel->count == 0) {
		sel->count = auxiliary::arm(start, sel->heros, count, arm);
	} else {
		int has = sel->count;
		int ex = sel->heros[0]->pos;
		struct herost **selhero = &sel->heros[has];
		count -= has;
		count = auxiliary::armexclude(start, selhero, count, arm, ex);
		sel->count = count + has;
	}
	return ;
}

static void
select_pos(struct ground *g, int startid, struct sel *sel, int count, int pos)
{
	int has = sel->count;
	select_alive(g, startid, sel, count);
	count = sel->count - has;
	if (count > 0) {
		struct herost **head = &sel->heros[has];
		struct herost *h = head[0];
		int offset = pos - h->pos;
		if (offset > 0 && offset < count) { //has
			head[0] = head[offset];
			head[offset] = h;
		}
	}
	return ;
}



static void
select_category(struct ground *g, int startid, int count,
		const db::skill *skill, struct sel *sel)
{
	int n, has;
	enum property prop;
	n = skill->select.category;
	if (n >= (int)ARRAYSIZE(category)) {
		sel->count = 0;
		return ;
	}
	prop = category[n].prop;
	has = sel->count;
	select_alive(g, startid, sel, count);
	count = sel->count - has;
	if (category[n].seq == ASC)
		auxiliary::sortasc(&sel->heros[has], count, prop);
	else
		auxiliary::sortdesc(&sel->heros[has], count, prop);
	return ;
}

static bool
warcry(struct ground *g, struct herost *h,
		const db::skill *skill, struct sel *sel)
{
	int n;
	struct herost *causer;
	const struct buffst *warcry;
	warcry = buff::warcry(g, h);
	DPRINT(g, "[select] warcry:%p\n", warcry);
	if (warcry == nullptr)
		return false;
	causer = warcry->causer;
	n = abs(causer->pos - h->pos);
	if (n > skill->range) {
		DPRINT(g, "[select] warcry hero"
			"pos:%d 2-1 causer pos:%d"
			"distance:%d\n",
			h->id, causer->id, n);
		return false;
	}
	sel->heros[0] = causer;
	sel->count = 1;
	return true;
}

static void
random_shuffle(struct ground *g, struct sel *sel)
{
	int count = sel->count;
	int offset = count - 1;
	auto &rand = g->rand;
	auto &heros = sel->heros;
	for (int i = 0; i < count; i++) {
		int swap = rand.IRandom(0, offset);
		struct herost *tmp;
		tmp = heros[i];
		heros[i] = heros[swap];
		heros[swap] = tmp;
	}
	return ;
}

void
select(struct ground *g, struct herost *h, const db::skill *skill, struct sel *sel)
{
	bool ooc;
	int n, begin, end;
	int startid, count;
	struct herost **start;
	int selteam = h->team;
	begin = h->pos - skill->range;
	end = h->pos + skill->range;
	sel->count = 0;
	switch (skill->select.faction) {
	case SELENEMY:	//敌方
		if (warcry(g, h, skill, sel))
			return ;
		selteam ^= 1;
		break;
	case SELFRIEND: //我方
		break;
	default:
		return ;
	}
	ooc = buff::ooc(g, h);
	if (ooc) {
		startid = std::max(begin, 0);
		end = std::min(TWO_TEAM - 1, end);
	} else if (selteam == 0) {
		startid = std::max(begin, 0);
		end = std::min(ONE_TEAM - 1, end);
	} else {
		selteam = ONE_TEAM;
		startid = std::max(begin, ONE_TEAM);
		end = std::min(TWO_TEAM - 1, end);
	}
	count = end - startid + 1;
	if (count <= 0) {
		DPRINT(g, "[select] hero id:%d select team:%d skillrange:%d "
				"start:%d end:%d range count:%d\n",
			h->id, selteam, skill->range, startid, end, count);
		sel->count = 0;
		return ;
	}
	switch (skill->select.range) {
	case 0: //根据范围选取
		select_alive(g, startid, sel, count);
		break;
	case 1: //根据category选取
		select_category(g, startid, count, skill, sel);
		break;
	case 2:	//选取自己
		sel->heros[0] = h;
		sel->count = 1;
		break;
	case 3:	//选取非自己
		start = &g->heros[startid];
		sel->count = auxiliary::aliveexclude(start, sel->heros, count, h->pos);
		break;
	case 4: //选取骑兵
		select_arm(g, startid, sel, count, ARM_CAVALRY);
		break;
	case 5: //选取弓兵
		select_arm(g, startid, sel, count, ARM_ARCHER);
		break;
	case 6: //选取步兵
		select_arm(g, startid, sel, count, ARM_INFANTRY);
		break;
	case 7: //优先选取大营
		select_pos(g, startid, sel, count, TEAMSLOT[selteam + 2]);//2号位
		break;
	case 8:	//优先选取中军
		select_pos(g, startid, sel, count, TEAMSLOT[selteam + 1]);//1号位
		break;
	case 9: //优先选取前排
		select_pos(g, startid, sel, count, TEAMSLOT[selteam + 0]);//0号位
		break;
	default:
		sel->count = 0;
		return ;
	}
	random_shuffle(g, sel);
#if DEBUGLOG
	for (int i = 0; i < sel->count; i++) {
		struct herost *t = sel->heros[i];
		DPRINT(g, "[select] hero id:%d target id:%d\n", h->id, t->pos);
	}
#endif
	n = g->rand.IRandom(0, skill->select.count.size() - 1);
	n = skill->select.count[n];
	DPRINT(g, "[select] factio:%d ooc:%d startid:%d count:%d "
		"hero id:%d select team:%d skill range:%d "
		"start:%d end:%d really count:%d limit:%d\n",
		skill->select.faction,
		ooc, startid, count,
		h->id, selteam, skill->range,
		startid, end, sel->count, n);
	sel->count = std::min(sel->count, n);
	return ;
}

int
distance(struct herost *a, struct herost *b)
{
	int pa, pb;
	pa =  a->pos < ONE_TEAM ? ONE_TEAM - 1 - a->pos : a->pos;
	pb =  b->pos < ONE_TEAM ? ONE_TEAM - 1 - b->pos : b->pos;
	return abs(pa - pb);
}


}}

