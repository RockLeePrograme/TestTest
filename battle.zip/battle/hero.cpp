#include <stdio.h>
#include <math.h>
#include "ground.h"
#include "skill.h"
#include "hero.h"

namespace battle {
namespace hero {

static void
passive_classify(ground *g, struct herost *h, const db::skill *skill)
{
	int event = skill->initparam;
	switch (event) {
	case TRIGGER_ROUNDOPEN:
		h->passiveroundopen.push_back(skill);
		break;
	case TRIGGER_ROUNDCLOSE:
		h->passiveroundclose.push_back(skill);
		break;
	case TRIGGER_ACTIONOPEN:
		h->passiveactionopen.push_back(skill);
		break;
	case TRIGGER_ACTIONCLOSE:
		h->passiveactionclose.push_back(skill);
		break;
	default:
		DPRINT(g, "[hero] unsupport passive event:%d\n", event);
		break;
	}
}

void
init(struct ground *g, struct herost *h, const db::hero *db, int id)
{
	h->db = db;
	h->id = id;
	h->pos = id;
	h->masterskill = nullptr;
	h->normalskill = nullptr;
	h->chaseskill = nullptr;
	h->counterskill = nullptr;
	h->mastercount = 0;
	h->maxtroops = db->troops;
	for (const auto &iter:db->props) {
		h->props[iter.first] = iter.second.val;
		DPRINT(g, "[hero] pos:%d prop:%d value:%.2f\n", id, iter.first, iter.second.val);
	}
	h->props[PROP_TROOPS] = db->troops;
	h->props[PROP_HURTTROOPS] = db->wounded;
	DPRINT(g, "[hero] pos:%d heroid:%d wounded:%d\n", id, db->hid, db->wounded);
	DPRINT(g, "[hero] pos:%d prop:%d value:%d\n", id, PROP_TROOPS, db->troops);
	const auto &gskills = g->dbref->skills;
	for (auto skillid:db->skills) {
		const auto &iter = gskills.find(skillid);
		if(iter == gskills.end())
			continue;
		const db::skill *skill = &iter->second;
		DPRINT(g, "[hero] hero:%d pos:%d skill:%d skilltype:%d\n",
				db->hid, id, skill->id, skill->type);
		switch (skill->type) {
		case SKILL_OPEN:
			h->openskills.push_back(skill);
			break;
		case SKILL_STRATEGY:
			h->strategyskills.push_back(skill);
			break;
		case SKILL_PASSIVE:
			passive_classify(g, h, skill);
			break;
		case SKILL_MASTER:
			h->mastercd = skill->initparam;
			h->masterskill = skill;
			break;
		case SKILL_ACTIVE:
			h->activeskills.push_back(skill);
			break;
		case SKILL_NORMAL:
			h->normalskill = skill;
			break;
		case SKILL_CHASE:
			h->chaseskill = skill;
			break;
		case SKILL_COUNTER:
			h->counterskill = skill;
			break;
		default:
			DPRINT(g, "[hero] init unsupport skilltype:%d",
				skill->type);
			break;
		}
	}
	return ;
}

float
propget(const struct herost *h, enum property prop)
{
	const auto &iter = h->props.find((int)prop);
	if (iter == h->props.end())
		return 0;
	return iter->second;
}

static inline float
valsub(float &v, float n, float p)
{
	float val = n + v * p / PERCENT100;
	if (v > val) {
		v -= val;
		return val;
	} else {
		float sub = v;
		v = 0.0f;
		return sub;
	}
}

float
propsub(struct herost *h, enum property prop, float n, float p)
{
	float &old = h->props[prop];
	return valsub(old, n, p);
}

float
propadd(struct herost *h, enum property prop, float n, float p)
{
	float diff;
	float &res = h->props[prop];
	n += res * p / PERCENT100 + res;
	if (n < 0.0f)
		n = 0.0f;
	diff = n - res;
	res = n;
	return diff;
}

float
hpsub(struct herost *h, struct herost * atk, float *current, float n, float p)
{
	float sub;
	float &old = h->props[PROP_TROOPS];
	sub = n > 0 ? valsub(old, n, p) : 0;
	*current = old;
	return sub;
}

int
banincr(struct herost *h, int ban)
{
	int &n = h->banlist[ban];
	n += 1;
	return n;
}

int
bandec(struct herost *h, int ban, int n)
{
	auto iter = h->banlist.find(ban);
	if (iter == h->banlist.end())
		return 0;
	iter->second -= n;
	if (iter->second <= 0) {
		h->banlist.erase(iter);
		return 0;
	}
	return iter->second;;
}

int
banget(struct herost *h, int ban)
{
	const auto &iter = h->banlist.find(ban);
	if (iter == h->banlist.end())
		return 0;
	return iter->second;
}

int
statusincr(struct herost *h, enum herostatus status)
{
	int &n = h->statuslist[status];
	n += 1;
	return n;
}

int
statusdec(struct herost *h, enum herostatus status, int n)
{
	auto iter = h->statuslist.find(status);
	if (iter == h->statuslist.end())
		return 0;
	iter->second -= n;
	if (iter->second <= 0) {
		h->statuslist.erase(iter);
		return 0;
	}
	return iter->second;
}

int
statusget(struct herost *h, enum herostatus status)
{
	auto iter = h->statuslist.find(status);
	if (iter == h->statuslist.end())
		return 0;
	return iter->second;
}

bool
isdead(const struct herost *h)
{
	int64_t hp = propget(h, PROP_TROOPS);
	return hp < 1.0f;
}


}}

