#ifndef _BATTLE_H
#define _BATTLE_H
#include "StdAfx.h"
#include "idcount.h"
#include "battle_db.hpp"
#include "ground.h"
#include "property.h"
#include "extra.h"

namespace battle {

uint32_t totalprop(battle::ground &g, enum property prop, int from, int to);
uint32_t totaltroops(const std::vector<battle::db::hero> &l);
void transform(db::ground &g, std::string &dat);
void play(battle::ground &g);
void dummy(battle::ground &g, battle::result winval);
void reportextra(battle::ground &g, uint32_t type, uint32_t value);
void reportaward(battle::ground &g, const std::vector<IdCount> &l);
void getreport(battle::ground &g, std::string &report);
uint32_t replay(battle::ground &g, const std::string &op, battle::result res);
}

#endif

