#ifndef _BATTLE_HURT_H
#define _BATTLE_HURT_H

#include "ground.h"

namespace battle {
namespace hurt {

float eval(struct ground *g,  struct herost *atk, struct herost *def,
		const db::element *elem);

void perform(struct ground *g, struct herost *atk, struct herost *def,
		const db::element *elem,
		struct herost *share = nullptr, float sharepercent = 0.0f);


}}


#endif

