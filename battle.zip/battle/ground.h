#ifndef _BATTLE_GROUND_H
#define _BATTLE_GROUND_H
#include <stdarg.h>
#include <vector>
#include <memory>
#include <unordered_map>
#include <unordered_set>
#include "randomc.h"
#include "skilltype.h"
#include "battle_db.hpp"
#include "portable/battle_report.hpp"

#define DEBUGLOG		1
#define ONE_TEAM		(3)
#define TWO_TEAM		(6)
#define ATK_ID(n)		((n))
#define DEF_ID(n)		((n) + ONE_TEAM)
#define ARRAYSIZE(n)		(sizeof(n) / sizeof((n)[0]))

typedef void (*log_cb_t)(const char *str, int sz);

namespace battle {

typedef uint32_t event_type_t;
typedef uint32_t event_size_t;
typedef std::vector<int32_t>			list_t;
typedef std::vector<const db::skill *>		skills_t;
typedef std::vector<battle::db::hero>		heros_t;

enum ctrl {
	CTRL_NORMAL = 0,
	CTRL_BREAK = 1,
	CTRL_WAITMASTER = 2,
};


enum changetype : int32_t {
	CHANGE_SKILL = 1,
	CHANGE_BUFF = 2,
	CHANGE_ATTACH = 3,
	CHANGE_ATTACHDELAY = 4,
	CHANGE_ATTACHREAL = 5,
	CHANGE_DETACH = 6,
	CHANGE_DETACHREPLACE = 7,
};

enum result {
	NIL = 0,
	WIN = 1,
	LOST,
	DRAW,
};

enum bigtype :int {
	BIG_SPECIAL = 2,
	BIG_BUFFPROP = 4,
	BIG_BUFFSTEAL = 15,
};

//NOTE: keep same sa skilltype
enum bantype : int {
	BAN_ACTION = 999,	//禁止行动
	BAN_MASTER = 1,		//禁止指挥官技能
	BAN_ACTIVE = 2,		//禁止主动技能
	BAN_NORMAL = 3,		//禁止普通攻击
	BAN_PASSIVE = 4,	//禁止被动技能
	BAN_STRATEGY = 5,	//禁止战术技能
	BAN_CHASE = 6,		//禁止追击技能
	BAN_COUNTER = 7,	//禁止反击技能
};

enum skilltrigger: int {
	//type
	TRIGGER_NONE = 0,		//不需要条件
	TRIGGER_MUST = 1,		//必然触发
	TRIGGER_RAND = 2,		//概率触发
	TRIGGER_POINT = 3,		//指挥点触发
	//event
	TRIGGER_ROUNDOPEN = 1,	//回合前触发
	TRIGGER_ROUNDCLOSE = 2,	//回合后触发
	TRIGGER_ACTIONOPEN = 3,	//行动前触发
	TRIGGER_ACTIONCLOSE = 4,//行动后触发
};

enum formula : int {
	FORMULA_PHYSICS = 1,
	FORMULA_MAGIC = 2,
	FORMULA_HEAL1 = 3,
	FORMULA_HEAL2 = 4,
	FORMULA_HEAL3 = 5,
};

enum effecttype: int {
	EFFECT_HURT = 1,	//攻击
	EFFECT_HEAL = 2,	//治疗
	EFFECT_BUFF = 3,	//Buff
	EFFECT_DEBUFF = 4,	//Debuff
	EFFECT_ADDPROP = 6,	//增加属性
	EFFECT_SUBPROP = 7,	//减少属性
	EFFECT_DETACH = 8,	//清除BUFF
};

enum bufftrigger : int {
	BUFF_MOUNT = 1,		//立即生效
	BUFF_ROUNDOPEN = 2,	//回合前
	BUFF_ROUNDCLOSE = 3,	//回合结束
	BUFF_ACTOPEN = 4,	//英雄行动前
	BUFF_ACTCLOSE = 5,	//英雄行动后
	BUFF_HURTEDOPEN = 6,	//受到伤血前
	BUFF_HURTEDCLOSE = 7,	//受到伤血后
	BUFF_UNMOUNT = 8,	//BUFF结束后生效
};

enum bufftakeoff : int {
	TAKEOFF_ROUNDCLOSE = 1,	//回合结束后
	TAKEOFF_ACTCLOSE = 2,	//持有人行动后
	TAKEOFF_HURTCLOSE = 3,	//持有人释放伤害元素
	TAKEOFF_HURTEDCLOSE = 4,//持有人受击后
	TAKEOFF_HEALEDCLOSE = 5,//持有人受到治疗后
	TAKEOFF_ACTOPEN = 6,	//持有人行动前
	TAKEOFF_HEALCLOSE = 7,	//持有人释放治疗元素后
};

enum state : int {
	STATE_NONE,
	STATE_OPEN,
	STATE_STRATEGY,
	STATE_ROUNDOPEN,
	STATE_PASSIVEOPEN,
	STATE_FIGHTING,
	STATE_PASSIVECLOSE,
	STATE_ROUNDCLOSE,
	STATE_OVER,
	STATE_EXIT,
};

enum fightstate : int {
	FIGHT_NONE,
	FIGHT_BUFFOPEN,		//全场buff
	FIGHT_PASSIVEOPEN,	//行动前触发技能
	FIGHT_MASTERW,		//指挥官技能 Wait
	FIGHT_MASTERP,		//指挥官技能 Perform
	FIGHT_ACTIVE,		//主动技能
	FIGHT_NORMAL,		//普通技能
	FIGHT_MASTER2W,		//指挥官技能 Wait
	FIGHT_MASTER2P,		//指挥官技能 Perform
	FIGHT_BUFFCLOSE,	//全场buff
	FIGHT_PASSIVECLOSE,	//行动后触发被动技能
};

enum performstate : int {
	PERFORM_NONE = 0,	//
	PERFORM_ATTACK	= 1,	//执行攻击
	PERFORM_COUNTER = 2,	//执行反击
	PERFORM_CHASE = 3,	//执行追击
};

enum herostatus : int {
	HERO_NONE = 0,		//
	HERO_DIZZY = 2,		//眩晕
	HERO_OOC = 3,		//暴走
	HERO_SILENCE = 4,	//沉默
	HERO_BANNORMAL = 5,	//缴械（禁止普攻）
	HERO_BURN = 6,		//燃烧
	HERO_COLD = 7,		//寒冷
	HERO_POISON = 8,	//中毒
	HERO_NORMALTWICE = 9,	//两次普攻
	HERO_CTRLINVALID = 10,	//控制无效
	HERO_HURTINVALID = 11,	//伤害无效
	HERO_HEALINVALID = 12,	//治疗无效

};

enum uniquebuff : int {
	UNIQUE_WARCRY = 1,	//嘲讽
	UNIQUE_HURTSHARE = 2,	//援护
	UNIQUE_HURTAROUND = 3,	//分兵
};

struct buffst {
	int buffid;
	struct herost *causer;
	struct herost *owner;
	const db::element *elem;
	int lastround;
	union {
		float f;
		int n;
	}ud;
};

struct herobuff {
	//BigType << 16 | SmallType, buffid
	std::unordered_map<int, int> category;
	std::unordered_map<int, list_t> trigger;
	std::unordered_map<int, list_t> invalid;
	std::unordered_map<int, list_t> takeoff;
	std::unordered_map<int, int> unique;
	std::unordered_map<int, int> overlaycount;
	std::unordered_map<int, buffst> pool;
};

struct shadowbuff {
	int buffid;
	struct herost *atk;
	struct herost *def;
	const db::element *elem;
	shadowbuff(int b, struct herost *a,
		struct herost *d, const db::element *e):
		buffid(b), atk(a), def(d), elem(e) {}
};

typedef std::vector<struct shadowbuff> shadowbuffs_t;

struct statistics {
	float phurt;
	float mhurt;
	float heal;
};

struct herost {
	int id;
	short pos;	//pos
	short team;
	int mastercd;
	int mastercount;
	float maxtroops;
	skills_t openskills;
	skills_t strategyskills;
	skills_t passiveroundopen;
	skills_t passiveroundclose;
	skills_t passiveactionopen;
	skills_t passiveactionclose;
	skills_t activeskills;
	const db::skill *normalskill;
	const db::skill *masterskill;
	const db::skill *chaseskill;
	const db::skill *counterskill;
	struct herobuff buff;
	struct statistics statistics;
	std::unordered_map<intptr_t, int> sing;
	std::unordered_map<int, int> banlist;
	std::unordered_map<int, int> statuslist;
	std::unordered_map<int, float> props;
	const db::hero *db;
};

struct queue {
	int idx = 0;
	int count = 0;
	struct herost *heros[TWO_TEAM];
};

struct manual {
	int team = 0;
	struct herost *hero = nullptr;
};

struct ground {
	///////////////plain struct
	int round;
	int maxround;
	float hurtratio;
	int buffidx = 0;
	bool simplify;
	int mastermax;
	int masterdelta;
	int masterpoint[2];	//两队指挥点, 0 -> attack, 1 -> defend
	int manualctrl[2];	//两队手操和自动操作
	int alivecount[2];
	struct queue queue;
	struct manual manual;
	enum state state;
	enum fightstate fightstate;
	enum performstate performstate;
	struct herost *heros[TWO_TEAM];
	size_t reportlastsize;
	//NOTE: when modify struct groud fields
	//should be careful with logic.cpp::clearground()
	enum result winval = WIN;
	enum result result = NIL;
	///////////////object
	report::attack rattack;
	report::eattack eattack;
	report::operation operation;
	std::string report;
	//pool
	CRandomMersenne rand;
	const db::ground *dbref;
	std::unordered_map<int, shadowbuffs_t> shadowbuffs;
	//const data
	std::unique_ptr<struct herost> pool_heros[TWO_TEAM];
	db::ground db;
	log_cb_t log;

	void clear() {

	}
};

#if DEBUGLOG
#ifdef WIN32
static inline void DPRINT(struct ground *g, const char *fmt,...) {
	int n;
	va_list ap;
	char buff[2048];
	log_cb_t cb = g->log;
	if (cb == nullptr)
		return ;
	va_start(ap, fmt);
	n = vsnprintf(buff, 2048, fmt, ap);
	va_end(ap);
	if (n < 2048)
		cb(buff, n);
	return ;
}
#else
#define DPRINT(g, ...)		{printf(__VA_ARGS__); fflush(stdout);}
#endif
#else
#define DPRINT(g, ...)		(void)0;
#endif

}


#endif

