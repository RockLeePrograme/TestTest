#include <string.h>
#include "zprotowire.h"
#include "battle_db.hpp"
namespace battle {
namespace db {

using namespace zprotobuf;

wiretree&
wirepimpl::_wiretree() const
{
	return serializer::instance();
}

int
prop::_tag() const
{
	return 0x0;
}
const char *
prop::_name() const
{
	return "prop";
}
struct zproto_struct *prop::_st = nullptr;
struct zproto_struct *
prop::_query() const
{
	return _st;
}
void
prop::_load(wiretree &t)
{
	prop::_st = t.query("prop");
	assert(prop::_st);
}
void
prop::_reset()
{
	id = 0;
	val = 0.0f;

}
int
prop::_encode_field(struct zproto_args *args) const
{
	switch (args->tag) {
	case 1:
		return _write(args, id);
	case 2:
		return _write(args, val);
	default:
		return ZPROTO_ERROR;
	}
}
int
prop::_decode_field(struct zproto_args *args) 
{
	switch (args->tag) {
	case 1:
		return _read(args, id);
	case 2:
		return _read(args, val);
	default:
		return ZPROTO_ERROR;
	}
}
int
skillsel::_tag() const
{
	return 0x0;
}
const char *
skillsel::_name() const
{
	return "skillsel";
}
struct zproto_struct *skillsel::_st = nullptr;
struct zproto_struct *
skillsel::_query() const
{
	return _st;
}
void
skillsel::_load(wiretree &t)
{
	skillsel::_st = t.query("skillsel");
	assert(skillsel::_st);
}
void
skillsel::_reset()
{
	faction = 0;
	range = 0;
	category = 0;
	count.clear();

}
int
skillsel::_encode_field(struct zproto_args *args) const
{
	switch (args->tag) {
	case 1:
		return _write(args, faction);
	case 2:
		return _write(args, range);
	case 3:
		return _write(args, category);
	case 4:
		assert(args->idx >= 0);
		if (args->idx >= (int)count.size()) {
			args->len = args->idx;
			return ZPROTO_NOFIELD;
		}
		return _write(args, count[args->idx]);
	default:
		return ZPROTO_ERROR;
	}
}
int
skillsel::_decode_field(struct zproto_args *args) 
{
	switch (args->tag) {
	case 1:
		return _read(args, faction);
	case 2:
		return _read(args, range);
	case 3:
		return _read(args, category);
	case 4:
		assert(args->idx >= 0);
		if (args->len == 0)
			return 0;
		count.resize(args->idx + 1);
		return _read(args, count[args->idx]);
	default:
		return ZPROTO_ERROR;
	}
}
int
skill::_tag() const
{
	return 0x0;
}
const char *
skill::_name() const
{
	return "skill";
}
struct zproto_struct *skill::_st = nullptr;
struct zproto_struct *
skill::_query() const
{
	return _st;
}
void
skill::_load(wiretree &t)
{
	skill::_st = t.query("skill");
	assert(skill::_st);
}
void
skill::_reset()
{
	id = 0;
	type = 0;
	triggerparam1 = 0;
	triggerparam2 = 0;
	initparam = 0;
	cd = 0;
	range = 0;
	readyround = 0;
	select._reset();
	element.clear();
	nextskill = 0;
	nexthappentype = 0;
	nexthappenratio = 0;

}
int
skill::_encode_field(struct zproto_args *args) const
{
	switch (args->tag) {
	case 1:
		return _write(args, id);
	case 2:
		return _write(args, type);
	case 3:
		return _write(args, triggerparam1);
	case 4:
		return _write(args, triggerparam2);
	case 5:
		return _write(args, initparam);
	case 6:
		return _write(args, cd);
	case 7:
		return _write(args, range);
	case 8:
		return _write(args, readyround);
	 case 9:
		 return select._encode(args->buff, args->buffsz, args->sttype);
	case 10:
		assert(args->idx >= 0);
		if (args->idx >= (int)element.size()) {
			args->len = args->idx;
			return ZPROTO_NOFIELD;
		}
		return _write(args, element[args->idx]);
	case 11:
		return _write(args, nextskill);
	case 12:
		return _write(args, nexthappentype);
	case 13:
		return _write(args, nexthappenratio);
	default:
		return ZPROTO_ERROR;
	}
}
int
skill::_decode_field(struct zproto_args *args) 
{
	switch (args->tag) {
	case 1:
		return _read(args, id);
	case 2:
		return _read(args, type);
	case 3:
		return _read(args, triggerparam1);
	case 4:
		return _read(args, triggerparam2);
	case 5:
		return _read(args, initparam);
	case 6:
		return _read(args, cd);
	case 7:
		return _read(args, range);
	case 8:
		return _read(args, readyround);
	 case 9:
		 return select._decode(args->buff, args->buffsz, args->sttype);
	case 10:
		assert(args->idx >= 0);
		if (args->len == 0)
			return 0;
		element.resize(args->idx + 1);
		return _read(args, element[args->idx]);
	case 11:
		return _read(args, nextskill);
	case 12:
		return _read(args, nexthappentype);
	case 13:
		return _read(args, nexthappenratio);
	default:
		return ZPROTO_ERROR;
	}
}
int
elembuff::_tag() const
{
	return 0x0;
}
const char *
elembuff::_name() const
{
	return "elembuff";
}
struct zproto_struct *elembuff::_st = nullptr;
struct zproto_struct *
elembuff::_query() const
{
	return _st;
}
void
elembuff::_load(wiretree &t)
{
	elembuff::_st = t.query("elembuff");
	assert(elembuff::_st);
}
void
elembuff::_reset()
{
	delay = 0;
	trigger = 0;
	invalid = 0;
	lasttype = 0;
	lastround = 0;
	overlay = 0;
	overcount = 0;
	limittype = 0;
	limitparam = 0;
	category = 0;

}
int
elembuff::_encode_field(struct zproto_args *args) const
{
	switch (args->tag) {
	case 1:
		return _write(args, delay);
	case 2:
		return _write(args, trigger);
	case 3:
		return _write(args, invalid);
	case 4:
		return _write(args, lasttype);
	case 5:
		return _write(args, lastround);
	case 6:
		return _write(args, overlay);
	case 7:
		return _write(args, overcount);
	case 8:
		return _write(args, limittype);
	case 9:
		return _write(args, limitparam);
	case 10:
		return _write(args, category);
	default:
		return ZPROTO_ERROR;
	}
}
int
elembuff::_decode_field(struct zproto_args *args) 
{
	switch (args->tag) {
	case 1:
		return _read(args, delay);
	case 2:
		return _read(args, trigger);
	case 3:
		return _read(args, invalid);
	case 4:
		return _read(args, lasttype);
	case 5:
		return _read(args, lastround);
	case 6:
		return _read(args, overlay);
	case 7:
		return _read(args, overcount);
	case 8:
		return _read(args, limittype);
	case 9:
		return _read(args, limitparam);
	case 10:
		return _read(args, category);
	default:
		return ZPROTO_ERROR;
	}
}
int
element::_tag() const
{
	return 0x0;
}
const char *
element::_name() const
{
	return "element";
}
struct zproto_struct *element::_st = nullptr;
struct zproto_struct *
element::_query() const
{
	return _st;
}
void
element::_load(wiretree &t)
{
	element::_st = t.query("element");
	assert(element::_st);
}
void
element::_reset()
{
	id = 0;
	bigtype = 0;
	smalltype = 0;
	formula = 0;
	effecttype = 0;
	buff._reset();
	happentype = 0;
	happenratio = 0;
	percentdown = 0;
	percentup = 0;
	valueup = 0;
	valuedown = 0;

}
int
element::_encode_field(struct zproto_args *args) const
{
	switch (args->tag) {
	case 1:
		return _write(args, id);
	case 2:
		return _write(args, bigtype);
	case 3:
		return _write(args, smalltype);
	case 4:
		return _write(args, formula);
	case 5:
		return _write(args, effecttype);
	 case 6:
		 return buff._encode(args->buff, args->buffsz, args->sttype);
	case 7:
		return _write(args, happentype);
	case 8:
		return _write(args, happenratio);
	case 9:
		return _write(args, percentdown);
	case 10:
		return _write(args, percentup);
	case 11:
		return _write(args, valueup);
	case 12:
		return _write(args, valuedown);
	default:
		return ZPROTO_ERROR;
	}
}
int
element::_decode_field(struct zproto_args *args) 
{
	switch (args->tag) {
	case 1:
		return _read(args, id);
	case 2:
		return _read(args, bigtype);
	case 3:
		return _read(args, smalltype);
	case 4:
		return _read(args, formula);
	case 5:
		return _read(args, effecttype);
	 case 6:
		 return buff._decode(args->buff, args->buffsz, args->sttype);
	case 7:
		return _read(args, happentype);
	case 8:
		return _read(args, happenratio);
	case 9:
		return _read(args, percentdown);
	case 10:
		return _read(args, percentup);
	case 11:
		return _read(args, valueup);
	case 12:
		return _read(args, valuedown);
	default:
		return ZPROTO_ERROR;
	}
}
int
hero::_tag() const
{
	return 0x0;
}
const char *
hero::_name() const
{
	return "hero";
}
struct zproto_struct *hero::_st = nullptr;
struct zproto_struct *
hero::_query() const
{
	return _st;
}
void
hero::_load(wiretree &t)
{
	hero::_st = t.query("hero");
	assert(hero::_st);
}
void
hero::_reset()
{
	huid = 0;
	hid = 0;
	type = 0;
	arm = 0;
	level = 0;
	troops = 0;
	wounded = 0;
	skills.clear();
	props.clear();

}
int
hero::_encode_field(struct zproto_args *args) const
{
	switch (args->tag) {
	case 1:
		return _write(args, huid);
	case 2:
		return _write(args, hid);
	case 3:
		return _write(args, type);
	case 4:
		return _write(args, arm);
	case 5:
		return _write(args, level);
	case 6:
		return _write(args, troops);
	case 7:
		return _write(args, wounded);
	case 8:
		assert(args->idx >= 0);
		if (args->idx >= (int)skills.size()) {
			args->len = args->idx;
			return ZPROTO_NOFIELD;
		}
		return _write(args, skills[args->idx]);
	 case 9: {
		 int ret;
		 if (args->idx == 0) {
			 _mapiterator.props = props.begin();
		 }
		 if (_mapiterator.props == props.end()) {
			 args->len = args->idx;
			 return ZPROTO_NOFIELD;
		 }
		 ret = _mapiterator.props->second._encode(args->buff, args->buffsz, args->sttype);
		 ++_mapiterator.props;
		 return ret;}
	default:
		return ZPROTO_ERROR;
	}
}
int
hero::_decode_field(struct zproto_args *args) 
{
	switch (args->tag) {
	case 1:
		return _read(args, huid);
	case 2:
		return _read(args, hid);
	case 3:
		return _read(args, type);
	case 4:
		return _read(args, arm);
	case 5:
		return _read(args, level);
	case 6:
		return _read(args, troops);
	case 7:
		return _read(args, wounded);
	case 8:
		assert(args->idx >= 0);
		if (args->len == 0)
			return 0;
		skills.resize(args->idx + 1);
		return _read(args, skills[args->idx]);
	 case 9: {
		 int ret;
		 struct prop _tmp;
		 assert(args->idx >= 0);
		 if (args->len == 0)
			 return 0;
		 ret = _tmp._decode(args->buff, args->buffsz, args->sttype);
		 props[_tmp.id] = std::move(_tmp);
		 return ret;
		 }
	default:
		return ZPROTO_ERROR;
	}
}
int
ground::_tag() const
{
	return 0x0;
}
const char *
ground::_name() const
{
	return "ground";
}
struct zproto_struct *ground::_st = nullptr;
struct zproto_struct *
ground::_query() const
{
	return _st;
}
void
ground::_load(wiretree &t)
{
	ground::_st = t.query("ground");
	assert(ground::_st);
}
void
ground::_reset()
{
	seed = 0;
	scene = 0;
	mround = 0;
	attacker.clear();
	defender.clear();
	skills.clear();
	elements.clear();
	masterpoint = 0;
	masterdelta = 0;
	mastermax = 0;
	hurtratio = 0;

}
int
ground::_encode_field(struct zproto_args *args) const
{
	switch (args->tag) {
	case 1:
		return _write(args, seed);
	case 2:
		return _write(args, scene);
	case 3:
		return _write(args, mround);
	 case 4:
		 if (args->idx >= (int)attacker.size()) {
			 args->len = args->idx;
			 return ZPROTO_NOFIELD;
		 }
		 return attacker[args->idx]._encode(args->buff, args->buffsz, args->sttype);
	 case 5:
		 if (args->idx >= (int)defender.size()) {
			 args->len = args->idx;
			 return ZPROTO_NOFIELD;
		 }
		 return defender[args->idx]._encode(args->buff, args->buffsz, args->sttype);
	 case 6: {
		 int ret;
		 if (args->idx == 0) {
			 _mapiterator.skills = skills.begin();
		 }
		 if (_mapiterator.skills == skills.end()) {
			 args->len = args->idx;
			 return ZPROTO_NOFIELD;
		 }
		 ret = _mapiterator.skills->second._encode(args->buff, args->buffsz, args->sttype);
		 ++_mapiterator.skills;
		 return ret;}
	 case 7: {
		 int ret;
		 if (args->idx == 0) {
			 _mapiterator.elements = elements.begin();
		 }
		 if (_mapiterator.elements == elements.end()) {
			 args->len = args->idx;
			 return ZPROTO_NOFIELD;
		 }
		 ret = _mapiterator.elements->second._encode(args->buff, args->buffsz, args->sttype);
		 ++_mapiterator.elements;
		 return ret;}
	case 8:
		return _write(args, masterpoint);
	case 9:
		return _write(args, masterdelta);
	case 10:
		return _write(args, mastermax);
	case 11:
		return _write(args, hurtratio);
	default:
		return ZPROTO_ERROR;
	}
}
int
ground::_decode_field(struct zproto_args *args) 
{
	switch (args->tag) {
	case 1:
		return _read(args, seed);
	case 2:
		return _read(args, scene);
	case 3:
		return _read(args, mround);
	 case 4:
		 assert(args->idx >= 0);
		 if (args->len == 0)
			 return 0;
		 attacker.resize(args->idx + 1);
		 return attacker[args->idx]._decode(args->buff, args->buffsz, args->sttype);
	 case 5:
		 assert(args->idx >= 0);
		 if (args->len == 0)
			 return 0;
		 defender.resize(args->idx + 1);
		 return defender[args->idx]._decode(args->buff, args->buffsz, args->sttype);
	 case 6: {
		 int ret;
		 struct skill _tmp;
		 assert(args->idx >= 0);
		 if (args->len == 0)
			 return 0;
		 ret = _tmp._decode(args->buff, args->buffsz, args->sttype);
		 skills[_tmp.id] = std::move(_tmp);
		 return ret;
		 }
	 case 7: {
		 int ret;
		 struct element _tmp;
		 assert(args->idx >= 0);
		 if (args->len == 0)
			 return 0;
		 ret = _tmp._decode(args->buff, args->buffsz, args->sttype);
		 elements[_tmp.id] = std::move(_tmp);
		 return ret;
		 }
	case 8:
		return _read(args, masterpoint);
	case 9:
		return _read(args, masterdelta);
	case 10:
		return _read(args, mastermax);
	case 11:
		return _read(args, hurtratio);
	default:
		return ZPROTO_ERROR;
	}
}
const char *def = "\x23\x23\x23\x23\x23\x23\x23\x23\x23\x23\x23\x58\x6d\x6c\x20\x4d\x69\x72\x72\x6f\x72\xa\xa\x70\x72\x6f\x70\x20\x7b\xa\x9\x2e\x69\x64\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x31\xa\x9\x2e\x76\x61\x6c\x3a\x66\x6c\x6f\x61\x74\x20\x32\xa\x7d\xa\xa\x73\x6b\x69\x6c\x6c\x73\x65\x6c\x20\x7b\xa\x9\x2e\x66\x61\x63\x74\x69\x6f\x6e\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x31\xa\x9\x2e\x72\x61\x6e\x67\x65\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x32\xa\x9\x2e\x63\x61\x74\x65\x67\x6f\x72\x79\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x33\xa\x9\x2e\x63\x6f\x75\x6e\x74\x3a\x69\x6e\x74\x65\x67\x65\x72\x5b\x5d\x20\x34\xa\x7d\xa\xa\x73\x6b\x69\x6c\x6c\x20\x7b\xa\x9\x2e\x69\x64\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x31\xa\x9\x2e\x74\x79\x70\x65\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x32\xa\x9\x2e\x74\x72\x69\x67\x67\x65\x72\x70\x61\x72\x61\x6d\x31\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x33\xa\x9\x2e\x74\x72\x69\x67\x67\x65\x72\x70\x61\x72\x61\x6d\x32\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x34\xa\x9\x2e\x69\x6e\x69\x74\x70\x61\x72\x61\x6d\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x35\xa\x9\x2e\x63\x64\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x36\xa\x9\x2e\x72\x61\x6e\x67\x65\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x37\xa\x9\x2e\x72\x65\x61\x64\x79\x72\x6f\x75\x6e\x64\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x38\xa\x9\x2e\x73\x65\x6c\x65\x63\x74\x3a\x73\x6b\x69\x6c\x6c\x73\x65\x6c\x20\x39\xa\x9\x2e\x65\x6c\x65\x6d\x65\x6e\x74\x3a\x6c\x6f\x6e\x67\x5b\x5d\x20\x31\x30\xa\x9\x2e\x6e\x65\x78\x74\x73\x6b\x69\x6c\x6c\x3a\x6c\x6f\x6e\x67\x20\x31\x31\x9\x9\x23\x74\x68\x69\x73\x20\x66\x69\x65\x6c\x64\x20\x77\x69\x6c\x6c\x20\x73\x61\x76\x65\x20\x73\x6b\x69\x6c\x6c\x20\x70\x6f\x69\x6e\x74\x65\x72\xa\x9\x2e\x6e\x65\x78\x74\x68\x61\x70\x70\x65\x6e\x74\x79\x70\x65\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x31\x32\xa\x9\x2e\x6e\x65\x78\x74\x68\x61\x70\x70\x65\x6e\x72\x61\x74\x69\x6f\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x31\x33\xa\x7d\xa\xa\x65\x6c\x65\x6d\x62\x75\x66\x66\x20\x7b\xa\x9\x2e\x64\x65\x6c\x61\x79\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x31\xa\x9\x2e\x74\x72\x69\x67\x67\x65\x72\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x32\xa\x9\x2e\x69\x6e\x76\x61\x6c\x69\x64\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x33\xa\x9\x2e\x6c\x61\x73\x74\x74\x79\x70\x65\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x34\xa\x9\x2e\x6c\x61\x73\x74\x72\x6f\x75\x6e\x64\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x35\xa\x9\x2e\x6f\x76\x65\x72\x6c\x61\x79\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x36\xa\x9\x2e\x6f\x76\x65\x72\x63\x6f\x75\x6e\x74\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x37\xa\x9\x2e\x6c\x69\x6d\x69\x74\x74\x79\x70\x65\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x20\x38\xa\x9\x2e\x6c\x69\x6d\x69\x74\x70\x61\x72\x61\x6d\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x39\xa\x9\x2e\x63\x61\x74\x65\x67\x6f\x72\x79\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x31\x30\xa\x7d\xa\xa\x65\x6c\x65\x6d\x65\x6e\x74\x20\x7b\xa\x9\x2e\x69\x64\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x31\xa\x9\x2e\x62\x69\x67\x74\x79\x70\x65\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x32\xa\x9\x2e\x73\x6d\x61\x6c\x6c\x74\x79\x70\x65\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x33\xa\x9\x2e\x66\x6f\x72\x6d\x75\x6c\x61\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x34\xa\x9\x2e\x65\x66\x66\x65\x63\x74\x74\x79\x70\x65\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x35\xa\x9\x2e\x62\x75\x66\x66\x3a\x65\x6c\x65\x6d\x62\x75\x66\x66\x20\x36\xa\x9\x2e\x68\x61\x70\x70\x65\x6e\x74\x79\x70\x65\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x37\xa\x9\x2e\x68\x61\x70\x70\x65\x6e\x72\x61\x74\x69\x6f\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x38\xa\x9\x2e\x70\x65\x72\x63\x65\x6e\x74\x64\x6f\x77\x6e\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x39\xa\x9\x2e\x70\x65\x72\x63\x65\x6e\x74\x75\x70\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x31\x30\xa\x9\x2e\x76\x61\x6c\x75\x65\x75\x70\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x31\x31\xa\x9\x2e\x76\x61\x6c\x75\x65\x64\x6f\x77\x6e\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x31\x32\xa\x7d\xa\xa\x23\x23\x23\x23\x23\x20\x64\x61\x74\x61\x20\x73\x74\x72\x75\x63\x74\xa\xa\x68\x65\x72\x6f\x20\x7b\xa\x9\x2e\x68\x75\x69\x64\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x31\xa\x9\x2e\x68\x69\x64\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x32\xa\x9\x2e\x74\x79\x70\x65\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x33\x20\x23\x20\x65\x6e\x75\x6d\x20\x68\x65\x72\x6f\x74\x79\x70\x65\x20\x40\x20\x70\x72\x6f\x70\x65\x72\x74\x79\x2e\x68\xa\x9\x2e\x61\x72\x6d\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x34\xa\x9\x2e\x6c\x65\x76\x65\x6c\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x35\xa\x9\x2e\x74\x72\x6f\x6f\x70\x73\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x36\x20\x23\x61\x6c\x69\x76\x65\x20\x74\x72\x6f\x6f\x70\x73\xa\x9\x2e\x77\x6f\x75\x6e\x64\x65\x64\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x37\x20\x23\x68\x75\x72\x74\x20\x74\x72\x6f\x6f\x70\x73\xa\x9\x2e\x73\x6b\x69\x6c\x6c\x73\x3a\x69\x6e\x74\x65\x67\x65\x72\x5b\x5d\x20\x38\xa\x9\x2e\x70\x72\x6f\x70\x73\x3a\x70\x72\x6f\x70\x5b\x69\x64\x5d\x20\x39\xa\x7d\xa\xa\x67\x72\x6f\x75\x6e\x64\x20\x7b\xa\x9\x2e\x73\x65\x65\x64\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x31\xa\x9\x2e\x73\x63\x65\x6e\x65\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x32\xa\x9\x2e\x6d\x72\x6f\x75\x6e\x64\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x33\xa\x9\x2e\x61\x74\x74\x61\x63\x6b\x65\x72\x3a\x68\x65\x72\x6f\x5b\x5d\x20\x34\xa\x9\x2e\x64\x65\x66\x65\x6e\x64\x65\x72\x3a\x68\x65\x72\x6f\x5b\x5d\x20\x35\xa\x9\x2e\x73\x6b\x69\x6c\x6c\x73\x3a\x73\x6b\x69\x6c\x6c\x5b\x69\x64\x5d\x20\x36\xa\x9\x2e\x65\x6c\x65\x6d\x65\x6e\x74\x73\x3a\x65\x6c\x65\x6d\x65\x6e\x74\x5b\x69\x64\x5d\x20\x37\xa\x9\x2e\x6d\x61\x73\x74\x65\x72\x70\x6f\x69\x6e\x74\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x38\xa\x9\x2e\x6d\x61\x73\x74\x65\x72\x64\x65\x6c\x74\x61\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x39\xa\x9\x2e\x6d\x61\x73\x74\x65\x72\x6d\x61\x78\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x31\x30\xa\x9\x2e\x68\x75\x72\x74\x72\x61\x74\x69\x6f\x3a\x69\x6e\x74\x65\x67\x65\x72\x20\x31\x31\xa\x7d\xa\xa";

serializer::serializer()
	 :wiretree(def)
{
	prop::_load(*this);
	skillsel::_load(*this);
	skill::_load(*this);
	elembuff::_load(*this);
	element::_load(*this);
	hero::_load(*this);
	ground::_load(*this);
}
serializer &
serializer::instance()
{
	 static serializer *inst = new serializer();
	 return *inst;
}
}}
