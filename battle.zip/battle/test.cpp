#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include "property.h"
#include "ground.h"
#include "logic.h"
#include "XmlStruct.h"
#include "test.h"

#define Config XmlConfig::Instance()

namespace battle {

void
test()
{
	int err;
	ground g;
	struct stat st;
	err = stat("./ground.dat", &st);
	if (err == -1) {
		perror("zproto_load:");
		return ;
	}
	FILE *fp = fopen("./ground.dat", "rb");
	if (fp == NULL) {
		perror("zproto_load:");
		return ;
	}
	uint8_t *buff = (uint8_t *)malloc(st.st_size + 1);
	err = fread(buff, 1, st.st_size, fp);
	if (err != st.st_size) {
		return ;
	}
	err = logic::parse(g.db, buff, st.st_size);
	assert(err > 0);
	logic::start(&g, nullptr);
	while (g.state != STATE_EXIT) {
		logic::step(&g);
	}
	printf("fight ok\n");
}

}
