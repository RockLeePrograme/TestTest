#ifndef _BATTLE_HEAL_H
#define _BATTLE_HEAL_H

#include "ground.h"

namespace battle {
namespace heal {

float eval(struct ground *g, struct herost *atk, struct herost *def,
		const db::element *elem);

void perform(struct ground *g, struct herost *atk, struct herost *def,
		const db::element *elem);


}}


#endif

