#include "ground.h"
#include "selector.h"
#include "auxiliary.h"
#include "hero.h"
#include "hurt.h"
#include "heal.h"
#include "buff.h"
#include "skill.h"

namespace battle {
namespace skill {

static bool
triggerpoint(struct ground *g, struct herost *h, const db::skill *skill)
{
	bool trigger;
	int team, need;
	DPRINT(g, "[skill] triggerpoint hero id"
		":%d mastercd:%d round:%d\n",
		h->id, h->mastercd, g->round);
	if (h->mastercd > g->round)
		return false;
	team = h->team;
	need = hero::propget(h, PROP_MASTEPOINT);
	need +=  skill->triggerparam2;
	trigger = g->masterpoint[team] >= need;
	if (trigger) {
		h->mastercd = g->round + skill->cd;
		g->masterpoint[team] -= need;
		auxiliary::pushchange(g, CHANGE_SKILL, 0, team,
			PROP_MASTER, g->masterpoint[team], BUFF_ACTOPEN);
	}
	return trigger;
}


static bool
trigger(struct ground *g, struct herost *h, const db::skill *skill)
{
	bool trigger;
	int ratio;
	int type = skill->triggerparam1;
	switch (type) {
	case TRIGGER_NONE:
	case TRIGGER_MUST:
		trigger = true;
		break;
	case TRIGGER_RAND:
		ratio = skill->triggerparam2;
		if (skill->type == SKILL_ACTIVE)
			ratio += hero::propget(h, PROP_ACTIVERATIO);
		trigger = g->rand.IRandom(1, PERCENT100) < ratio;
		break;
	case TRIGGER_POINT:
		trigger = triggerpoint(g, h, skill);
		break;
	default:
		trigger = false;
		break;
	}
	DPRINT(g, "[skill] trigger atk id:%d skill:%d trigger:%d res:%d\n",
		h->id, skill->id, type, trigger);
	return trigger;
}

enum happentype {
	HAPPEN_MUST = 1,
	HAPPEN_RAND = 2,
};

static inline bool
elemtrigger(struct ground *g, struct herost *atk, struct herost *def,
		const db::element *elem)
{
	(void)atk;
	(void)def;
	switch(elem->happentype) {
	case HAPPEN_MUST:
		return true;
	case HAPPEN_RAND:
		return g->rand.IRandom(1, PERCENT100) < elem->happenratio;
	default:
		DPRINT(g, "[skill] unknow elemet happentype:%d\n",
				elem->happentype);
		break;
	}
	return false;
}

static inline void
propsub(struct ground *g, struct herost *atk, struct herost *def,
		const db::element *e)
{
	enum property prop;
	float percent, value, real;
	auto &rand = g->rand;
	(void)real;
	prop = (enum property)e->smalltype;
	percent = rand.IRandom(e->percentdown, e->percentup);
	value = rand.IRandom(e->valuedown, e->valueup);
	real = hero::propsub(def, prop, value, percent);
	DPRINT(g, "[skill] sub id:%d prop:%d "
			"percent:%f value:%f final:%f\n",
			def->id, e->smalltype,
			percent, value, real);
	return ;
}

static inline void
propadd(struct ground *g, struct herost *atk, struct herost *def,
		const db::element *e)
{
	enum property prop;
	float percent, value, real;
	auto &rand = g->rand;
	(void)real;
	prop = (enum property)e->smalltype;
	percent = rand.IRandom(e->percentdown, e->percentup);
	value = rand.IRandom(e->valuedown, e->valueup);
	real = hero::propadd(def, prop, value, percent);
	DPRINT(g, "[skill] add prop id:%d prop:%d "
			"percent:%f value:%f final:%f\n",
			def->id, e->smalltype,
			percent, value, real);
	return ;
}


static void
fire_elem(struct ground *g, struct herost *atk,
		const db::skill *skill, struct herost *def)
{
	struct buffst *b;
	struct herost *share;
	float sharep;
	if (skill->type == SKILL_NORMAL && (b = buff::hurtshare(g, def))) {
		auto &rand = g->rand;
		auto &eshare = b->elem;
		share = b->causer;
		sharep = rand.IRandom(eshare->percentdown, eshare->percentup);
	} else {
		share = nullptr;
		sharep = 0.0f;
	}
	for (auto elemid:skill->element) {
		const db::element *e = (const db::element *)elemid;
		if (e == nullptr || !elemtrigger(g, atk, def, e))
			continue;
		switch (e->effecttype) {
		case EFFECT_HURT:
			hurt::perform(g, atk, def, e, share, sharep);
			break;
		case EFFECT_HEAL:
			heal::perform(g, atk, def, e);
			break;
		case EFFECT_DEBUFF:
		case EFFECT_BUFF:
			buff::attach(g, atk, def, e);
			break;
		case EFFECT_DETACH:
			buff::detach(g, def, e);
			break;
		case EFFECT_SUBPROP:
			propsub(g, atk, def, e);
			break;
		case EFFECT_ADDPROP:
			propadd(g, atk, def, e);
			break;
		}
	}
	return ;
}

static inline void
fire_each(struct ground *g, struct herost *atk,
		const db::skill *skill, selector::sel *sel)
{
	if (sel->count == 0)
		return ;
	auto &report = g->rattack;
	report.atk = atk->id;
	report.skill = skill->id;
	for (int i = 0; i < sel->count; i++) {
		struct herost *h = sel->heros[i];
		DPRINT(g, "[skill] attack atk id:%d skill:%d def id:%d\n",
			atk->id, skill->id, h->id);
		fire_elem(g, atk, skill, h);
	}
	g->eattack.list.emplace_back(std::move(g->rattack));
	return ;
}


static void
fire_nested(struct ground *g, struct herost *atk, const db::skill *skill)
{
	struct selector::sel sel;
	selector::select(g, atk, skill, &sel);
recursive:
	DPRINT(g, "[skill] nested atk id:%d skill:%d count:%d\n",
		atk->id, skill->id, sel.count);
	fire_each(g, atk, skill, &sel);
	if (skill->nextskill) {
		selector::select(g, atk, skill, &sel);
		skill = (db::skill *) skill->nextskill;
		goto recursive; //tail call
	}
	return ;
}

static void
fire(struct ground *g, struct herost *atk, const db::skill *skill)
{
	struct selector::sel sel;
	g->performstate = PERFORM_ATTACK;
	selector::select(g, atk, skill, &sel);
	fire_each(g, atk, skill, &sel);
	if (skill->nextskill)
		fire_nested(g, atk, (db::skill *)skill->nextskill);
	if (skill->type != SKILL_NORMAL)
		return ;
	if (sel.count > 0) //分兵
		buff::hurtaround(g, atk, sel.heros[0]);
	g->performstate = PERFORM_COUNTER;
	for (int i = 0; i < sel.count; i++) {
		struct herost *h = sel.heros[i];
		const db::skill *counter = h->counterskill;
		if (counter == nullptr)
			continue;
		if (selector::distance(h, atk) > counter->range) {
			DPRINT(g, "[skill] counter atk id:%d"
				" counter skill:%d range:%d def id:%d\n",
				atk->id, counter->id,
				counter->range,h->id);
			continue;
		}
		if (!trigger(g, h, counter))
			continue;
		DPRINT(g, "[skill] counter atk id:%d skill:%d def id:%d\n",
			atk->id, counter->id, h->id);
		auto &report = g->rattack;
		report.atk = h->id;
		report.skill = counter->id;
		fire_elem(g, h, counter, atk);
		if (counter->nextskill) {
			const db::skill *s = (db::skill *)counter->nextskill;
			fire_nested(g, h, s);
		}
	}
	if (atk->chaseskill == nullptr || !(trigger(g, atk, atk->chaseskill)))
		return ;
	g->performstate = PERFORM_CHASE;
	sel.count = auxiliary::aliveshrink(sel.heros, sel.count);
	DPRINT(g, "[skill] chase atk id:%d skill:%d def count:%d\n",
			atk->id, atk->chaseskill->id, sel.count);
	fire_each(g, atk, atk->chaseskill, &sel);
	return ;
}

static inline void
sing(struct ground *g, struct herost *h, const db::skill *skill)
{
	int round;
	auto &sing = h->sing;
	intptr_t skillptr = (intptr_t)skill;
	if (sing.count(skillptr)) {
		DPRINT(g, "[skill] sing id:%d has sing skill:%d drop it\n",
			h->id, skill->id);
		return ;
	}
	round = g->round + skill->readyround;
	sing[skillptr] = round;
	DPRINT(g, "[hero] sing id:%d skill:%d effect round:%d\n",
			h->id, skill->id, round);
	return ;
}

void
songclear(struct ground *g, struct herost *h)
{
	(void)g;
	h->sing.clear();
	return ;
}

bool
perform(struct ground *g, struct herost *atk, const db::skill *skill)
{
	auto &s = atk->sing;
	intptr_t skillptr = (intptr_t)skill;
	auto iter = s.find(skillptr);
	if (iter != s.end()) {
		if (iter->second != g->round)
			return false;
		s.erase(iter);
	} else {
		if (!trigger(g, atk, skill))
			return false;
		if (skill->readyround > 0) {	//need sing
			sing(g, atk, skill);
			return false;
		}
	}
	fire(g, atk, skill);
	auxiliary::attackevent(g);
	DPRINT(g, "[skill] finish\n");
	return true;
}


}}
