#ifndef _BATTLE_SKILL_H
#define _BATTLE_SKILL_H

#include "ground.h"

namespace battle {
namespace skill {

void songclear(struct ground *g, struct herost *h);
void song(struct ground *g, struct herost *h, enum skilltype type);
bool perform(struct ground *g, struct herost *atk, const db::skill *skill);

}}

#endif

